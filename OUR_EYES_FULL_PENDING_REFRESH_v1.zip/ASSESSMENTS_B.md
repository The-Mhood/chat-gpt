# Group B — 43 independent twelve-component assessments

File roles and historical/current recommendations are separate from the preserved CD6/21/12 result. Individual Markdown files are in the companion archive at `assessments/CODE.md`.

- [B01](#b01) — `B2_CAND_VR-011_LANDING_OF_UNCLAIMED_V003.jpg`
- [B02](#b02) — `CH01-SET-001-ST01_V001.jpg`
- [B03](#b03) — `CH01-SET-001-ST01_V002.jpg`
- [B04](#b04) — `CH01-SET-001-ST02_V001.jpg`
- [B05](#b05) — `CH01-SET-001-ST02_V002.jpg`
- [B06](#b06) — `CH01-SET-001-ST03_V001.jpg`
- [B07](#b07) — `CH01-SET-001-ST03_V002.jpg`
- [B08](#b08) — `CH01-SET-001-ST04_V001.jpg`
- [B09](#b09) — `CH01-SET-001-ST04_V002.jpg`
- [B10](#b10) — `CH01-SET-001-ST04_V003.jpg`
- [B11](#b11) — `CH01-SET-001-ST04_V004.jpg`
- [B12](#b12) — `CH01-SET-001-ST05_V001.jpg`
- [B13](#b13) — `CH01-SET-001-ST05_V002.jpg`
- [B14](#b14) — `CH01-SET-001-ST06_V001.jpg`
- [B15](#b15) — `CH01-SET-001-ST06_V002.jpg`
- [B16](#b16) — `CH01-SET-001-ST07_V001.jpg`
- [B17](#b17) — `CH01-SET-001-ST07_V002.jpg`
- [B18](#b18) — `CHAR_ADANNA_TURNAROUND_BACK_V001_REFERENCE_VS_CANDIDATE.jpg`
- [B19](#b19) — `CHAR_ADANNA_TURNAROUND_FRONT_V001_REFERENCE_VS_CANDIDATE.jpg`
- [B20](#b20) — `CHAR_ADANNA_TURNAROUND_LEFT_SIDE_V001_REFERENCE_VS_CANDIDATE.jpg`
- [B21](#b21) — `CHAR_ADANNA_TURNAROUND_THREE_QUARTER_V001_REFERENCE_VS_CANDIDATE.jpg`
- [B22](#b22) — `COSTUME_BREAKDOWN_SHEET_V001_REFERENCE_VS_CANDIDATE.jpg`
- [B23](#b23) — `ENV_CH03-EXP-001_THE_WALL_TOP_WALK_V001.jpg`
- [B24](#b24) — `ENV_CH03-INT-004_THE_FORGOTTEN_KITCHEN_V001.jpg`
- [B25](#b25) — `ENV_CH03-INT-005_A_SLEEPING_ROOM_V001.jpg`
- [B26](#b26) — `ENV_CH03-SUB-005_A_RESIDENTIAL_COURTYARD_V001.jpg`
- [B27](#b27) — `ENV_CH03-SUB-006_THE_BACK_PLOTS_V001.jpg`
- [B28](#b28) — `ENV_CH03-TRV-003_THE_NARROW_PASSAGES_V001.jpg`
- [B29](#b29) — `ENV_CH04-EXP-003_THE_SMALL_ISLANDS_V001.jpg`
- [B30](#b30) — `ENV_CH04-EXP-006_THE_CAVE_BEHIND_THE_LOW_FALLS_V001.jpg`
- [B31](#b31) — `ENV_CH04-INT-001_A_FISHING_SHELTER_V001.jpg`
- [B32](#b32) — `ENV_CH04-INT-002_A_RIVERBANK_HOUSE_V001.jpg`
- [B33](#b33) — `ENV_CH04-INT-003_THE_CANOE_SHED_V001.jpg`
- [B34](#b34) — `ENV_CH04-SET-002_THE_TWO_HOUSE_LANDING_V001.jpg`
- [B35](#b35) — `ENV_CH05-EXP-002_THE_HIDDEN_CAVE_V001.jpg`
- [B36](#b36) — `ENV_CH05-INT-001_THE_HERDERS_SHELTER_V001.jpg`
- [B37](#b37) — `ENV_CH05-INT-002_A_VILLAGE_HOUSE_V001.jpg`
- [B38](#b38) — `ENV_CH05-LMK-002_THE_ABANDONED_WATCHPOST_V001.jpg`
- [B39](#b39) — `ENV_CH05-SET-002_THE_UPPER_HAMLET_V001.jpg`
- [B40](#b40) — `ENV_CH05-SUB-003_THE_CLIMBERS_CAMP_V001.jpg`
- [B41](#b41) — `ENV_CH06-INT-004_A_ROOM_THAT_EXPECTS_YOU_V001.jpg`
- [B42](#b42) — `ENV_CH06-INT-005_THE_FORGOTTEN_ROOM_V001.jpg`
- [B43](#b43) — `PROP_ADANNA_SCABBARD_SIMPLE_LEATHER_V001.jpg`

---

<a id="b01"></a>

# B01 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B01` · **Filename:** `B2_CAND_VR-011_LANDING_OF_UNCLAIMED_V003.jpg`

**Source:** [1s2nj3g1sIoeG_GSOZx80h4gWPAOCii1B](https://drive.google.com/file/d/1s2nj3g1sIoeG_GSOZx80h4gWPAOCii1B/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

VR-011/H3 is independently held on D9/RQ-01 by the current CD record. Fictional framing never waives that gate. Filename/header/Field-of-Cloth subject mapping must not be resolved by visual similarity or version-number assumptions.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1365×768 JPEG; decoded modeRGB. 

- Source:`140648`bytes; MD5`bad276dd99538ff44824240838f8b0fa`; SHA256`6ef2456d4d028bccdae710360b3abc04310d2b34ae99b8b701b799c8fbe8821a`.
- Research:`2774`bytes; MD5`ea97fea41daf553f999184606a23cd86`; SHA256`a524b0120f21f39960af20cf6c9a19230c237fed8a8209bbb5013bd809d2cf19`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B01_B2_CAND_VR-011_LANDING_OF_UNCLAIMED_V003.md](https://drive.google.com/file/d/1Q8GCZgZpZk-fff4Yp5m1sXTXBPF9ejbm/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> An overcast, wet-looking shore of flat grey mud. About a dozen dugout canoes are drawn up on the mud in several rows that recede toward the left. The nearest canoe carries a wrapped cloth bundle tied with cord, a round pot, a rolled dark textile and a paddle. Other canoes carry rolled cloth bundles. A long dark embankment runs along the right of the frame, and tall bamboo-like poles with white hanging strips stand along its foot.

**Published flags (original wording, including any error reconciled below):**

> - CULTURAL READING NOT SUPPORTED: the wrapped bundles could be read as bodies or burial bundles. Nothing in this file establishes that reading, and this report does not make it. The batch-16 text record C09 (ORIGINAL, text) names this image; this report does not rely on C09's wording.
> - UNVERIFIED: the strips are described as white cloth; their material and meaning are not established by the image.
> - ORIGINAL item. The 'VR-011 V003' label is taken from the file name and the C09 record only; approval status is not established here.

## 05. Independent content findings

**Direct source observation:** Grey empty shore, many plain dugout-like canoes carrying rolled/tied textiles, pots and paddle; near boat's tied rectangular load does not visibly establish a human body. Very long dark embankment with tall regular white strip banners; no visible people/text.

**Independent assessment:** Plain vessels/no obvious body silhouette are improvements relevant to VR-011, but cargo identity, white-marker programme and shore setting remain unverified. Source is a distinct ORIGINAL V003, not permission to supersede assistant D07 or settle ritual/cultural gates.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Plain vessels/no obvious body silhouette are improvements relevant to VR-011, but cargo identity, white-marker programme and shore setting remain unverified. Source is a distinct ORIGINAL V003, not permission to supersede assistant D07 or settle ritual/cultural gates.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Plain vessels/no obvious body silhouette are improvements relevant to VR-011, but cargo identity, white-marker programme and shore setting remain unverified. Source is a distinct ORIGINAL V003, not permission to supersede assistant D07 or settle ritual/cultural gates.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

CD/Research supplies the exact VR-011 intended cargo and white-cloth/marker authority and source→V003 record; keep nonfunerary description unless evidence establishes otherwise. No production correction or move authorised by this assessment.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C09 source](https://drive.google.com/file/d/1GbksU93uvNp26nSVs2sx0msW0CNW-acn/view) — archive`assessments/C09.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b02"></a>

# B02 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B02` · **Filename:** `CH01-SET-001-ST01_V001.jpg`

**Source:** [1SLxYu-Fez5qGeo1gpZbILWXy_Y_9WHco](https://drive.google.com/file/d/1SLxYu-Fez5qGeo1gpZbILWXy_Y_9WHco/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`288236`bytes; MD5`6bc96ac39e58b88de89798bef2e3a163`; SHA256`6f7d1cf0457417dc69c790ceaac92bb72e3c780432ccb94354d30b855d2fabc9`.
- Research:`2450`bytes; MD5`193535c7c1f83e03ee715ec1fe2b1555`; SHA256`52acb8b26e6478a20d103f605c71feac3776836786c490e29b4415ab7cfa1434`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B02_CH01-SET-001-ST01_V001.md](https://drive.google.com/file/d/1P_zVqgTOZqB8SIQdFTBHNcytemm4tcUH/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A dawn or dusk view of a walled Home Settlement compound seen from an elevated angle. In the foreground are conical thatched round houses on mud walls; the walls carry blue geometric painted panels. Behind the open yard stands a large thatched rectangular hall with a veranda and smaller thatched towers. Mist sits over the yard. Beyond the compound are fenced fields and a dark forest line under an orange-tinged sky.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED CULTURAL CLAIM: the blue geometric panels are a visual detail of the image. No source in this file ties them to any documented practice, and this report does not claim they are.
> - UNVERIFIED: the thatched hall and towers are the image's depiction; their correspondence to any architectural source is not checked.
> - ORIGINAL item. Its link to any TD rejection is not checked in this report and is not asserted here.

## 05. Independent content findings

**Direct source observation:** Dawn/orange horizon and low mist; large empty plaza bordered by circular conical-roof huts; elaborate back hall/veranda/towers; blue geometric panels and spire-like finials. Source's central shade tree and compound/path composition absent/replaced.

**Independent assessment:** Dawn atmosphere readable but not a source-preserving state; substantial architecture/layout invention, unsourced pattern programme.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Designated source architecture/layout substantially reinvented; not a source-preserving dawn state.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Dawn atmosphere readable but not a source-preserving state; substantial architecture/layout invention, unsourced pattern programme.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Dawn atmosphere readable but not a source-preserving state; substantial architecture/layout invention, unsourced pattern programme.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Designated source architecture/layout substantially reinvented; not a source-preserving dawn state.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Reconcile palace, square tree, compound footprints and route hierarchy against the CD-confirmed source/camera; do not replace with invented local architecture. Obtain OAD-06 review before patterned wall programme. No regeneration authority inferred.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B03 source](https://drive.google.com/file/d/1Rxo6My76m13XUAEVS00M3-bVzMVIxQgb/view) — archive`assessments/B03.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`; [C17 source](https://drive.google.com/file/d/1OE2u-yuZz2IfyF0iVPzUzfkC-YUAzldj/view) — archive`assessments/C17.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b03"></a>

# B03 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B03` · **Filename:** `CH01-SET-001-ST01_V002.jpg`

**Source:** [1Rxo6My76m13XUAEVS00M3-bVzMVIxQgb](https://drive.google.com/file/d/1Rxo6My76m13XUAEVS00M3-bVzMVIxQgb/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`241010`bytes; MD5`9d0b57620ee6bad955ded5e3a8b4befc`; SHA256`22f072b5e8936bf64dc99cc85d347c4d92690fed11af82b3569d01224a593923`.
- Research:`2192`bytes; MD5`e00695636fbe36747739ee29be3e3381`; SHA256`877a095316a1edefdd18bc9cd845679cd9c8aae5e7cbea45624d20dc1e40693e`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B03_CH01-SET-001-ST01_V002.md](https://drive.google.com/file/d/1jL4g6Ghjzk6wy79kBFCTmhqnl-E-Ysi1/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A dawn view across a settlement yard. Several conical thatched round houses with low mud walls stand around the edge; dark cloth hangings cover some doorways. A larger thatched round house with a stepped entrance stands at the back. A tree is at the left edge, banana-type plants sit behind a low wall, and cultivated fields stretch to a misty tree line.

**Published flags (original wording, including any error reconciled below):**

> - COMPARISON NOTE: the V001 of this set (B02) shows blue patterned panels; this V002 does not. The comparison is made from the two images as displayed, not from a pixel diff.
> - UNVERIFIED: whether the dark hangings are cloth or another material is not established by the image.
> - ORIGINAL item; this is the V002 correction in the CH01 set and is not approved.

## 05. Independent content findings

**Direct source observation:** Warm dawn haze; plain earth walls/dark door curtains, circular houses and rear conical principal house. Tree only at left edge; low circular feature near middle; no source-like central spreading tree or palace shape.

**Independent assessment:** Dawn beat and plain dressing visible. The plan/palace/tree differ from the provisional source and other states, but C03 expressly records description-based single shots and accepted camera/geometry variance under a claimed owner override. The originating instruction was not independently located. A pixel-identical camera is NOT imposed here; the actual allowable degree of design/landmark continuity must be confirmed before a correction verdict.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Dawn beat and plain dressing visible. The plan/palace/tree differ from the provisional source and other states, but C03 expressly records description-based single shots and accepted camera/geometry variance under a claimed owner override. The originating instruction was not independently located. A pixel-identical camera is NOT imposed here; the actual allowable degree of design/landmark continuity must be confirmed before a correction verdict.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Dawn beat and plain dressing visible. The plan/palace/tree differ from the provisional source and other states, but C03 expressly records description-based single shots and accepted camera/geometry variance under a claimed owner override. The originating instruction was not independently located. A pixel-identical camera is NOT imposed here; the actual allowable degree of design/landmark continuity must be confirmed before a correction verdict.

**Dependencies:** ORIGINATING_OWNER_OVERRIDE; STATE_SERIES_LANDMARK_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD final-series recommendation for CD to attach the originating Batch10 override and define which palace, tree and compound landmarks must remain common across states. Assess against that scope, not an invented pixel-lock requirement. Preserve older V001 not-approved outcome. No new regeneration or source approval.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B02 source](https://drive.google.com/file/d/1SLxYu-Fez5qGeo1gpZbILWXy_Y_9WHco/view) — archive`assessments/B02.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b04"></a>

# B04 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B04` · **Filename:** `CH01-SET-001-ST02_V001.jpg`

**Source:** [1xSJ6QJBwA2eQsatcYgM_hHBrhEAvz_5d](https://drive.google.com/file/d/1xSJ6QJBwA2eQsatcYgM_hHBrhEAvz_5d/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`401806`bytes; MD5`07497ed4f825d7b58e5e87b0660e298d`; SHA256`92da348191a0ce5d98ec6290ed558fb4dc2b5a62acce26524bdedf11cb64570e`.
- Research:`2302`bytes; MD5`72666023abde58df5084ded6d53249ae`; SHA256`8269c39abbf9e35a6a9b425c8f9a512493651c64e00b2d2b2284e38ec222b3f8`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B04_CH01-SET-001-ST02_V001.md](https://drive.google.com/file/d/1Ah4Yq3RXmAlEcy5m6N4csVpy3EUl2ady/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> An overcast view of a walled compound. A large raised round house with a thatched roof and a double-door entrance stands at the back, with a second rectangular building to its right. Blue patterned bands run along the walls. Two small upright objects stand in the open yard. Fenced fields and a dark forest line lie behind the compound.

**Published flags (original wording, including any error reconciled below):**

> - UNIDENTIFIED OBJECTS: the two upright objects in the yard are not identified by the image. They could be posts, sculptures or figures. This report does not identify them.
> - UNSUPPORTED CULTURAL CLAIM: the blue patterned bands are a visual detail; no source in this file ties them to documented practice.
> - ORIGINAL item; a V001 candidate in the CH01 set, not approved.

## 05. Independent content findings

**Direct source observation:** Grey daytime scene; circular huts, wall patterns and triangular blue bands; elaborate raised back complex. At least two isolated upright marker-like forms in square, one appearing paired. Exact object identity/function cannot be established.

**Independent assessment:** Retain architectural-layout drift and introduced marker-programme finding; Research correctly does not identify upright objects as ritual stones. Scene read not sufficient for approved state.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Architectural reinvention and introduced carved-marker programme; report counting does not resolve retained visual findings.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Retain architectural-layout drift and introduced marker-programme finding; Research correctly does not identify upright objects as ritual stones. Scene read not sufficient for approved state.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Retain architectural-layout drift and introduced marker-programme finding; Research correctly does not identify upright objects as ritual stones. Scene read not sufficient for approved state.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Architectural reinvention and introduced carved-marker programme; report counting does not resolve retained visual findings.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Reconcile source layout/tree/palace and obtain owner/Research decision on introduced upright objects and OAD-06 patterns. No unsupported claim they are sacred, no automatic removal prescription.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B05 source](https://drive.google.com/file/d/1hldnXwv2_grB2Q6YWvQFRPdcIs3dR_h3/view) — archive`assessments/B05.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`; [C17 source](https://drive.google.com/file/d/1OE2u-yuZz2IfyF0iVPzUzfkC-YUAzldj/view) — archive`assessments/C17.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b05"></a>

# B05 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B05` · **Filename:** `CH01-SET-001-ST02_V002.jpg`

**Source:** [1hldnXwv2_grB2Q6YWvQFRPdcIs3dR_h3](https://drive.google.com/file/d/1hldnXwv2_grB2Q6YWvQFRPdcIs3dR_h3/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`342730`bytes; MD5`821dd5b39fcbf60e9caf40ff8059e865`; SHA256`017c02a12b5d3010f591204b464017ca1893e48a7b3568f5bffebb1be3d5d7d7`.
- Research:`2058`bytes; MD5`ffc5669a2d01156ee674a62e6b5401a6`; SHA256`b582e6a081268e7b118f7ea991e43290a137a69ec73f3b926769cbe4c1b68fa8`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B05_CH01-SET-001-ST02_V002.md](https://drive.google.com/file/d/1Es9tbkn1hFq1n1SOpSv50Vu4LtxdSt9R/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> An overcast view of a circular compound. A ring of conical thatched round houses on low mud walls surrounds a bare reddish-brown yard. A large central house with dark door hangings stands at the back. Trees and fields lie beyond the wall line. No blue panels are visible.

**Published flags (original wording, including any error reconciled below):**

> - COMPARISON NOTE: the V001 (B04) shows blue bands and two upright objects in the yard; this V002 shows neither. Comparison is by visual inspection, not a pixel diff.
> - UNVERIFIED: whether the removal of the upright objects is a deliberate correction is not established by the image.
> - ORIGINAL item; a V002 in the CH01 set, not approved.

## 05. Independent content findings

**Direct source observation:** Bare red-earth plaza; plain doors, circular ring of conical houses, enlarged conical back building; no upright square objects or blue wall panels visible. Central source shade tree absent.

**Independent assessment:** Midday/plain-square treatment and absence of conspicuous V001 upright markers are visible. C03 permits varying single-shot cameras as reported; it does not settle shared palace/tree/layout continuity or authenticate new apex details. Originating owner override remains independently unavailable.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Midday/plain-square treatment and absence of conspicuous V001 upright markers are visible. C03 permits varying single-shot cameras as reported; it does not settle shared palace/tree/layout continuity or authenticate new apex details. Originating owner override remains independently unavailable.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Midday/plain-square treatment and absence of conspicuous V001 upright markers are visible. C03 permits varying single-shot cameras as reported; it does not settle shared palace/tree/layout continuity or authenticate new apex details. Originating owner override remains independently unavailable.

**Dependencies:** ORIGINATING_OWNER_OVERRIDE; STATE_SERIES_LANDMARK_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD on intended state-series continuity and source authority. CD confirms allowable plan/palace/central-tree change and apex treatment before any precise correction. No invented cultural identity for small forms, no automatic re-render.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B04 source](https://drive.google.com/file/d/1xSJ6QJBwA2eQsatcYgM_hHBrhEAvz_5d/view) — archive`assessments/B04.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b06"></a>

# B06 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B06` · **Filename:** `CH01-SET-001-ST03_V001.jpg`

**Source:** [1YJqo7pZRuq1hOHpfsiBp9Amiv8SHGJQp](https://drive.google.com/file/d/1YJqo7pZRuq1hOHpfsiBp9Amiv8SHGJQp/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`259222`bytes; MD5`cb43f0277f450bd8cc83e8039d2d8260`; SHA256`dea1eba1333b54a35354c37790b23f40df26c38483ea12bc79cff17af76a87ef`.
- Research:`2049`bytes; MD5`444e04a9ee3d98d2d67cc500c9ddb2d0`; SHA256`3739e7941b87e8accdca3bdcb1441f39097fff430108be5a168e110ef255240f`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B06_CH01-SET-001-ST03_V001.md](https://drive.google.com/file/d/103GIteVgcpx8jqYwsy-_HH5KY1r6nXhF/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A dusk view of a walled compound. Conical thatched round houses stand on mud walls at the front and sides. A large rectangular building with a stepped entrance sits at the back, its walls carrying red-brown and blue triangular and diamond patterns. The sky is orange and violet at the horizon, with a dark forest line and fenced fields behind.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED CULTURAL CLAIM: the triangular and diamond patterns are visual details; no source in this file ties them to documented practice.
> - UNVERIFIED: the building's function is not established by the image.
> - ORIGINAL item; a V001 candidate in the CH01 set, not approved.

## 05. Independent content findings

**Direct source observation:** Orange sunset sky, open plaza, stylized earth fort-like raised rear complex with multiple turrets and diamond/triangle panels; conical huts around edge. Main shade tree absent.

**Independent assessment:** Dusk readable; retained source-layout and architectural reinvention, unsourced motifs.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Palace/compound redesign rather than a source-preserving dusk state.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Dusk readable; retained source-layout and architectural reinvention, unsourced motifs.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Dusk readable; retained source-layout and architectural reinvention, unsourced motifs.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Palace/compound redesign rather than a source-preserving dusk state.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Against confirmed Home Settlement source, reconcile palace silhouette, square tree and compound topology; keep dusk treatment and qualify motifs under OAD-06, without cultural-authentication claims.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B07 source](https://drive.google.com/file/d/1j03tjjtHXt6s5iHJfgJS3M_j17aNmiMg/view) — archive`assessments/B07.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`; [C17 source](https://drive.google.com/file/d/1OE2u-yuZz2IfyF0iVPzUzfkC-YUAzldj/view) — archive`assessments/C17.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b07"></a>

# B07 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B07` · **Filename:** `CH01-SET-001-ST03_V002.jpg`

**Source:** [1j03tjjtHXt6s5iHJfgJS3M_j17aNmiMg](https://drive.google.com/file/d/1j03tjjtHXt6s5iHJfgJS3M_j17aNmiMg/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`245080`bytes; MD5`5e5bb058fdd761d859fda2d95cabb68e`; SHA256`5601f89c4d8707daae6ee80eea5e1d97cff533809776fb1b0624574e140dfcb7`.
- Research:`2294`bytes; MD5`26d0deefaf8f8313431f14d87740de8f`; SHA256`0c9acdf8334225e3afd575d2826f1b01c7866634ae115dd06cb1d46886dfe92c`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B07_CH01-SET-001-ST03_V002.md](https://drive.google.com/file/d/1ZGNfJYR3YHaG5TLM3PMqWL5d15aVB49N/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A sunset view of a walled compound (1536x1024). Conical thatched round houses on mud walls stand around a bare reddish yard; several doorways are covered with dark cloth and some show small lamps. A large rectangular thatched hall with a raised stepped approach and two cylindrical mud towers sits at the back right. Fields and a tree line lie beyond the compound under an orange-violet sky.

**Published flags (original wording, including any error reconciled below):**

> - UNVERIFIED: the cylindrical towers are the image's depiction; they are not checked against any architectural source. The architectural form is flagged against the off-idiom architecture findings in C10–C14.
> - UNVERIFIED: the lamps are depicted light sources; their use is not established.
> - ORIGINAL item; a V002 correction in the CH01 set, not approved.

## 05. Independent content findings

**Direct source observation:** Orange low sun, broad bare plaza; rear rectangular hall flanked by tall cylindrical conical-capped towers; plain doorway cloth and small warm light points. No blue panels visible; source shade tree missing.

**Independent assessment:** Dusk and simplified cloth are present; tall capped towers differ from the provisional source and other states. C03 itself flags architectural elaboration and asserts accepted camera variance. Camera mismatch alone is not a failure under an unverified claimed exception; tower/material/source continuity still needs CD scope.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Dusk and simplified cloth are present; tall capped towers differ from the provisional source and other states. C03 itself flags architectural elaboration and asserts accepted camera variance. Camera mismatch alone is not a failure under an unverified claimed exception; tower/material/source continuity still needs CD scope.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Dusk and simplified cloth are present; tall capped towers differ from the provisional source and other states. C03 itself flags architectural elaboration and asserts accepted camera variance. Camera mismatch alone is not a failure under an unverified claimed exception; tower/material/source continuity still needs CD scope.

**Dependencies:** ORIGINATING_OWNER_OVERRIDE; STATE_SERIES_LANDMARK_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD final recommendation until CD confirms allowed palace/tower/landmark continuity in the originating owner instruction. Do not demand pixel identity or invent a cultural tower type. No new correction assignment.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B06 source](https://drive.google.com/file/d/1YJqo7pZRuq1hOHpfsiBp9Amiv8SHGJQp/view) — archive`assessments/B06.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b08"></a>

# B08 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B08` · **Filename:** `CH01-SET-001-ST04_V001.jpg`

**Source:** [1r5SIMNFxa1CRTgFnA-4yugnvykBBch4F](https://drive.google.com/file/d/1r5SIMNFxa1CRTgFnA-4yugnvykBBch4F/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`271613`bytes; MD5`413ca01877b799dada63ade40dc3ebf2`; SHA256`b9cff30f47082ef6416b615789ed369a4291a46e3347bc247e17c63859dbb4e5`.
- Research:`2453`bytes; MD5`ba236978989d1eda961be0008dab56dc`; SHA256`259f356936a51b83c5823d3ed1e166b4c610e0f0c4db193c2b95f1440b3638b9`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B08_CH01-SET-001-ST04_V001.md](https://drive.google.com/file/d/163qR6I_wt_91aEv_VG4R9DYrAE3X1uZB/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A night view (1536x1024) of a compound under a starry sky. At the back stands a tall multi-tier building with a pointed upper tower, pinnacle finials along its roofline and blue geometric panels on its walls. Conical thatched round houses with blue cloth on their doorways surround the yard. Upright stakes form a fence in the foreground, and a dense field of stakes or poles lies beyond.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED ARCHITECTURE: the tall pinnacled tower and roofline finials are not supported by any source in this file. They are flagged for review against the off-idiom architecture findings in C10–C14.
> - UNSUPPORTED CULTURAL CLAIM: the blue geometric panels are a visual detail; no source in this file ties them to documented practice.
> - UNVERIFIED: the boulders and stake fence are depicted elements; their purpose is not established.
> - ORIGINAL item; the V001 of the ST04 set, not approved.

## 05. Independent content findings

**Direct source observation:** Starry blue night; tall multi-tier central tower with pointed buttress/finial programme, blue geometric bands, conical houses and foreground stakes/rocks. No source central shade tree.

**Independent assessment:** Night treatment does not justify new multi-tier palace or changed layout; retained V001 finding.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Multi-tiered tower architecture replaces the designated source; not a night-only treatment.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Night treatment does not justify new multi-tier palace or changed layout; retained V001 finding.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Night treatment does not justify new multi-tier palace or changed layout; retained V001 finding.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Multi-tiered tower architecture replaces the designated source; not a night-only treatment.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Reconcile palace/compound/tree geometry with confirmed source, and seek OAD-06/architecture decisions for new decorative programme. No assumed cultural origin.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B09 source](https://drive.google.com/file/d/1YF2yq80Bxzz9wGOn7C4GzkzaFgApJqe-/view) — archive`assessments/B09.md`; [B10 source](https://drive.google.com/file/d/1IhgfuIFZ5wOj4Wb0KpTrYQcyj57nT9Pz/view) — archive`assessments/B10.md`; [B11 source](https://drive.google.com/file/d/1npYn0kJB2FFjTxPyGdACAsCqKk8ZbDPq/view) — archive`assessments/B11.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`; [C17 source](https://drive.google.com/file/d/1OE2u-yuZz2IfyF0iVPzUzfkC-YUAzldj/view) — archive`assessments/C17.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b09"></a>

# B09 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B09` · **Filename:** `CH01-SET-001-ST04_V002.jpg`

**Source:** [1YF2yq80Bxzz9wGOn7C4GzkzaFgApJqe-](https://drive.google.com/file/d/1YF2yq80Bxzz9wGOn7C4GzkzaFgApJqe-/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`236945`bytes; MD5`2e516f43275009955061cfcc25ed23c6`; SHA256`4902019cdd75dfce93bea8f853999572f2be44a2dcdf483f927ce09f52b8d653`.
- Research:`2438`bytes; MD5`64c7f375692a3e38a6b926d2793af34c`; SHA256`b80c03dbd3e9084f4fdc8901713b073b3884ea27d1c5cf69f5502a2aa42bdbd2`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B09_CH01-SET-001-ST04_V002.md](https://drive.google.com/file/d/1hd4JB0V9GlE3uN1UoiApLIEPoHas9nSe/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A night view (1536x1024) under a crescent moon. A two-storey-looking rectangular mud building with a thatched roof stands at the back, with a dark blue door and two small lit windows. Conical thatched round houses line the yard. A low curved mud wall runs across the foreground with a blue cloth hanging at a gateway. A ring of rounded stones lies on the open yard in the centre.

**Published flags (original wording, including any error reconciled below):**

> - CENTRAL STONE RING UNIDENTIFIED: the ring of stones in the centre is not identified by this image. A fire-ring ruling is pending in the research record and this report does not make it. Its function is not established.
> - CONSISTENCY NOTE: the earlier record notes that the blue patterned panels in ST04 V001 do not carry into V002. This frame shows the same absence; it is recorded, not independently re-verified against V001 here.
> - ORIGINAL item; the V002 of the ST04 set, not approved.

## 05. Independent content findings

**Direct source observation:** Blue moonlit courtyard, broad half-lit moon, circular conical houses, two-level-looking rear house, low foreground wall/gateway. A low closed ring of rounded stones is plainly visible near centre; dark middle but no clear functional proof. Stone cluster bottom-left.

**Independent assessment:** Ring identity/function remains unknown. No basis to call it definitely a fire ring or ritual stone circle, or to clear the pending ruling. Layout/palace/tree also differ from provisional source.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Ring identity/function remains unknown. No basis to call it definitely a fire ring or ritual stone circle, or to clear the pending ruling. Layout/palace/tree also differ from provisional source.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Ring identity/function remains unknown. No basis to call it definitely a fire ring or ritual stone circle, or to clear the pending ruling. Layout/palace/tree also differ from provisional source.

**Dependencies:** ST04_RING_FUNCTION; SOURCE_COMPOSITION_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. HOLD identity/brief judgement on ring: Research supplies contextual construction/function evidence and CD rules on intended role/retention. Do not invent its function or prescribe automatic removal. Separately reconcile source geometry once scope confirmed.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B08 source](https://drive.google.com/file/d/1r5SIMNFxa1CRTgFnA-4yugnvykBBch4F/view) — archive`assessments/B08.md`; [B10 source](https://drive.google.com/file/d/1IhgfuIFZ5wOj4Wb0KpTrYQcyj57nT9Pz/view) — archive`assessments/B10.md`; [B11 source](https://drive.google.com/file/d/1npYn0kJB2FFjTxPyGdACAsCqKk8ZbDPq/view) — archive`assessments/B11.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`; [C05 source](https://drive.google.com/file/d/1ei3sAwJ6AQ3CU3fCAZ8FqR2JldJWRc8y/view) — archive`assessments/C05.md`; [C06 source](https://drive.google.com/file/d/14JDeODzhfPwOuCgXPezYYMlyjMGGdC-N/view) — archive`assessments/C06.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b10"></a>

# B10 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B10` · **Filename:** `CH01-SET-001-ST04_V003.jpg`

**Source:** [1IhgfuIFZ5wOj4Wb0KpTrYQcyj57nT9Pz](https://drive.google.com/file/d/1IhgfuIFZ5wOj4Wb0KpTrYQcyj57nT9Pz/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1264×843 JPEG; decoded modeRGB. 

- Source:`157784`bytes; MD5`109c6ea79bedd7d2d629aca2dda22a05`; SHA256`300484f18b744874505b2b2d83c468ea7cf58abb2c1f5543a70ac110630e9332`.
- Research:`2138`bytes; MD5`ec69908d541f3f2a93716861d434e759`; SHA256`2342eeb9ecae8bbf2ad02d24eda51a107a2e78321bc2167463fbf3f2fa399b3e`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B10_CH01-SET-001-ST04_V003.md](https://drive.google.com/file/d/1K0FPmdKMODU_tHRp30s0avJiCaQ_y7o3/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A night view (1264x843) under a crescent moon, with a composition close to ST04 V002. A mud building with a thatched roof and blue doors stands at the back; conical thatched round houses ring the yard, with lit windows on some. A low curved wall runs across the foreground with a thatched hut set on it. The yard is open earth.

**Published flags (original wording, including any error reconciled below):**

> - COMPARISON NOTE: this frame and ST04 V002 (B09) share a layout; the stone ring visible in B09 is absent here. The comparison is by visual inspection only.
> - UNVERIFIED: whether the difference is a deliberate correction is not established by the image.
> - ORIGINAL item; a V003 in the ST04 set, not approved.

## 05. Independent content findings

**Direct source observation:** Night scene resembling B09 at 1264x843. Centre of square now bare; broad wall/foreground hut and scene layout remain. No central ring visible.

**Independent assessment:** Current native1264x843 and broad ring/cluster/gateway/curtain removal direction are directly supported. C05 discloses generative changes from B09 V002, not exact outside-mask preservation; B11 is a later distinct V004. Original owner instruction and ring function remain unverified.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Current native1264x843 and broad ring/cluster/gateway/curtain removal direction are directly supported. C05 discloses generative changes from B09 V002, not exact outside-mask preservation; B11 is a later distinct V004. Original owner instruction and ring function remain unverified.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Current native1264x843 and broad ring/cluster/gateway/curtain removal direction are directly supported. C05 discloses generative changes from B09 V002, not exact outside-mask preservation; B11 is a later distinct V004. Original owner instruction and ring function remain unverified.

**Dependencies:** ST04_RING_FUNCTION remains open for B09; DELIVERY_RESOLUTION

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve superseded V003 and use B11 for current technical/removal-scope decision. Do not demand native1536 detail from this1264 output or infer that ring absence settles identity.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B08 source](https://drive.google.com/file/d/1r5SIMNFxa1CRTgFnA-4yugnvykBBch4F/view) — archive`assessments/B08.md`; [B09 source](https://drive.google.com/file/d/1YF2yq80Bxzz9wGOn7C4GzkzaFgApJqe-/view) — archive`assessments/B09.md`; [B11 source](https://drive.google.com/file/d/1npYn0kJB2FFjTxPyGdACAsCqKk8ZbDPq/view) — archive`assessments/B11.md`; [C05 source](https://drive.google.com/file/d/1ei3sAwJ6AQ3CU3fCAZ8FqR2JldJWRc8y/view) — archive`assessments/C05.md`; [C06 source](https://drive.google.com/file/d/14JDeODzhfPwOuCgXPezYYMlyjMGGdC-N/view) — archive`assessments/C06.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b11"></a>

# B11 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B11` · **Filename:** `CH01-SET-001-ST04_V004.jpg`

**Source:** [1npYn0kJB2FFjTxPyGdACAsCqKk8ZbDPq](https://drive.google.com/file/d/1npYn0kJB2FFjTxPyGdACAsCqKk8ZbDPq/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`319754`bytes; MD5`766ce2bfed229421627323b8c7ba3c70`; SHA256`2e2eba64a5e19747b1349d933515cb1777ac2f7e75a85246c09f98375d665a3b`.
- Research:`2014`bytes; MD5`b13386ac46dd7e53c09f0b37d0609155`; SHA256`7f6c2e8162253f8ab72097ab1939835a3ae086ce5caf8d9af0fe8d6cb4c50a53`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B11_CH01-SET-001-ST04_V004.md](https://drive.google.com/file/d/1IFIggqUR4iEyAsbpOaITEqogaqd9sUds/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A night view (1536x1024) under a crescent moon, closely matching the layout of ST04 V003 (B10). A mud building with a thatched roof and blue doors stands at the back. Conical thatched round houses ring the yard, and a low curved wall with a thatched hut crosses the foreground. No central stone ring is visible.

**Published flags (original wording, including any error reconciled below):**

> - COMPARISON NOTE: the layout matches V003 (B10) at a different frame size (1536x1024 versus 1264x843). Comparison is by visual inspection only.
> - UNVERIFIED: the relationship between V003 and V004 (for example whether V004 is a re-render) is not established by the image.
> - ORIGINAL item; a V004 in the ST04 set, not approved.

## 05. Independent content findings

**Direct source observation:** 1536x1024 night courtyard, visually close to B10; bare central plaza, low foreground wall/hut, plain dark blue curtains and rear tall principal house. No central ring visible.

**Independent assessment:** The ring-free centre and removal direction are visible. C06 explicitly records a three-pass generative edit from V002, native1264x843 LANCZOS-resampled1536x1024, with residual geometry/lighting/niche caveats. This is not a native1536x1024 rerender or proven surgical preservation. No ring-function ruling can be inferred from its absence.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

The ring-free centre and removal direction are visible. C06 explicitly records a three-pass generative edit from V002, native1264x843 LANCZOS-resampled1536x1024, with residual geometry/lighting/niche caveats. This is not a native1536x1024 rerender or proven surgical preservation. No ring-function ruling can be inferred from its absence.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** The ring-free centre and removal direction are visible. C06 explicitly records a three-pass generative edit from V002, native1264x843 LANCZOS-resampled1536x1024, with residual geometry/lighting/niche caveats. This is not a native1536x1024 rerender or proven surgical preservation. No ring-function ruling can be inferred from its absence.

**Dependencies:** ORIGINATING_REMOVAL_SCOPE; RESAMPLED_DELIVERY_ACCEPTANCE; ST04_RING_IDENTITY_REMAINS_HISTORICAL

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD technical and exact four-removal/preservation acceptance; CD reviews native-versus-resampled delivery and residual junction/edge crop against the originating narrow removal instruction. Do not add new removals, rebuild source geometry or identify specks/niche as ritual features without marked evidence. Preserve V002/V003 and ring identity question; no work executed.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B08 source](https://drive.google.com/file/d/1r5SIMNFxa1CRTgFnA-4yugnvykBBch4F/view) — archive`assessments/B08.md`; [B09 source](https://drive.google.com/file/d/1YF2yq80Bxzz9wGOn7C4GzkzaFgApJqe-/view) — archive`assessments/B09.md`; [B10 source](https://drive.google.com/file/d/1IhgfuIFZ5wOj4Wb0KpTrYQcyj57nT9Pz/view) — archive`assessments/B10.md`; [C05 source](https://drive.google.com/file/d/1ei3sAwJ6AQ3CU3fCAZ8FqR2JldJWRc8y/view) — archive`assessments/C05.md`; [C06 source](https://drive.google.com/file/d/14JDeODzhfPwOuCgXPezYYMlyjMGGdC-N/view) — archive`assessments/C06.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b12"></a>

# B12 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B12` · **Filename:** `CH01-SET-001-ST05_V001.jpg`

**Source:** [1KyoNo4wBHp6GG_2Ad2MdYew-cKLYHpaz](https://drive.google.com/file/d/1KyoNo4wBHp6GG_2Ad2MdYew-cKLYHpaz/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`346760`bytes; MD5`21e3d3c81b72e698e34de772a690bf16`; SHA256`a39f7716c0129a191f8082c623cd585623eba88c184234d9ab8e33ea6555a611`.
- Research:`2504`bytes; MD5`3247e76f81583f4089c9c756f0006da0`; SHA256`76abc9db4b876957f4671cc6dd721377114f8ca905668d79a9ff922986f4d8ee`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B12_CH01-SET-001-ST05_V001.md](https://drive.google.com/file/d/15oGrDs8ROcnMmq1leL869BrGtob4T8mW/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A rainstorm view (1536x1024) of a walled compound. Wet, reflective mud fills the yard. A large thatched rectangular building with a raised entrance and a dark doorway, blue cloth hangings, and tall pointed finials sits at the back right. Conical thatched round houses with blue cloth on their walls stand around the edge. A dense field of upright stakes lies behind the compound under a dark sky with a shaft of light.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED ARCHITECTURE: the pointed finials and the crown-like roof finial are not supported by any source in this file. They are flagged for review against the off-idiom architecture findings in C10–C14.
> - UNSUPPORTED CULTURAL CLAIM: the blue cloth hangings are a visual detail; no source in this file ties them to documented practice.
> - UNVERIFIED: the rain and wet-ground effects are depicted; they carry no evidential weight here.
> - ORIGINAL item; the V001 of the ST05 set, not approved.

## 05. Independent content findings

**Direct source observation:** Heavy rain, puddled square; elaborate raised rear complex with finials, patterned blue hangings, repeating round huts and dense background stake field. Central shade tree absent.

**Independent assessment:** Rain is clear, but retained source-palace/compound/tree drift; roof finials/patterns unsourced; no unsupported historical claim.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Palace silhouette, compound placement and square composition reinvented rather than preserving source in rain.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Rain is clear, but retained source-palace/compound/tree drift; roof finials/patterns unsourced; no unsupported historical claim.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Rain is clear, but retained source-palace/compound/tree drift; roof finials/patterns unsourced; no unsupported historical claim.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Palace silhouette, compound placement and square composition reinvented rather than preserving source in rain.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Reconcile source layout and building silhouettes to confirmed direction; separately get dressing/standing-water extent and motif clearance rather than inventing drainage engineering.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B13 source](https://drive.google.com/file/d/1X-eO-Svbzo46ozPXbsE-JpT4SEfWMgOw/view) — archive`assessments/B13.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`; [C17 source](https://drive.google.com/file/d/1OE2u-yuZz2IfyF0iVPzUzfkC-YUAzldj/view) — archive`assessments/C17.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b13"></a>

# B13 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B13` · **Filename:** `CH01-SET-001-ST05_V002.jpg`

**Source:** [1X-eO-Svbzo46ozPXbsE-JpT4SEfWMgOw](https://drive.google.com/file/d/1X-eO-Svbzo46ozPXbsE-JpT4SEfWMgOw/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`349340`bytes; MD5`d4312825d677faf65863186c5249c0f0`; SHA256`4e21d61db1974b95a2453dc0c00ecd13a27cfcf6e105ff218a43e24323cba925`.
- Research:`2213`bytes; MD5`c900f152bdae0c6b63110e6017fe760c`; SHA256`1909d839045f372027a9d2d7396f573c9bcb9cf6dcfde7bdb5b44b19c319331e`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B13_CH01-SET-001-ST05_V002.md](https://drive.google.com/file/d/1sk3yIpIzeFrownI4CGmX49E1U5_9XudK/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A rain view  of a waterlogged compound. The yard is a flooded reddish pool. Conical thatched round houses with dark doorway cloths stand on the left and right, and a low mud wall runs along the foreground. A large rectangular thatched hall with a shallow step and dark doorway sits at the back, with a line of small round houses on each side. Trees and fields lie beyond under a dark sky.

**Published flags (original wording, including any error reconciled below):**

> - UNVERIFIED: the standing water and rain are depicted effects; they carry no evidential weight here.
> - COMPARISON NOTE: this is the V002 of ST05; the V001 (B12) shows a different camera position and a finialed back building. Comparison is by visual inspection only.
> - ORIGINAL item; the V002 of the ST05 set, not approved.

## 05. Independent content findings

**Direct source observation:** Sheet rain; large reflective pool over almost whole plaza; plain dark curtains, rear low rectangular hall, round thatched houses and foreground earth-wall occluder. No blue geometric wall panels visible.

**Independent assessment:** Rain and flooded square are visible, with simpler unpatterned cloth. C03 reports that varying cameras are accepted, so foreground-wall camera difference alone is not rejected. Allowed flooding extent and common palace/tree/compound design remain unresolved against the provisional establishing source.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Rain and flooded square are visible, with simpler unpatterned cloth. C03 reports that varying cameras are accepted, so foreground-wall camera difference alone is not rejected. Allowed flooding extent and common palace/tree/compound design remain unresolved against the provisional establishing source.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Rain and flooded square are visible, with simpler unpatterned cloth. C03 reports that varying cameras are accepted, so foreground-wall camera difference alone is not rejected. Allowed flooding extent and common palace/tree/compound design remain unresolved against the provisional establishing source.

**Dependencies:** ORIGINATING_OWNER_OVERRIDE; STATE_SERIES_LANDMARK_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD final-series acceptance pending CD's actual shared-landmark/flood-state scope and originating override. No invented hydrology, drainage standard, universal layout pixel-lock or regeneration.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B12 source](https://drive.google.com/file/d/1KyoNo4wBHp6GG_2Ad2MdYew-cKLYHpaz/view) — archive`assessments/B12.md`; [C03 source](https://drive.google.com/file/d/1B0qMXM87r7vP5kBahTCckDRXdz70JLmm/view) — archive`assessments/C03.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b14"></a>

# B14 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B14` · **Filename:** `CH01-SET-001-ST06_V001.jpg`

**Source:** [1cKZa4flUbjidGKo5dHZECfJF9hf75RdW](https://drive.google.com/file/d/1cKZa4flUbjidGKo5dHZECfJF9hf75RdW/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`462460`bytes; MD5`8728ea412a71967e07656de28b59710d`; SHA256`87e42ed3498911d06301c36aa4f9359a0424d0a1f4e358ba53d45548228f3ad8`.
- Research:`2372`bytes; MD5`b9cab4d722c4b8cf41110e9739153695`; SHA256`244bd201553b8da8542aa613dc3daffa2cf9176ff8dfbfeb896a21753a9c10fe`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B14_CH01-SET-001-ST06_V001.md](https://drive.google.com/file/d/1QFB1xhdHuzrtz5zA7eCaGsX6BlrF3bIi/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A daytime market scene  on bare reddish-brown earth. Tarpaulin and thatch canopies shade stalls of tomatoes, leafy greens, yams, and sorted baskets. Many people are at the stalls and walking between them. A wheelbarrow stands near the centre and a dark metal charcoal stove sits in the foreground. Corrugated-metal-roofed buildings line the back of the market. A large tree stands at the upper right.

**Published flags (original wording, including any error reconciled below):**

> - PERIOD AND SETTING NOT ESTABLISHED: corrugated metal roofs, tarpaulins and modern clothing are shown. Whether they fit the Chapter 1 setting is not established here; flagged for the research base.
> - UNVERIFIED: the market's location is not identified by the image.
> - ORIGINAL item; the V001 of the ST06 set, not approved. Its photographic style is noted; it is not treated as a reference.

## 05. Independent content findings

**Direct source observation:** Photographic-style crowded food market, corrugated metal roofs, tarpaulin-like covers, shirts/trousers/T-shirts, wheelbarrow and dark metal stoves. Foreground women wear patterned wrappers. No readable source-square/palace continuity.

**Independent assessment:** Photoreal contemporary market/context and patterned cloth are directly visible. C04 expressly claims owner cultural guidance; C07 supersedes this V001. Without the originating guidance, a global period/material or photoreal-style prohibition is not established. Textile and intended Home Settlement-state continuity remain unverified, not authenticated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Photoreal contemporary market/context and patterned cloth are directly visible. C04 expressly claims owner cultural guidance; C07 supersedes this V001. Without the originating guidance, a global period/material or photoreal-style prohibition is not established. Textile and intended Home Settlement-state continuity remain unverified, not authenticated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Photoreal contemporary market/context and patterned cloth are directly visible. C04 expressly claims owner cultural guidance; C07 supersedes this V001. Without the originating guidance, a global period/material or photoreal-style prohibition is not established. Textile and intended Home Settlement-state continuity remain unverified, not authenticated.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve V001 as superseded evidence; assess B15 under the actual originating context decision when supplied. No V001 redo, blanket period ban or unsupported locality claim.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B15 source](https://drive.google.com/file/d/1TBXHgJlUmmbMWcMhG9PQn0eS07bdbum9/view) — archive`assessments/B15.md`; [C04 source](https://drive.google.com/file/d/1y2nF2o_KEALA29pJyfjU7oF-aQaXm1Y-/view) — archive`assessments/C04.md`; [C07 source](https://drive.google.com/file/d/1mRYoJ71IRUz3HS1G19luJMFCJxjv3-th/view) — archive`assessments/C07.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b15"></a>

# B15 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B15` · **Filename:** `CH01-SET-001-ST06_V002.jpg`

**Source:** [1TBXHgJlUmmbMWcMhG9PQn0eS07bdbum9](https://drive.google.com/file/d/1TBXHgJlUmmbMWcMhG9PQn0eS07bdbum9/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`344781`bytes; MD5`1bea08e784023a5a0c526bf3eca050f1`; SHA256`a4c915f241ad0bbf1cf46812961f5ba80c416d04c006947e30410ca93081186e`.
- Research:`2224`bytes; MD5`33a7a166f2ae36e1158994169eb4b8c0`; SHA256`4e09a15fd9eb33de1644d6faff976bff86f0945422c7cc4c31fbdae5a4c1cf12`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B15_CH01-SET-001-ST06_V002.md](https://drive.google.com/file/d/18k-axnu8KJy5Wil_rRfViYsMRcU1SQIy/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly rendering  of a market on reddish earth under a grey cloudy sky. Tarpaulin and dark sheet canopies shade stalls of onions, tomatoes, dried fish, yams and baskets. Figures walk between stalls and tend the tables. Low mud-and-metal-roofed buildings sit behind. A woman in a cream top bends at a basket on the right.

**Published flags (original wording, including any error reconciled below):**

> - STYLE PAIR: this is the painterly counterpart of the market in B14. Layout correspondence is by visual inspection only.
> - PERIOD AND SETTING NOT ESTABLISHED: the metal roofs and modern dress are flagged as in B14.
> - UNVERIFIED: whether the painterly version is the approved style is not established by the image; the research record is not checked here.

## 05. Independent content findings

**Direct source observation:** Painterly/textured market with food stalls, plastic/tarpaulin-looking canopies and corrugated roofs; short-sleeve collared shirts and shorts/trousers. Layout and main figures are not identical to B14.

**Independent assessment:** Painterly/plain-textile direction relative to B14 is visible, while metal/tarpaulin-like roofs and contemporary clothing remain. C07 deliberately describes a laterite/metal-roof, Nsukka-derived context under owner Cultural-Guidance Decisions. Those originating decisions were not independently located; do NOT declare a binding global period/material prohibition if the owner intentionally selected this context. The old Home Settlement source is not proven continuous and Nsukka attribution is not authenticated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Painterly/plain-textile direction relative to B14 is visible, while metal/tarpaulin-like roofs and contemporary clothing remain. C07 deliberately describes a laterite/metal-roof, Nsukka-derived context under owner Cultural-Guidance Decisions. Those originating decisions were not independently located; do NOT declare a binding global period/material prohibition if the owner intentionally selected this context. The old Home Settlement source is not proven continuous and Nsukka attribution is not authenticated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Painterly/plain-textile direction relative to B14 is visible, while metal/tarpaulin-like roofs and contemporary clothing remain. C07 deliberately describes a laterite/metal-roof, Nsukka-derived context under owner Cultural-Guidance Decisions. Those originating decisions were not independently located; do NOT declare a binding global period/material prohibition if the owner intentionally selected this context. The old Home Settlement source is not proven continuous and Nsukka attribution is not authenticated.

**Dependencies:** ORIGINATING_OWNER_CULTURAL_GUIDANCE; INTENDED_MODERN_CONTEXT_VS_PARENT_STATE; OAD-55/56

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD intended-use/owner-exception and textile acceptance. CD supplies the actual ST06 guidance and confirms whether this is a contemporary contextual exploration or a state of the older Home Settlement model; Research scopes locality/material claims. No blanket photoreal ban, automatic crowd correction or replacement generation.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B14 source](https://drive.google.com/file/d/1cKZa4flUbjidGKo5dHZECfJF9hf75RdW/view) — archive`assessments/B14.md`; [C04 source](https://drive.google.com/file/d/1y2nF2o_KEALA29pJyfjU7oF-aQaXm1Y-/view) — archive`assessments/C04.md`; [C07 source](https://drive.google.com/file/d/1mRYoJ71IRUz3HS1G19luJMFCJxjv3-th/view) — archive`assessments/C07.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b16"></a>

# B16 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B16` · **Filename:** `CH01-SET-001-ST07_V001.jpg`

**Source:** [1sixVQ4I9wsgJbEOSfssCVsXRcrIG3x7R](https://drive.google.com/file/d/1sixVQ4I9wsgJbEOSfssCVsXRcrIG3x7R/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`367460`bytes; MD5`5502ac4ae09d35f3734bd206bab25a65`; SHA256`694684263f47e76e00f4f0978ce1e72ac9de2a839e58b1078be0553f67228216`.
- Research:`2153`bytes; MD5`eac441b3e45509f42835933ce9fef493`; SHA256`c70ffb7fbe31381a04c9dc8c0641b9c4395ed9226174de8082d6fe6ebbae60b6`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B16_CH01-SET-001-ST07_V001.md](https://drive.google.com/file/d/1TRKDglbWWUTnCUMNcyQwAzMirY-TtX6C/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A daytime photographic view  of a community meeting. About twenty people sit on wooden benches in a rough circle under a large tree. A man in a light shirt speaks with open hands in the centre-left; others stand at the edge. Rusted corrugated roofs and mud-walled houses stand behind, with banana plants to the left.

**Published flags (original wording, including any error reconciled below):**

> - PERIOD AND SETTING NOT ESTABLISHED: modern dress and corrugated metal roofs are shown; their fit to the Chapter 1 setting is flagged for the research base.
> - UNVERIFIED: the gathering's purpose or role (for example a council, a court, or a meeting) is not established by the image; no label is legible.
> - ORIGINAL item; the V001 of the ST07 set, not approved.

## 05. Independent content findings

**Direct source observation:** Photographic-style seated gathering under tree; corrugated roofs on earth houses, collared shirts/T-shirts/trousers, patterned wrappers/headwraps; benches and central speaker. No identifiable ritual shown.

**Independent assessment:** Generic non-ritual assembly with contemporary clothing/metal roofs is visible. C04 claims owner context guidance and C07 supersedes this V001. Do not diagnose ceremony or reject solely by assuming an unverified period restriction; OAD55/56 and exact state-model context remain unconfirmed.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Generic non-ritual assembly with contemporary clothing/metal roofs is visible. C04 claims owner context guidance and C07 supersedes this V001. Do not diagnose ceremony or reject solely by assuming an unverified period restriction; OAD55/56 and exact state-model context remain unconfirmed.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Generic non-ritual assembly with contemporary clothing/metal roofs is visible. C04 claims owner context guidance and C07 supersedes this V001. Do not diagnose ceremony or reject solely by assuming an unverified period restriction; OAD55/56 and exact state-model context remain unconfirmed.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve V001 as superseded evidence; current B17 needs actual owner-guidance scope, not invented ritual correction or automatic regeneration.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B17 source](https://drive.google.com/file/d/1_Lw07vpd0aOo0XnI7-xrbWZTWhypg7vU/view) — archive`assessments/B17.md`; [C04 source](https://drive.google.com/file/d/1y2nF2o_KEALA29pJyfjU7oF-aQaXm1Y-/view) — archive`assessments/C04.md`; [C07 source](https://drive.google.com/file/d/1mRYoJ71IRUz3HS1G19luJMFCJxjv3-th/view) — archive`assessments/C07.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b17"></a>

# B17 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B17` · **Filename:** `CH01-SET-001-ST07_V002.jpg`

**Source:** [1_Lw07vpd0aOo0XnI7-xrbWZTWhypg7vU](https://drive.google.com/file/d/1_Lw07vpd0aOo0XnI7-xrbWZTWhypg7vU/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-SET-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Adanna's home community: compounds, a square, a market and the palace of Ezeani, enclosed by gates.
> - Architecture: Family compounds of mud-walled houses round courtyards, steep palm-thatch roofs, carved doors, painted walls (documented forms).
> - Materials: Laterite mud, hardwood, bamboo, palm thatch, raffia.
> - Lighting: Warm daylight, hearth light at night.
> **Required assets.** Compound house kit, walls, gates, square, market, palace.
> **Notes.** Recorded from the original brief's settlement list. Chapter placement is PENDING DESIGN; listed under Chapter 1 because Adanna leaves home for the forest. Exact wording of the brief to be confirmed by the client. Parent entry for the settlement locations below. VILLAGER CLOTHING (OAD-55, proposed production standard pending visual approval): ordinary adult villagers wear a recognisable torso-covering garment, varied from person to person; no bare chests and no shoulder-only cloths by default; palace guards keep their own uniform. A production decision for the game, not a statement about historical dress.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1536×1024 JPEG; decoded modeRGB. 

- Source:`388491`bytes; MD5`ca1ce79791caba1536354836f554abce`; SHA256`15863690c940e0a67d502b4106a3101370714c732e11855718cd7bb2b66c7495`.
- Research:`2132`bytes; MD5`ddb28ca0c611fc243e4ceaaf3357123e`; SHA256`8892113f164b791938ec410cbe0490e05145a4ec4c657e8343e1f672975816c4`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B17_CH01-SET-001-ST07_V002.md](https://drive.google.com/file/d/1DSFkzpraf9IPWB3P8bTj1o7y7LjO4qMC/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly rendering  of the same kind of gathering as B16: a circle of seated people under a large tree, with a central speaker in a pale yellow shirt and figures standing behind. Rusted-roof houses and palm plants lie to the left and right. Two women with headwraps sit in the foreground: one in a blue top and one in a rust-red top.

**Published flags (original wording, including any error reconciled below):**

> - STYLE PAIR: this is the painterly counterpart of the gathering in B16. Layout correspondence is by visual inspection only.
> - PERIOD AND SETTING NOT ESTABLISHED: the modern dress and metal roofs are flagged as in B16.
> - UNVERIFIED: the gathering's purpose is not established; no label is legible.

## 05. Independent content findings

**Direct source observation:** Painterly circle under large tree, corrugated roofs and modern shirts/trousers/wrappers; central speaker, seated crowd. Different viewpoint/figure placement from B16.

**Independent assessment:** Plain-clothed informal assembly/one speaker/stools and benches, no obvious instrument or regalia programme. Metal roofs and contemporary clothing are visible but C07 expressly retains this context under claimed owner guidance. Originating guidance is unavailable; do not reject solely by treating a possibly authorised exception as a universal historical-material violation. No ceremonial meaning or hierarchy is established.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Plain-clothed informal assembly/one speaker/stools and benches, no obvious instrument or regalia programme. Metal roofs and contemporary clothing are visible but C07 expressly retains this context under claimed owner guidance. Originating guidance is unavailable; do not reject solely by treating a possibly authorised exception as a universal historical-material violation. No ceremonial meaning or hierarchy is established.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Plain-clothed informal assembly/one speaker/stools and benches, no obvious instrument or regalia programme. Metal roofs and contemporary clothing are visible but C07 expressly retains this context under claimed owner guidance. Originating guidance is unavailable; do not reject solely by treating a possibly authorised exception as a universal historical-material violation. No ceremonial meaning or hierarchy is established.

**Dependencies:** ORIGINATING_OWNER_CULTURAL_GUIDANCE; INTENDED_MODERN_CONTEXT_VS_PARENT_STATE; OAD-55/56

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD scope/source continuity and owner-guidance confirmation, not a new ritual or instrument defect. Keep generic non-ritual assembly framing and OAD55/56 qualifications. Do not demand old source layout/painterly-only convention without the actual state brief; no new artwork execution.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B16 source](https://drive.google.com/file/d/1sixVQ4I9wsgJbEOSfssCVsXRcrIG3x7R/view) — archive`assessments/B16.md`; [C04 source](https://drive.google.com/file/d/1y2nF2o_KEALA29pJyfjU7oF-aQaXm1Y-/view) — archive`assessments/C04.md`; [C07 source](https://drive.google.com/file/d/1mRYoJ71IRUz3HS1G19luJMFCJxjv3-th/view) — archive`assessments/C07.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b18"></a>

# B18 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B18` · **Filename:** `CHAR_ADANNA_TURNAROUND_BACK_V001_REFERENCE_VS_CANDIDATE.jpg`

**Source:** [1uHEH6I8SKhwpeA1C38tsarzLNBACDWny](https://drive.google.com/file/d/1uHEH6I8SKhwpeA1C38tsarzLNBACDWny/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

3320×1010 JPEG; decoded modeRGB. 

- Source:`471228`bytes; MD5`ac6a380f542e35efd45affc053e2df05`; SHA256`6337d09b8098b6aab86d10fd4f6fe0fdee65724a299cdefa21da0bf3c55f1a43`.
- Research:`3656`bytes; MD5`89be486d57ba1073b54647a70b69c8d9`; SHA256`297ed36b9a3b136153536d63ce0b58e0121fed37a7c15826c0f9efde13d9ba90`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B18_CHAR_ADANNA_TURNAROUND_BACK_V001_REFERENCE_VS_CANDIDATE.md](https://drive.google.com/file/d/1h2CZd9GojO8BgUs6IBtoDZ3u39k1LeCt/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A two-panel comparison board . The left panel is an identity reference sheet titled 'ADANNA — MASTER IDENTITY REFERENCE' with a portrait, detail crops and text. The right panel is a full-length back-view render of a figure in a blue wrap and a bare-shouldered top, with a diagonal strap across the back and a sandal pair. The heading reads: 'Reference: CHAR_ADANNA_MASTER_REFERENCE_V001 (Drive 1k08XH8V…) · Candidate: UNAPPROVED — PENDING CD/TD review'.

**Published flags (original wording, including any error reconciled below):**

> - REFERENCE NOT IN LISTING: the cited reference ID (1k08XH8V…) is not in the PENDING ID registers or the image MD5 listing. The reference file is outside PENDING by this refresh's registers and is not examined here.
> - BOARD CLAIM UNVERIFIED: the board states the spiral pendant and bead arrangement are 'original fiction, not a documented Igbo emblem'. This is the board's own statement; this report does not verify it.
> - BOARD CLAIM UNVERIFIED: the board names 'Braided styling and indigo cloth' as broadly West African. Not checked here.
> - CANDIDATE STATUS: the board itself marks the candidate UNAPPROVED — PENDING CD/TD review. This report does not approve or reject it.
> - BLADE: the identity lock says a blade is worn on the left hip; the candidate's hip detail is not clear enough to confirm it. Recorded, not resolved.
> - UNVERIFIED: the figure's stated age, build and expression are the board's text and are not checked.

## 05. Independent content findings

**Direct source observation:** Master-reference board on left; right full-length BACK V001 figure with long loose braids, diagonal strap, blue wrap and long sheath-like object near viewer-left hip. Outer heading explicitly NEW CANDIDATE/UNAPPROVED.

**Independent assessment:** Not a standalone current artwork master. Shows historical V001 shape for evidence; cannot prove source V001 bytes or authorize new back design. Master ID is now resolved independently outside PENDING.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Not a standalone current artwork master. Shows historical V001 shape for evidence; cannot prove source V001 bytes or authorize new back design. Master ID is now resolved independently outside PENDING.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Not a standalone current artwork master. Shows historical V001 shape for evidence; cannot prove source V001 bytes or authorize new back design. Master ID is now resolved independently outside PENDING.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain as historical aid, link exact candidate-original when located; do not promote thumbnail or infer hidden front/weapon authority. No alteration to this original audit evidence.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C01 source](https://drive.google.com/file/d/1gN2UYAAP0liFmCgQMJjJhskj2D0BAmQW/view) — archive`assessments/C01.md`; [C19 source](https://drive.google.com/file/d/1m32I8rIheLcbUG8NAWF1b1DbUSHE4b7H/view) — archive`assessments/C19.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b19"></a>

# B19 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B19` · **Filename:** `CHAR_ADANNA_TURNAROUND_FRONT_V001_REFERENCE_VS_CANDIDATE.jpg`

**Source:** [12v0y9sOdgbn7ZBFBMdUDPOh64EtpyW02](https://drive.google.com/file/d/12v0y9sOdgbn7ZBFBMdUDPOh64EtpyW02/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

3320×1010 JPEG; decoded modeRGB. 

- Source:`528761`bytes; MD5`7d76482ba8e245b340565765f1c3cdb7`; SHA256`d993720c8dea0d0504d04d3166eacba65e33d1404c233bd20c1569099dceef69`.
- Research:`3465`bytes; MD5`5d21f0725b5e8ee36a67230dcedfcfb0`; SHA256`6d362efe09aaca5e7f082ae47d95487ae9a949440f3e5750d58e689e29135b94`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B19_CHAR_ADANNA_TURNAROUND_FRONT_V001_REFERENCE_VS_CANDIDATE.md](https://drive.google.com/file/d/1yM87TzkqXGpufThbHTwtTWfL4WksUG60/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A two-panel board . Left: the identity reference sheet 'ADANNA — MASTER IDENTITY REFERENCE' (same text and crops as B18). Right: a labelled front-view figure titled 'ADANNA — REFERENCE VIEW: FRONT', with a height scale marked in heads (7.5 heads tall) and call-outs for hair, temple beads, scar, bandeau, baldric, pendant, armlet, scabbard, wrapper skirt and sandals. The header reads 'NEW CANDIDATE (right)' and 'UNAPPROVED — PENDING CD/TD review'.

**Published flags (original wording, including any error reconciled below):**

> - CALL-OUT CONFLICT: the front panel labels the temple beads 'Right temple', while the reference text (left panel) states 'LEFT TEMPLE'. Recorded, not resolved; the research record is not used to choose.
> - PANEL LABEL CONFLICT: the right panel is labelled 'REFERENCE VIEW' with an APPROVED status line, but the board heading calls it the NEW CANDIDATE, UNAPPROVED. Which panel is the candidate cannot be confirmed from the board alone.
> - UNVERIFIED: the 7.5-head proportion and the callout positions are the board's claims, not measured here.
> - UNSUPPORTED CULTURAL CLAIM: the board's note that the spiral pendant and bead arrangement are 'original fiction' is the board's statement; not verified.
> - The reference ID the board cites (1k08XH8V…) is NOT in the PENDING ID registers or the image MD5 listing (checked in B18); the reference is not examined here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Outer header identifies right as NEW CANDIDATE/UNAPPROVED; embedded FRONT V001 says APPROVED and 'Right temple' while left master says LEFT. Sheath on viewer-left, badge-like jewellery/copy and detailed callouts.

**Independent assessment:** Actual false approval/temple-copy conflict visible. Contrary to Research's stronger ambiguity language, outer panel designation plus C19 identifies intended candidate panel; false embedded text does not make it approved. No exact candidate-original fingerprint from thumbnail.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Actual false approval/temple-copy conflict visible. Contrary to Research's stronger ambiguity language, outer panel designation plus C19 identifies intended candidate panel; false embedded text does not make it approved. No exact candidate-original fingerprint from thumbnail.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Actual false approval/temple-copy conflict visible. Contrary to Research's stronger ambiguity language, outer panel designation plus C19 identifies intended candidate panel; false embedded text does not make it approved. No exact candidate-original fingerprint from thumbnail.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve historical evidence; any separately authorised current artwork must carry correct status and LEFT-temple lock. Do not edit the historical comparison or treat this aid as the raw V001.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C01 source](https://drive.google.com/file/d/1gN2UYAAP0liFmCgQMJjJhskj2D0BAmQW/view) — archive`assessments/C01.md`; [C19 source](https://drive.google.com/file/d/1m32I8rIheLcbUG8NAWF1b1DbUSHE4b7H/view) — archive`assessments/C19.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b20"></a>

# B20 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B20` · **Filename:** `CHAR_ADANNA_TURNAROUND_LEFT_SIDE_V001_REFERENCE_VS_CANDIDATE.jpg`

**Source:** [1IljvE5kdAQKj-GXJbpTFCTcu2KKXK_4a](https://drive.google.com/file/d/1IljvE5kdAQKj-GXJbpTFCTcu2KKXK_4a/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

3320×1010 JPEG; decoded modeRGB. 

- Source:`503142`bytes; MD5`dc67da65f23c4623e79bf3968a4137a0`; SHA256`dcd112b8644e8300a39385af66c66b3da914880b55cd207d3525cb4b58dd44a0`.
- Research:`2858`bytes; MD5`e0bf3ae24fc0a8bad42ddac87a2f9114`; SHA256`547b87555ac575a1b5cb80accd7e526a355d644ae3a2cf288a3b393e2b90c31f`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B20_CHAR_ADANNA_TURNAROUND_LEFT_SIDE_V001_REFERENCE_VS_CANDIDATE.md](https://drive.google.com/file/d/1bVWiYdnienrfRUkugg2VycuMlXI78fkh/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A two-panel board . Left: the same 'ADANNA — MASTER IDENTITY REFERENCE' sheet. Right: a full-length left-profile figure on a grey gradient, labelled 'REFERENCE PLATE: ADANNA — LEFT PROFILE' with 'STATUS: APPROVED / DATE: 2026-11-15'. The figure wears a bare-shouldered blue top, a blue wrap skirt and a leather strap; the feet appear bare at this scale.

**Published flags (original wording, including any error reconciled below):**

> - PANEL LABEL CONFLICT: the right panel is labelled a REFERENCE PLATE with APPROVED status, while the board heading names it the NEW CANDIDATE. This report cannot tell which panel is the candidate.
> - VISUAL DISCREPANCY: the feet look bare in this view; the front view (B19) and the three-quarter view (B21) show sandals. Not resolved here; the image scale is too small to confirm.
> - UNVERIFIED: the left-side claims in the identity text (for example the armlet on the left upper arm) are not checked in this profile.
> - The reference ID the board cites (1k08XH8V…) is NOT in the PENDING ID registers or the image MD5 listing (checked in B18); the reference is not examined here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Outer heading NEW CANDIDATE right versus approved master left; embedded LEFT PROFILE V001 carries false APPROVED/date text. Side figure faces left, blue wrap and sheath; dark sandals/sole shapes are faint at this presentation size.

**Independent assessment:** False status is clear; Research's apparently-bare-foot reading is uncertain and not a defensible barefoot-correction instruction from this aid. Original standalone pixels required for that claim.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

False status is clear; Research's apparently-bare-foot reading is uncertain and not a defensible barefoot-correction instruction from this aid. Original standalone pixels required for that claim.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** False status is clear; Research's apparently-bare-foot reading is uncertain and not a defensible barefoot-correction instruction from this aid. Original standalone pixels required for that claim.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain audit aid; link raw source and correct status only in a separately authorised deliverable, not by overwriting this evidence. No geometry or footwear changes directed here.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C01 source](https://drive.google.com/file/d/1gN2UYAAP0liFmCgQMJjJhskj2D0BAmQW/view) — archive`assessments/C01.md`; [C19 source](https://drive.google.com/file/d/1m32I8rIheLcbUG8NAWF1b1DbUSHE4b7H/view) — archive`assessments/C19.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b21"></a>

# B21 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B21` · **Filename:** `CHAR_ADANNA_TURNAROUND_THREE_QUARTER_V001_REFERENCE_VS_CANDIDATE.jpg`

**Source:** [1Vyt8yjZAcy8uqMUSZEWDludc5k74rAix](https://drive.google.com/file/d/1Vyt8yjZAcy8uqMUSZEWDludc5k74rAix/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

3320×1010 JPEG; decoded modeRGB. 

- Source:`491226`bytes; MD5`de040afd2f417f6d514f41421eaea57f`; SHA256`e54b87853f719e8b98bfc06196b249d868a794eaa052153efc763cb08329f21e`.
- Research:`2668`bytes; MD5`df5ebf7dd3e08d4d9a1a452839982488`; SHA256`0f3d58474a8bd2c2ad52f1323843fb1d4c62726d171a8e98029003e761682bd8`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B21_CHAR_ADANNA_TURNAROUND_THREE_QUARTER_V001_REFERENCE_VS_CANDIDATE.md](https://drive.google.com/file/d/15UbukY-19IyzdCCjEyn-8XPV8uKfk4MF/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A two-panel board . Left: the same 'ADANNA — MASTER IDENTITY REFERENCE' sheet. Right: a full-length three-quarter-front figure on a grey gradient, labelled 'PRODUCTION MODEL SHEET: CHARACTER: ADANNA — REFERENCE VIEW: THREE-QUARTER FRONT'. The figure wears a bare-shouldered blue top, a blue wrap skirt, a leather baldric and sandals, with a scabbard-like object at the hip.

**Published flags (original wording, including any error reconciled below):**

> - PANEL LABEL CONFLICT: the right panel is labelled a reference view, while the board heading names it the NEW CANDIDATE. Which panel is the candidate is not established by the board.
> - UNVERIFIED: the scabbard-like object's side and form are not confirmed at this scale; the identity text places the blade on the left hip.
> - The reference ID the board cites (1k08XH8V…) is NOT in the PENDING ID registers or the image MD5 listing (checked in B18); the reference is not examined here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Outer heading NEW CANDIDATE right; embedded three-quarter figure with strap, skirt/sandals and protruding hilt-like part on viewer-right hip, under PRODUCTION MODEL SHEET/REFERENCE VIEW wording.

**Independent assessment:** Outer label establishes intended panel despite embedded reference wording. Weapon configuration is unapproved CQ-9 evidence, not approved hilt authority; thumbnail cannot stand in for exact raw V001.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Outer label establishes intended panel despite embedded reference wording. Weapon configuration is unapproved CQ-9 evidence, not approved hilt authority; thumbnail cannot stand in for exact raw V001.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Outer label establishes intended panel despite embedded reference wording. Weapon configuration is unapproved CQ-9 evidence, not approved hilt authority; thumbnail cannot stand in for exact raw V001.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Keep historical comparison and bind actual source/version; preserve CQ-9 and do not implement weapon design from it.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C01 source](https://drive.google.com/file/d/1gN2UYAAP0liFmCgQMJjJhskj2D0BAmQW/view) — archive`assessments/C01.md`; [C19 source](https://drive.google.com/file/d/1m32I8rIheLcbUG8NAWF1b1DbUSHE4b7H/view) — archive`assessments/C19.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b22"></a>

# B22 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B22` · **Filename:** `COSTUME_BREAKDOWN_SHEET_V001_REFERENCE_VS_CANDIDATE.jpg`

**Source:** [1gDpiCSJVuhSFUgRpuN9t_dBR4_n3oegj](https://drive.google.com/file/d/1gDpiCSJVuhSFUgRpuN9t_dBR4_n3oegj/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

3332×1004 JPEG; decoded modeRGB. 

- Source:`607803`bytes; MD5`c07a7d149f494b7de72f57202f911a51`; SHA256`9fe29869512b7bf7b09e0aff13cbd925572160b11c16e8ed4d5018ef07362133`.
- Research:`3466`bytes; MD5`dd9ec055a5be9e3774e38165d9960080`; SHA256`303d3c2ecb81c365bc29f0eea4f3e2e35790f6666b692af52f850a92a9ea9992`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B22_COSTUME_BREAKDOWN_SHEET_V001_REFERENCE_VS_CANDIDATE.md](https://drive.google.com/file/d/17ynH6QGvYX4bU4v4m0SEEm1-dyNMmYYZ/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A two-panel costume board . Left: the reference 'ADANNA — MASTER IDENTITY REFERENCE' sheet. Right: 'CHAR_ADANNA_COSTUME_BREAKDOWN_V001 — UNAPPROVED — PENDING CD — COSTUME BREAKDOWN', with front, back and side figures, detail crops, a palette strip, call-outs, and an outlined 'UNRESOLVED — NOT APPROVED' banner over the back view. The subtitle reads: 'Reference: CHAR_ADANNA_MASTER_REFERENCE_V001 (Drive 1k08XH8…, approved copy 1FY3hw36…) · Candidate: UNAPPROVED — PENDING CD · NOT FOR PROMOTION'.

**Published flags (original wording, including any error reconciled below):**

> - UNRESOLVED ITEMS: the board itself lists six unresolved areas (back torso, lower body, fasteners, pendant cord, hand scale, strap-to-scabbard junction). Recorded; not resolved here.
> - LEFT TEMPLE / RIGHT TEMPLE: this board says LEFT TEMPLE, matching the reference text and differing from the 'Right temple' call-out on B19. The conflict on the turnaround boards is recorded.
> - CITED ID CONFLICT: the subtitle cites an approved copy 1FY3hw36…; that same ID is cited as absent in F49 of this refresh. Not in the registers; recorded.
> - The reference ID the board cites (1k08XH8V…) is NOT in the PENDING ID registers or the image MD5 listing (checked in B18); the reference is not examined here.
> - UNVERIFIED: the 'original fiction' and 'broadly West African' statements on the reference text are the board's claims, not checked here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Master left, costume multi-panel candidate right labelled UNAPPROVED; back panel UNRESOLVED. Front has asymmetric short wrap and visible scabbard/hilt while footer lists back/lower body/fasteners/cord/hand-scale/junction unresolved.

**Independent assessment:** Honest unresolved labels but visually detailed invented regions could be mistaken for specifications. Approved master copies now resolve with equal hashes, correcting Research's limited-register availability gap. This is not the raw costume V001.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Honest unresolved labels but visually detailed invented regions could be mistaken for specifications. Approved master copies now resolve with equal hashes, correcting Research's limited-register availability gap. This is not the raw costume V001.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Honest unresolved labels but visually detailed invented regions could be mistaken for specifications. Approved master copies now resolve with equal hashes, correcting Research's limited-register availability gap. This is not the raw costume V001.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain evidence-only aid and link raw exact costume source; no adoption of garment/fastener/weapon design. Do not silently edit Research's absence qualifications.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C18 source](https://drive.google.com/file/d/18Ehnq1cIcE6eu8fE7Wzidk9aDfNm9aTI/view) — archive`assessments/C18.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b23"></a>

# B23 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B23` · **Filename:** `ENV_CH03-EXP-001_THE_WALL_TOP_WALK_V001.jpg`

**Source:** [1CFCPrQct-qvsw662-wOZAngxiXAOMfw3](https://drive.google.com/file/d/1CFCPrQct-qvsw662-wOZAngxiXAOMfw3/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** separate valid JPEG; not the quarantined text object; integrity-linked. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-EXP-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** The worn top of the rampart, reached by cut steps: views over ash roofs and into back plots.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Rampart top, steps.
> **Notes.** Stands in for "rooftop corners": thatch roofs here cannot be walked on.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`337726`bytes; MD5`bce36fd7b0192e77b6f2de64b4e4be65`; SHA256`296b9a19eecd18d6fbd09a3d1c33e8a8d72bb54bc3ba2cd8d9885ccaf21f013d`.
- Research:`2600`bytes; MD5`d6a3f2a0a2622db4514e7b646de21dac`; SHA256`5d86d885d0e09ed92942743b1e37ff7874d198b33da52aa85d5fd522f6ea9550`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B23_ENV_CH03-EXP-001_THE_WALL_TOP_WALK_V001.md](https://drive.google.com/file/d/1K4tTOBzKqZ0tfVBNKqbq2iA8hV7EuiCD/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly view  along a stone wall-walk with stone parapets, a rope railing on wooden posts, and a paved stone walkway. Two crenellated square gatehouse towers with arched gates stand ahead. Flat-roofed stone houses fill the town below, with hills and haze behind.

**Published flags (original wording, including any error reconciled below):**

> - SETTING NOT ESTABLISHED: the architecture (crenellated gatehouses, arched gates, flat-roofed stone houses on hills) does not match the Nigerian/Igbo-region setting used elsewhere in the CH01 set. The image does not establish the Chapter 3 location; flagged for the research base. This report does not identify the place.
> - UNSUPPORTED ARCHITECTURE: the towers and wall-walk form are not supported by any source in this file.
> - BATCH RECORD CONFLICT: the F68 record names CH03-EXP-001 as a corrupt file excluded from batch 6, and the C15 record describes an overwrite incident for this asset. The integrity of this file is not established by this report beyond the MD5 check in the identity line.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Readable 1672x941 JPEG: golden/tan stone-paved battlement, crenellated stone parapets and two square towers; tightly packed flat-roof masonry city on rolling dry hills; rope-post rail; warm directional shadows. No earthen rampart, steep-thatch roofs, ash-grey still daylight or dead-palm/forest context identifiable.

**Independent assessment:** Current separate image's setting/material/atmosphere visibly fails LMR CH03-EXP-001 proposed brief. Exact real-world city cannot be identified and must not be asserted. Readable bytes do NOT resolve historical integrity incident or authorize recovery.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Current separate image's setting/material/atmosphere visibly fails LMR CH03-EXP-001 proposed brief. Exact real-world city cannot be identified and must not be asserted. Readable bytes do NOT resolve historical integrity incident or authorize recovery.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Current separate image's setting/material/atmosphere visibly fails LMR CH03-EXP-001 proposed brief. Exact real-world city cannot be identified and must not be asserted. Readable bytes do NOT resolve historical integrity incident or authorize recovery.

**Dependencies:** CH03_SCOPE; EXP001_PROVENANCE_INTEGRITY

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**REJECTION RECOMMENDED**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

REJECTION RECOMMENDED for this submitted CH03 use. CD must settle CH03 design scope and Research provide grounded architecture/material direction before any separately authorised redo; required rampart/ash-roof/back-plot view derives from LMR, not invented crenellation specifications. Preserve image and quarantined text separately.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [F16 source](https://drive.google.com/file/d/1vA4D8DM3ihztefYbeywPXOAUZjLx18ri/view) — archive`assessments/F16.md`; [F45 source](https://drive.google.com/file/d/13AXeI5-Cy7mvuvor4V86Y0Plv2midqqx/view) — archive`assessments/F45.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b24"></a>

# B24 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B24` · **Filename:** `ENV_CH03-INT-004_THE_FORGOTTEN_KITCHEN_V001.jpg`

**Source:** [18RHdPeQM-WUSA9N0dvliTi4WWqsfcFVX](https://drive.google.com/file/d/18RHdPeQM-WUSA9N0dvliTi4WWqsfcFVX/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-INT-004` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A kitchen shelter with three hearth stones, a pot of something long dried, firewood stacked for a meal never cooked.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Hearth stones, pot, firewood.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`261541`bytes; MD5`05d235bc3d7dfe6d56408e7a5ebfd496`; SHA256`8ce6445b7bc10661da4869597124990b40de1f5f096beb0430786517c54607dd`.
- Research:`2581`bytes; MD5`fb07ed34c84a16bf28f1fd24f315adb9`; SHA256`5737f80bcfc7db43e5bbc6d1691da34bed9dbc69525115491d3cdaeaa8359e4f`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B24_ENV_CH03-INT-004_THE_FORGOTTEN_KITCHEN_V001.md](https://drive.google.com/file/d/1tC2f4upJHmz-HPAH0_BSMJHUVWDgZY_D/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photoreal-style interior  of a dim stone kitchen. A stone stove with two arched firing mouths holds a black metal cooking pot and a small basin. Dried herb bundles hang from the wall; a stone quern sits on a low stone block; an earthen jar sits in a niche. A rock-cut opening on the back wall shows a bright exterior of rough stone. An open wooden door leads to a corridor at the right, with a wooden table holding bowls.

**Published flags (original wording, including any error reconciled below):**

> - CONSISTENCY NOTE: batch record F68 describes the V001 to V002 correction for CH03-INT-004 as 'hearth stones replace cut-stone stove'. This V001 shows the cut-stone stove that the correction removed, which fits the record. Not verified against the V002.
> - UNVERIFIED: the herb species, the quern's use, and the rock-cut opening's architecture are not established by the image.
> - SETTING NOT ESTABLISHED: the stone architecture is not checked against any Chapter 3 brief here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Stone/block twin-arched stove, dark round pot, herbs hung in bundles, circular stone quern, panelled timber door, side table and rubble-lit opening. No clearly separate three-stone hearth shown.

**Independent assessment:** Kitchen mood readable but LMR CH03-INT-004 calls for three hearth stones/pot/firewood in rectangular mud-compound chapter setting; visible masonry stove and broken rock opening do not supply it. Herb species and metal-pot material not authenticated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Kitchen mood readable but LMR CH03-INT-004 calls for three hearth stones/pot/firewood in rectangular mud-compound chapter setting; visible masonry stove and broken rock opening do not supply it. Herb species and metal-pot material not authenticated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Kitchen mood readable but LMR CH03-INT-004 calls for three hearth stones/pot/firewood in rectangular mud-compound chapter setting; visible masonry stove and broken rock opening do not supply it. Herb species and metal-pot material not authenticated.

**Dependencies:** CH03_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. If CD confirms proposed scope, replace twin-arched stone-stove design with three hearth stones and reconcile room to laterite/hardwood/palm-thatch requirement; preserve required pot/firewood. Do not prescribe herbs' identity. Await setting decision before production.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E46 source](https://drive.google.com/file/d/16yJsFYZRa3iE1VAtAqhBTAI3JLuUdCmT/view) — archive`assessments/E46.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b25"></a>

# B25 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B25` · **Filename:** `ENV_CH03-INT-005_A_SLEEPING_ROOM_V001.jpg`

**Source:** [1xxQFlOkqg045hnmWm-wJY428u0xSV3-K](https://drive.google.com/file/d/1xxQFlOkqg045hnmWm-wJY428u0xSV3-K/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-INT-005` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A dark inner room seen through a doorway: mats laid out, cloths folded as if for the night.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Mats, cloths.
> **Notes.** Not enterable: seen from the outer room only.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`201513`bytes; MD5`19f8ad3618ee9dfa69297cbe5b90b63e`; SHA256`6a2c0a026b8903519488d03e633f361924c5c22dcc04f2dab2ec8346c658a1c4`.
- Research:`2411`bytes; MD5`1f575a5350ed44d5984d4debc71bca3e`; SHA256`b4a92f59ba05520701e58344daea5a152c105eed343049c5e61fc29d9c95dc71`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B25_ENV_CH03-INT-005_A_SLEEPING_ROOM_V001.md](https://drive.google.com/file/d/1OD2mHnKgCn4DDlGiuQCFgWI1faPChyxI/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly interior of a small plastered room. A barred window with two wooden shutters on the left shows a hazy town of pale buildings outside. A raised wooden platform bed holds a woven mat and a folded striped cloth. At the right, a wooden stool carries a dark glazed jug and a brown bowl, and a small arched niche is set in the wall.

**Published flags (original wording, including any error reconciled below):**

> - SETTING NOT ESTABLISHED: the barred window, the arched niche and the town outside show architecture that the image does not place. The outside view is a generic town and is not identified.
> - CONSISTENCY NOTE: the F68 record says the batch-6 correction for CH03-INT-005 removed the window and arch. This V001 shows both, which fits the record as the pre-correction state. Not verified against the V002.
> - UNVERIFIED: the function of the platform and the bars is not established by the image.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Mat and folded bordered cloth on wooden platform, barred window with panel shutters, strong warm window shaft, arched niche, jug/bowl/stool. View is from inside room, with pale town outside window.

**Independent assessment:** Mats/folded cloth satisfy subject cues, but viewpoint is not registered outer-room/doorway-only look; shadowless grey CH03 light and source architecture not demonstrated. Patterned folded cloth is not cultural proof.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Mats/folded cloth satisfy subject cues, but viewpoint is not registered outer-room/doorway-only look; shadowless grey CH03 light and source architecture not demonstrated. Patterned folded cloth is not cultural proof.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Mats/folded cloth satisfy subject cues, but viewpoint is not registered outer-room/doorway-only look; shadowless grey CH03 light and source architecture not demonstrated. Patterned folded cloth is not cultural proof.

**Dependencies:** CH03_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Following CD confirmation, establish doorway/outer-room viewing limit and grey diffuse light per CH03-INT-005; reconcile introduced bars/shutters/niche to approved chapter kit rather than blanket naming them Mediterranean. Existing accepted V002 visual pass stays historical and is assessed separately.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E47 source](https://drive.google.com/file/d/1SR7CRZC9MZjTBsEi84_N3b4sesAmDsiq/view) — archive`assessments/E47.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b26"></a>

# B26 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B26` · **Filename:** `ENV_CH03-SUB-005_A_RESIDENTIAL_COURTYARD_V001.jpg`

**Source:** [10Apn34FkRedH1E5NXGCa9KSZ1Dh42SJK](https://drive.google.com/file/d/10Apn34FkRedH1E5NXGCa9KSZ1Dh42SJK/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-SUB-005` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A family courtyard with a mortar and pestle left standing, mats rolled, a child's clay toy.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Mortar, mats, toy.
> **Notes.** No remains shown.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`416566`bytes; MD5`9147eeb9255911f307f6cecc6e9220af`; SHA256`29a42eb5cce152d705d04d28540684710170238a95d2f5ccc916426e91755414`.
- Research:`2451`bytes; MD5`09ef8e7c358de8d7097b71a5fefe8fd7`; SHA256`95fe7bedee0517dc7bb4ce521808bc9a54911baea7c76a31afd2a4ff208c2032`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B26_ENV_CH03-SUB-005_A_RESIDENTIAL_COURTYARD_V001.md](https://drive.google.com/file/d/1Ey-aQclGj-gkHw2Jfyu6s58yCGNohb_6/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly courtyard with a paved floor, a tree rising from a square brick planter, and an open doorway in a brick back wall. Indigo-blue cloths hang on a line at the left. A dark glazed jar stands at the right beside a wooden shuttered door and a stone water trough with a tap.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED CULTURAL CLAIM: the indigo cloths are visual detail; this report does not link them to any documented indigo practice.
> - CONSISTENCY NOTE: F68 records that the CH03-SUB-005 correction replaced the tap and fired brick. This V001 shows a tap and fired-brick planter, which fits the record as the pre-correction state. Not verified against the V002.
> - SETTING NOT ESTABLISHED: the brick-and-stone architecture is not placed; the image does not establish the Chapter 3 location.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Bright leafy living tree in fired-brick planter; coursed brick/stone walls, paved floor, blue hanging cloth, louvred door/shutters and metal tap filling trough. No clearly required standing mortar/pestle, rolled mats or child's toy visible.

**Independent assessment:** Conflicts with LMR CH03-SUB-005 stopped-life dead-vegetation/grey-light/material baseline and specific courtyard assets. Water tap/leafy tree/stone paving are direct observations, not a real-world attribution.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Conflicts with LMR CH03-SUB-005 stopped-life dead-vegetation/grey-light/material baseline and specific courtyard assets. Water tap/leafy tree/stone paving are direct observations, not a real-world attribution.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Conflicts with LMR CH03-SUB-005 stopped-life dead-vegetation/grey-light/material baseline and specific courtyard assets. Water tap/leafy tree/stone paving are direct observations, not a real-world attribution.

**Dependencies:** CH03_SCOPE; CH03_INDIGO_LOCATION

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. On confirmed scope, reconcile tap/brick/leafy vegetation/strong sun with chapter requirement and include required mortar-pestle/mats/toy as designed; no invented plumbing solution. Indigo outside weavers' quarter needs location/owner ruling.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E48 source](https://drive.google.com/file/d/1xDJaz1ip1sU4mNFkUpjjPFcCkOGu1d-N/view) — archive`assessments/E48.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b27"></a>

# B27 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B27` · **Filename:** `ENV_CH03-SUB-006_THE_BACK_PLOTS_V001.jpg`

**Source:** [1RcEkIjAlMqO6cvKhwALy9gveVL07gOCK](https://drive.google.com/file/d/1RcEkIjAlMqO6cvKhwALy9gveVL07gOCK/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-SUB-006` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** House gardens gone to grey stalks, a cane fence, a hoe standing in the ground.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Dead garden, fence, hoe.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`382030`bytes; MD5`eb91726efa374c1c65298ae488dd0fd0`; SHA256`f74236063fc75a4db36e76f96050d06cf5e226e782ca85ef1c770ad213b1f402`.
- Research:`2584`bytes; MD5`ab43e5125ae98b7029bed46ddf1b7f79`; SHA256`1eac94ff2035f8753e1b134257361ec5aff478847f8dcbac9f8a685ff4f82ec3`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B27_ENV_CH03-SUB-006_THE_BACK_PLOTS_V001.md](https://drive.google.com/file/d/1dw3skIWbTxwNNBiyJ8NH2XbHg_q4RjQd/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly view of overgrown back yards. Collapsed and leaning wooden lattice, ruined brick walls with ivy, okra plants with pods in the foreground, a rusted metal drum lying in a mound of dark compost, and a line of laundry. Rows of chimneyed terrace houses with slate-style roofs stand in the background under an overcast sky.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED SETTING: the terrace houses, chimney stacks and slate-style roofs are not supported by any source in this file and do not establish the Chapter 3 location. Flagged for the research base. This report does not identify the place.
> - CONSISTENCY NOTE: F68 records that the CH03-SUB-006 correction removed the terraces. This V001 shows terraces in the background, which fits the record as the pre-correction state. Not verified against the V002.
> - FLAG (F68 record, author's): the batch-6 V002 is described as having a faint signature-like scrawl; it is not checked in this report.
> - UNVERIFIED: okra identification is a visual reading only; the drum's contents and origin are not established.

## 05. Independent content findings

**Direct source observation:** Dense green garden, lattice fences, broken brick walls, rusty barrel, hanging laundry; rows of two-storey houses with chimney pots and slate-like roofs behind. Hoe standing in ground not clearly readable.

**Independent assessment:** Strong direct mismatch with grey-stalk dead gardens, cane fence/hoe and rectangular mud/steep-thatch chapter kit; no need to diagnose an exact foreign city or plant species.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Strong direct mismatch with grey-stalk dead gardens, cane fence/hoe and rectangular mud/steep-thatch chapter kit; no need to diagnose an exact foreign city or plant species.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Strong direct mismatch with grey-stalk dead gardens, cane fence/hoe and rectangular mud/steep-thatch chapter kit; no need to diagnose an exact foreign city or plant species.

**Dependencies:** CH03_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. REJECTION RECOMMENDED for current CH03 use; if separately rebriefed after scope decision, show dead garden/cane fence/standing hoe and confirmed chapter architecture/light. Preserve prior V002 accepted visual pass without rewriting R6.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E49 source](https://drive.google.com/file/d/1bs7I2_iPaWQMANPkCLu8YA3x_24FiS9n/view) — archive`assessments/E49.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b28"></a>

# B28 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B28` · **Filename:** `ENV_CH03-TRV-003_THE_NARROW_PASSAGES_V001.jpg`

**Source:** [1DtT7wfMJt63S_oGN-cIKuzR__7oDAqRG](https://drive.google.com/file/d/1DtT7wfMJt63S_oGN-cIKuzR__7oDAqRG/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-TRV-003` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Gaps a shoulder wide between compound walls, drifted knee-deep in ash, with footprints that stop.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Wall backs, ash drifts.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`201902`bytes; MD5`de672ec7a42da26a5d8e7a11177f045b`; SHA256`e0fefc89353939f5618352e4a9b179d116808b019860913e4ead072c5a61ce25`.
- Research:`2318`bytes; MD5`193fa4716937c44975e256fb178c1490`; SHA256`f13595ef09afd5e89b8eac74809e39f2fe5c430c19aa03070093bc3ab398e6dd`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B28_ENV_CH03-TRV-003_THE_NARROW_PASSAGES_V001.md](https://drive.google.com/file/d/1vbGPDGs9ldWn24BdAyvhh1cOm1e3m93p/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly, dim narrow alley. Brick and earth walls close in on both sides; cloths are strung across the top of the alley in dark red and brown. An arched doorway with a recessed niche stands on the right, and a small barred window sits in the right-hand wall. Light falls at the far end on a stone-paved path.

**Published flags (original wording, including any error reconciled below):**

> - SETTING NOT ESTABLISHED: the arched doorway and brick walls are not placed by the image; the Chapter 3 location is not established.
> - CONSISTENCY NOTE: F68 records that the CH03-TRV-003 correction removed brick and arches. This V001 shows brick and an arch, which fits the record as the pre-correction state. The F68 flag that the V002 walls read near-concrete is not checked here.
> - UNVERIFIED: the overhead cloths' use and material are not established.

## 05. Independent content findings

**Direct source observation:** Very narrow warm-lit stone-paved alley, exposed coursed masonry/plaster, recessed arched door, window grille and overhead sagging cloths. No knee-deep ash or stopping footprint trace discernible.

**Independent assessment:** Passage read is clear but LMR CH03-TRV-003 ash-drift/footprint detail, grey daylight and earthen compound backs not demonstrated. Do not identify a specific bazaar or city.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Passage read is clear but LMR CH03-TRV-003 ash-drift/footprint detail, grey daylight and earthen compound backs not demonstrated. Do not identify a specific bazaar or city.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Passage read is clear but LMR CH03-TRV-003 ash-drift/footprint detail, grey daylight and earthen compound backs not demonstrated. Do not identify a specific bazaar or city.

**Dependencies:** CH03_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Following CD scope confirmation, reconcile masonry/arch programme and warm lighting with approved chapter kit; depict required ash/footprint beat in an assessable view rather than inventing motif or corridor width beyond registered shoulder-wide description.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E50 source](https://drive.google.com/file/d/1OmXsyhC7HZJrZuLjFqBKNkpAq4lqUWf2/view) — archive`assessments/E50.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b29"></a>

# B29 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B29` · **Filename:** `ENV_CH04-EXP-003_THE_SMALL_ISLANDS_V001.jpg`

**Source:** [1w0sSsFVxbPKPScXVHAZvj7wBHK7DnYCu](https://drive.google.com/file/d/1w0sSsFVxbPKPScXVHAZvj7wBHK7DnYCu/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-EXP-003` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Sandbars and two tree-grown islets mid-river, reached by canoe; birds, driftwood, one old hearth.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** Islets, driftwood, birds.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`296529`bytes; MD5`7cf439f3297a14b76deda85efaf44856`; SHA256`cdfb176f5a89e25e4c39d6c2577e22da2778c5768e704c391984f2c8164857e8`.
- Research:`2150`bytes; MD5`445d78b630aaf412bf1ee11b19277e47`; SHA256`1a3189bf4ffdc6ded13b8728dcefb3f1f91f85feee892abce37e8f83c186c57d`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B29_ENV_CH04-EXP-003_THE_SMALL_ISLANDS_V001.md](https://drive.google.com/file/d/1fxhWsyTXEvDLgdwESwjeheMJUswpnhfS/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painted river landscape. Several palm-fringed islands and sandbanks sit in pale, shallow water under a grey sky. A dense tree cluster stands on a larger island at the centre. Three narrow canoes are drawn up on a sandbank at the lower right. Hills lie in haze behind.

**Published flags (original wording, including any error reconciled below):**

> - UNIDENTIFIED WATERWAY: the river and its islands are not identified; the image does not establish the CH04 location.
> - UNVERIFIED: the canoes' form and make are not established at this scale.
> - UNVERIFIED: the species of palms and trees are visual readings only.
> - EXP item: an exploratory file; its status in the research record is not checked here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Pale broad river, sandy bars and multiple low vegetation islands, central dense tree island, palms, three plain narrow canoe-like craft on near-right bank, distant hills. No people or supernatural objects visible; old-hearth/driftwood/birds not identifiable.

**Independent assessment:** General river/sandbar subject is plausible against LMR, but two tree-grown islets/old-hearth microbeat and approved river continuity not established; Research expressly does not place waterway. EXP prefix denotes exploration category, not automatic noncanon permission.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Required two wooded islets and old-hearth/driftwood/bird detail beats not established by the retained visual review.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

General river/sandbar subject is plausible against LMR, but two tree-grown islets/old-hearth microbeat and approved river continuity not established; Research expressly does not place waterway. EXP prefix denotes exploration category, not automatic noncanon permission.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** General river/sandbar subject is plausible against LMR, but two tree-grown islets/old-hearth microbeat and approved river continuity not established; Research expressly does not place waterway. EXP prefix denotes exploration category, not automatic noncanon permission.

**Dependencies:** CH04_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Required two wooded islets and old-hearth/driftwood/bird detail beats not established by the retained visual review.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD final-use recommendation pending CH04 setting/scope and source/angle showing intended islets and required microbeat. Do not invent a geographically specific river or culturally exact canoe from small pixels.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b30"></a>

# B30 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B30` · **Filename:** `ENV_CH04-EXP-006_THE_CAVE_BEHIND_THE_LOW_FALLS_V001.jpg`

**Source:** [1s28ocisLsI-BOpGMY65MMT-yU9hbHDOY](https://drive.google.com/file/d/1s28ocisLsI-BOpGMY65MMT-yU9hbHDOY/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-EXP-006` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A shallow wet cave behind a 4 m curtain of water on a side stream.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** Falls, cave, wet rock.
> **Notes.** The side stream and falls are new; nothing in the cave by default.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`372877`bytes; MD5`424e44c7737356930c0cf13c097d6c63`; SHA256`b168ecd96227a0bf3ebced0049a3ff78e0d348306fbf6637e3ac189bce07e09a`.
- Research:`2253`bytes; MD5`1df03a2ce45472ffeca4600a9762f4fd`; SHA256`d6e74a92044024838db8f925753dc21aa6926c59f9d3a338b018e8d0f0dae1c1`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B30_ENV_CH04-EXP-006_THE_CAVE_BEHIND_THE_LOW_FALLS_V001.md](https://drive.google.com/file/d/1Oi1j9NrJDQkhc4lqhr0GX_Hg2CBN70qa/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painted waterfall scene. A broad sheet of water falls over a stepped ledge into a shallow pool in front of a dark rock overhang. Ferns hang from the rock lip at the upper right and left. A rainbow arcs across the mist at the left. The cave interior is dark, with a vertical rock face and dripping water.

**Published flags (original wording, including any error reconciled below):**

> - UNVERIFIED: the rock formation and the cave's form are visual readings; the geology is not established.
> - UNVERIFIED: the rainbow and mist are depicted optical effects; they carry no evidential weight here.
> - EXP item: an exploratory file; its status in the research record is not checked here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Low stepped fall across broad ledge, wet dark recess/overhang behind/above sheet water, ferns, bright spray and rainbow on left; no figures or ritual imagery visible. No scale object to measure four metres.

**Independent assessment:** Readable falls/wet-rock exploration, but exact shallow cave-behind-curtain access and registered4m scale cannot be verified; rainbow is optical depiction not a supernatural diagnosis.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Required enterable shallow cave behind the water curtain is not demonstrated in the retained visual assessment.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Readable falls/wet-rock exploration, but exact shallow cave-behind-curtain access and registered4m scale cannot be verified; rainbow is optical depiction not a supernatural diagnosis.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Readable falls/wet-rock exploration, but exact shallow cave-behind-curtain access and registered4m scale cannot be verified; rainbow is optical depiction not a supernatural diagnosis.

**Dependencies:** CH04_SCOPE; UNSCALED_CAVE_ACCESS

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Required enterable shallow cave behind the water curtain is not demonstrated in the retained visual assessment.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD pending CH04 scope and spatial/scale evidence for cave accessible behind low falls. No exact waterfall-height correction derivable from this unscaled single shot.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b31"></a>

# B31 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B31` · **Filename:** `ENV_CH04-INT-001_A_FISHING_SHELTER_V001.jpg`

**Source:** [1P-PjtOw4TrIjmN3uZsrFZF0NDjzgfHSv](https://drive.google.com/file/d/1P-PjtOw4TrIjmN3uZsrFZF0NDjzgfHSv/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-INT-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** An open lean-to on the bank with nets hung to dry, floats, a mending needle and a cold fire.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** Lean-to, nets, floats.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`381098`bytes; MD5`a4e15a6dfdf8489392db87a6ae8bbada`; SHA256`3a86367b85a8ea973d23e93494cb0254a395db5fa6241d09927490f382ac6921`.
- Research:`2494`bytes; MD5`beaa76f16d8abb28873d9a69aab254ca`; SHA256`098afefc188d3805a621088452b184528c97ee36fd1775b4f140ced4c23c1839`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B31_ENV_CH04-INT-001_A_FISHING_SHELTER_V001.md](https://drive.google.com/file/d/1Il11btWoZHCbD9ofVrxSVkN52Fbpct7M/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly interior of a thatched fishing shelter on a timber deck over a river. Dangling nets hang from the roof and posts; woven baskets and conical traps lie at the left. A plank table with a knife sits in the foreground. At the right a smoking rack of poles holds fish over a small fire on a river platform. The river and wooded far bank are visible through the open side.

**Published flags (original wording, including any error reconciled below):**

> - F68 CONSISTENCY NOTE: the batch-6 record says CH04-INT-001 V002 removed an overwater deck. This V001 shows a timber deck over the water, which fits the record as the pre-correction state. Not verified against the V002.
> - UNVERIFIED: the fish species, the net type, and the trap designs are visual readings; they are not identified.
> - UNVERIFIED: the smoke rack's function is inferred from its placement; not established by the image.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Nets/traps under thatch on timber deck at/over river edge; foreground knife/table; smoke/fire-like patch at right over water with rack; net floats/weights visible, mending needle not identifiable.

**Independent assessment:** Fishing cues match but LMR CH04-INT-001 specifies open lean-to on bank and cold fire; overwater platform and active smoke do not demonstrate that brief. Research does not authenticate fishing methods.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Fishing cues match but LMR CH04-INT-001 specifies open lean-to on bank and cold fire; overwater platform and active smoke do not demonstrate that brief. Research does not authenticate fishing methods.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Fishing cues match but LMR CH04-INT-001 specifies open lean-to on bank and cold fire; overwater platform and active smoke do not demonstrate that brief. Research does not authenticate fishing methods.

**Dependencies:** CH04_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. On confirmed scope, ground shelter on bank and show cold-fire state per registered brief; supply mending-tool detail if required at this level. No cultural fish/net species or engineering dimensions prescribed.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E51 source](https://drive.google.com/file/d/13Dc48FnSA9nvCUzL2zBq6zNv6axFLtIG/view) — archive`assessments/E51.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b32"></a>

# B32 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B32` · **Filename:** `ENV_CH04-INT-002_A_RIVERBANK_HOUSE_V001.jpg`

**Source:** [1QtJIm1YcL8orW7pNBRZDyLCdPG-RtCGo](https://drive.google.com/file/d/1QtJIm1YcL8orW7pNBRZDyLCdPG-RtCGo/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-INT-002` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A mud house a few steps above the water: paddles by the door, dried fish in the rafters, a sleeping platform.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** House shell, paddles, fish racks.
> **Notes.** On the ground, not stilts.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`337457`bytes; MD5`3e2616714a92b613f9a147306f3e20bf`; SHA256`1540d0ad330b08b780fcf8c635a7366cd9ec8efa9a5ba60e12f4b01f80c54877`.
- Research:`2419`bytes; MD5`9bbcd04638bb7947ff7a945d803ba84b`; SHA256`03fd59163cafd13c28e457947adc0bb09e8a87871218be1931811d5ef4f1ad16`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B32_ENV_CH04-INT-002_A_RIVERBANK_HOUSE_V001.md](https://drive.google.com/file/d/1Uco_g_Vn5hwQb9yvJjtnGkVf_oQXOz62/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly stilt house on a river edge. The house has a steep thatched roof, mud-plastered walls on the right and a timber-framed open front. Fish hang on a rack at the front, a rope ladder rises to a platform, and a woven basket sits by the door. Two earthenware pots stand on the platform. A dugout canoe with a domed woven cover lies at the left, and palms grow behind.

**Published flags (original wording, including any error reconciled below):**

> - F68 CONSISTENCY NOTE: the batch-6 record says CH04-INT-002 V002 removed a covered canoe. The domed cover on the dugout at the left of this V001 fits that record as the pre-correction state. Not verified against the V002.
> - UNVERIFIED: the fish species and the function of the domed cover are not established by the image.
> - UNVERIFIED: the mud-plastered wall and ladder's construction are visual readings only.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Steep-thatch mud/timber house on many posts rising from brown water, ladder to deck, hanging fish, pots and bed platform; canoe at left has domed woven-looking cover.

**Independent assessment:** Explicit conflict with CH04-INT-002 'on the ground, not stilts'; covered canoe lacks authority. Fish/platform support subject but not approval or exact construction.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Explicit conflict with CH04-INT-002 'on the ground, not stilts'; covered canoe lacks authority. Fish/platform support subject but not approval or exact construction.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Explicit conflict with CH04-INT-002 'on the ground, not stilts'; covered canoe lacks authority. Fish/platform support subject but not approval or exact construction.

**Dependencies:** CH04_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. If CD confirms registered scope, place house on ground a few steps above water, reconcile covered craft with approved plain dugout design and show required paddles/rafters. Do not invent stilts as a locally authentic solution.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E52 source](https://drive.google.com/file/d/1e98rcp-QG7u5z9ihXmbabgGDXe94XTEa/view) — archive`assessments/E52.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b33"></a>

# B33 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B33` · **Filename:** `ENV_CH04-INT-003_THE_CANOE_SHED_V001.jpg`

**Source:** [1Wj41WxKZ_kqLWRqJz2PQFr1EYWSqj9vR](https://drive.google.com/file/d/1Wj41WxKZ_kqLWRqJz2PQFr1EYWSqj9vR/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-INT-003` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A long thatched roof on posts over three dugouts, one half carved, adzes and chips beneath it.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** Shed, dugouts, adzes.
> **Notes.** Open-sided; walk-through.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`308982`bytes; MD5`e8b6deece65dc5077eb28aaf0715112f`; SHA256`2026ddd923529cf6bea3a275194b34eadf30e97679afad27fe50754e94d73f20`.
- Research:`2338`bytes; MD5`dfe35a22bd019be7c61d1357625196b8`; SHA256`cb986554ccfdf09d423b88d07cfb93f263e517acb18a09857a2916e1feffaf16`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B33_ENV_CH04-INT-003_THE_CANOE_SHED_V001.md](https://drive.google.com/file/d/1tjZIlCwCUy6PnotrH7sdAxYk2YKmXexg/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly timber canoe shed, open on the river side. Three dugout canoes lie on log cradles along the floor. Paddles hang on the back wall on pegs; a coil of rope hangs at the left, with a rack of small pots above. Two buckets, one holding dark liquid, sit near the right post. The river and a rocky bank are visible outside.

**Published flags (original wording, including any error reconciled below):**

> - F68 CONSISTENCY NOTE: the batch-6 record says CH04-INT-003 V002 replaced the shed with an open shelter and three dugouts. This V001 shows an enclosed-side timber shed with three dugouts, which fits the record as the pre-correction state. Not verified against the V002.
> - UNVERIFIED: the dark liquid in the bucket is not identified; no claim is made about its content or use.
> - UNVERIFIED: the paddle count and the rack's contents are not established at this scale.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Long open-river-side timber shed, solid boarded rear wall/paddle pegs, three long canoe-like hulls on log cradles, ropes and buckets. High upturned pointed hull ends; no unmistakable half-carved hull/adze/chips view.

**Independent assessment:** Three vessels satisfy count; open-sided walk-through thatch roof on posts and half-carved canoe beat are not established. Author's 'longboat' reading not exact identification; relative scale alone cannot prove over-length.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Three vessels satisfy count; open-sided walk-through thatch roof on posts and half-carved canoe beat are not established. Author's 'longboat' reading not exact identification; relative scale alone cannot prove over-length.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Three vessels satisfy count; open-sided walk-through thatch roof on posts and half-carved canoe beat are not established. Author's 'longboat' reading not exact identification; relative scale alone cannot prove over-length.

**Dependencies:** CH04_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Upon scope confirmation, use registered open roof/posts and demonstrable half-carved dugout/adze/chips; reconcile hull ends to approved dugout reference instead of naming European type or prescribing unsupported lengths. Unknown bucket contents remain unknown.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E53 source](https://drive.google.com/file/d/16E4umob2MQdXGMRt1M9upT5yYOJ8-3UV/view) — archive`assessments/E53.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b34"></a>

# B34 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B34` · **Filename:** `ENV_CH04-SET-002_THE_TWO_HOUSE_LANDING_V001.jpg`

**Source:** [1rYwLsX0S-MlqK-UArMF3MHUu1qc0QhwN](https://drive.google.com/file/d/1rYwLsX0S-MlqK-UArMF3MHUu1qc0QhwN/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** superseded creative evidence — preserve. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-SET-002` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A tiny landing of two houses and a smoke rack on a bend, half a day from the main settlement.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** 2 houses, rack, canoe.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`323741`bytes; MD5`ed93aa1347b35ad9528c4ce8b0c65c01`; SHA256`c8de9631f6a8551fecab3413af09effadfe71e59d46c4f744a7709ca9dcb8a43`.
- Research:`2602`bytes; MD5`5215313bfb703a222328b65c0b602997`; SHA256`120bb222d548e67a4aa0294d1f06404e1e1d69189e759b6e81965a465a000025`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B34_ENV_CH04-SET-002_THE_TWO_HOUSE_LANDING_V001.md](https://drive.google.com/file/d/1cN3Yh-Mpsh5D0k262Lp6g1e3RMNfMq9w/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly landing between two stilt houses on a muddy path. Both houses are thatched and raised on posts, with ladders to their doors. A line strung between posts carries strips of dried fish or cloth. Two dugouts sit in brown water in front of the landing, and palms and broad-leaved plants grow around. Pots and baskets sit by the houses.

**Published flags (original wording, including any error reconciled below):**

> - F68 CONSISTENCY NOTE: the batch-6 record says the CH04-SET-002 correction grounded both houses and set a freestanding smoke rack to one side. This V001 shows both houses raised on posts, which fits the record as the pre-correction state. The drying line is not a smoke rack; the record and this image differ in description and are recorded as such.
> - AMBIGUOUS OBJECT: the drying strips are unidentified (fish or cloth). This report does not decide which.
> - UNVERIFIED: the house construction and the landing's form are visual readings only.
> - ORIGINAL item; not approved by this report. The F68 flag that the exact approved staging is not in the author's context also applies.

## 05. Independent content findings

**Direct source observation:** Two raised post/stilt houses, ladders/decks, two canoes in foreground water, central ground path and line with hanging strips. No distinct freestanding smoking rack/fire confirmed; strips may be fish but pixels alone do not prove material/function.

**Independent assessment:** Two-house landing readable; house elevation directly conflicts with registered never-stilts architecture. Drying line is not proven smoke rack. Pending exact staging direction cannot be reconstructed from author rating.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Two-house landing readable; house elevation directly conflicts with registered never-stilts architecture. Drying line is not proven smoke rack. Pending exact staging direction cannot be reconstructed from author rating.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Two-house landing readable; house elevation directly conflicts with registered never-stilts architecture. Drying line is not proven smoke rack. Pending exact staging direction cannot be reconstructed from author rating.

**Dependencies:** CH04_SCOPE; LANDING_STAGING_REFERENCE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. After CH04 scope decision, ground houses per register and supply approved smoke-rack/landing staging; clarify strips rather than assert funerary or trade meaning. Do not turn author's strong rating into approval.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C15 source](https://drive.google.com/file/d/1VB5s6b3_tuiC475Aq7Z86XaBdPACu1db/view) — archive`assessments/C15.md`; [E54 source](https://drive.google.com/file/d/1Zjbufzzg6J4eL-OEKVZgBgNV8hMw1lig/view) — archive`assessments/E54.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b35"></a>

# B35 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B35` · **Filename:** `ENV_CH05-EXP-002_THE_HIDDEN_CAVE_V001.jpg`

**Source:** [1oMCsvO-dsL01rMpli_e1mwJs5wty-A57](https://drive.google.com/file/d/1oMCsvO-dsL01rMpli_e1mwJs5wty-A57/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH05-EXP-002` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A dry crack in the granite opening into a chamber about 8 m deep with a sand floor and bat roost.
> - Architecture: None built on the mountain; one hill village below. People only cut the rock or drive iron into it.
> - Materials: Granite, hand-forged iron, fibre rope, faded red cloth; mud and thatch in the village.
> - Lighting: Hard storm light; lightning white only, never coloured.
> **Required assets.** Cave, sand, bats (ambient).
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`287823`bytes; MD5`25eab40b09e9785a274353900d5d483f`; SHA256`2d1b954365a3e86f2f113341aa7794da2113987e6b7d3f9b8fbb636e781aa99e`.
- Research:`2118`bytes; MD5`07e6b95e0d3cf061944fc5227694738a`; SHA256`505a1e58d106d964b286eb2935b8dd2319292cee68ef10fd41fd153aca8177da`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B35_ENV_CH05-EXP-002_THE_HIDDEN_CAVE_V001.md](https://drive.google.com/file/d/1dtS9OocaixjuwHnBFsxgGx4iOoNaZAqe/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A dark painterly cave interior. A shaft of light falls from an opening in the upper centre onto a rubble floor of rocks and dry leaves. Ivy hangs from the left opening, which leads to a dark recess. A thin stream runs along the lower left. Rock walls rise on both sides.

**Published flags (original wording, including any error reconciled below):**

> - SETTING NOT ESTABLISHED: the cave's terrain is not placed; the research record's C16 finding flags CH05 geography as a failure. This image is not checked against the CH05 brief here.
> - UNVERIFIED: the rock formation and stream are visual readings only.
> - EXP item: an exploratory file; its status in the research record is not checked here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Dark rough cave with upper daylight opening, lush creeper at side, rock/leaf-litter floor and visible shallow stream winding across lower-left. Bats not clearly visible, no scale.

**Independent assessment:** Contradicts registered dry granite crack/sandy floor subject; image cannot establish geology or8m depth. C16 author's favourable rating does not settle these direct brief gaps.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Wet/skylit cavern conflicts with dry granite-crack, approximately 8 m sand-floor chamber and bat-roost direction.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Contradicts registered dry granite crack/sandy floor subject; image cannot establish geology or8m depth. C16 author's favourable rating does not settle these direct brief gaps.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Contradicts registered dry granite crack/sandy floor subject; image cannot establish geology or8m depth. C16 author's favourable rating does not settle these direct brief gaps.

**Dependencies:** CH05_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**CORRECTION REQUIRED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Wet/skylit cavern conflicts with dry granite-crack, approximately 8 m sand-floor chamber and bat-roost direction.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

If scope retained, rebrief to dry crack/sand-floor/chamber requirement and show scale/access evidence; ambient bats only within confirmed nonritual scope. No geology authentication from appearance.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b36"></a>

# B36 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B36` · **Filename:** `ENV_CH05-INT-001_THE_HERDERS_SHELTER_V001.jpg`

**Source:** [1OOnKZsctqMp19dzMhTrDqFLTTzRoRMf1](https://drive.google.com/file/d/1OOnKZsctqMp19dzMhTrDqFLTTzRoRMf1/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH05-INT-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A dry-stone windbreak roofed with poles and grass against a boulder, with a hearth and a goat-hair rope.
> - Architecture: None built on the mountain; one hill village below. People only cut the rock or drive iron into it.
> - Materials: Granite, hand-forged iron, fibre rope, faded red cloth; mud and thatch in the village.
> - Lighting: Hard storm light; lightning white only, never coloured.
> **Required assets.** Windbreak, roof, hearth.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`417217`bytes; MD5`04caf20e3eea50e47b27d4334f9af1fe`; SHA256`90aeb114b376e6668f8ba16dc25c9a1e84194728374d69d039029eb13a5c6293`.
- Research:`2460`bytes; MD5`e605412cf5b31e2b12901031b96e8028`; SHA256`26ceacf5a84d0a37b8ae3e997c17149f4fdd189cc1639958c45aade6112f408d`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B36_ENV_CH05-INT-001_THE_HERDERS_SHELTER_V001.md](https://drive.google.com/file/d/15S7sUdkLvF72je2iJ_gGr1v5JchV6bIP/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly highland shelter built against a rock face. A dry-stone wall with a thatch lean-to roof shelters a recess with a raised stone bench holding folded cloth. A wicker-walled side and timber posts close the open side. A brown pot stands on the ground, and a staff leans against the wall. Dry tawny hills and a blue sky with clouds lie beyond.

**Published flags (original wording, including any error reconciled below):**

> - SETTING NOT ESTABLISHED: the dry highland landscape does not match the forest and river settings of the CH01–CH04 images. The research record's C16 finding flags CH05 geography as a failure; this image is not checked against the CH05 brief here and the location is not identified.
> - UNVERIFIED: 'herders' is the file name's label; the image shows no herder or animal, and the use of the shelter is not established.
> - UNVERIFIED: the staff and cord's use is not established.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Low grass/thatch lean-to against large rock, dry-stone flank/wattle side, wooden supports, bedding/stone bench, pot and staff with rope-like loop; dry tawny rolling terrain, no snow. Hearth not clearly shown.

**Independent assessment:** Broadly closer to LMR windbreak/poles/grass/boulder than C16's generalised setting-failure label implies. Comparing CH05 to forest/river chapters is not evidence of failure: CH05 intentionally differs. Goat-hair fibre and exact location cannot be authenticated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Required hearth not legible; isolated-granite-dome geography conflict retained.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Broadly closer to LMR windbreak/poles/grass/boulder than C16's generalised setting-failure label implies. Comparing CH05 to forest/river chapters is not evidence of failure: CH05 intentionally differs. Goat-hair fibre and exact location cannot be authenticated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Broadly closer to LMR windbreak/poles/grass/boulder than C16's generalised setting-failure label implies. Comparing CH05 to forest/river chapters is not evidence of failure: CH05 intentionally differs. Goat-hair fibre and exact location cannot be authenticated.

**Dependencies:** CH05_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Required hearth not legible; isolated-granite-dome geography conflict retained.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD for CH05 scope and source-confirmed hearth/rope/terrain details; do not demand forest backdrop merely because CH01-04 differ. No supported full-redo instruction from Research's scope-limited caveat alone.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b37"></a>

# B37 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B37` · **Filename:** `ENV_CH05-INT-002_A_VILLAGE_HOUSE_V001.jpg`

**Source:** [145CTWxRCA0LQtYj3QNTGqFGNVmPLwSgg](https://drive.google.com/file/d/145CTWxRCA0LQtYj3QNTGqFGNVmPLwSgg/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH05-INT-002` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A hill house on a boulder footing: low door against the wind, hearth in the middle, goatskins, stored grain.
> - Architecture: None built on the mountain; one hill village below. People only cut the rock or drive iron into it.
> - Materials: Granite, hand-forged iron, fibre rope, faded red cloth; mud and thatch in the village.
> - Lighting: Hard storm light; lightning white only, never coloured.
> **Required assets.** House shell, hearth, skins.
> **Notes.** 2 dressed variants. In The Last Village.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`357609`bytes; MD5`fd01a4a12b72a45b2f92c6890f2fd1aa`; SHA256`7a5a8a442eb68fd0f3503b6e23bb236c03cc40c84c9736899abba4e935b4a7d7`.
- Research:`2501`bytes; MD5`d20eb19e651fe45caff132c8a1710fca`; SHA256`66bbb9e1b7e27499a04ee58d6b98223ccfe904785ef6d6812fafba661738bc2b`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B37_ENV_CH05-INT-002_A_VILLAGE_HOUSE_V001.md](https://drive.google.com/file/d/1PgEBsm8dCIn_HkzMMuoJL1BQTJFWfpdH/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly interior-front of a stone-and-mud house in heavy rain. A thatched roof with rain streaks overhangs the front. Inside the open doorway a hearth burns with a black pot on stones; a shelf holds pots and jars; a bed platform with a thatch mat sits in a recess at the left; a shallow bowl of grain and a stool sit on the floor. A timber plank door with an iron latch is at the right. Other thatched houses and a wet track lie below on the right, under dark mountains.

**Published flags (original wording, including any error reconciled below):**

> - SETTING NOT ESTABLISHED: the highland stone and mud architecture is not placed; it differs from the forest and river architecture of the CH01–CH04 images. The research record's C16 finding flags CH05 geography as a failure; not checked against the brief here.
> - UNVERIFIED: the grain's type and the pot contents are not identified.
> - UNVERIFIED: the rain and wet ground are depicted effects only.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Rainy hill-house cutaway/front, stone-heavy walls, thatch, recessed bed at left, small burning wall hearth under shelf, grain bowl and plank door; sharply ridged dark mountains and similar houses beyond.

**Independent assessment:** Shelter/hearth/grain readable but registered hearth in middle, low-door/boulder-footing/goatskin features not clearly met. Mountain form does not demonstrate isolated granite dome. Avoid asserting Welsh/Scottish identity as fact.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Wall fireplace/stone-cottage treatment replaces central-hearth mud-house direction; geography drift retained.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Shelter/hearth/grain readable but registered hearth in middle, low-door/boulder-footing/goatskin features not clearly met. Mountain form does not demonstrate isolated granite dome. Avoid asserting Welsh/Scottish identity as fact.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Shelter/hearth/grain readable but registered hearth in middle, low-door/boulder-footing/goatskin features not clearly met. Mountain form does not demonstrate isolated granite dome. Avoid asserting Welsh/Scottish identity as fact.

**Dependencies:** CH05_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**CORRECTION REQUIRED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Wall fireplace/stone-cottage treatment replaces central-hearth mud-house direction; geography drift retained.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

After scope decision, reconcile hearth placement/house material kit and boulder footing to registered direction, and terrain to approved rounded-dome reference; do not invent ethnographic house style or numeric doorway dimensions.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b38"></a>

# B38 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B38` · **Filename:** `ENV_CH05-LMK-002_THE_ABANDONED_WATCHPOST_V001.jpg`

**Source:** [1y4efClikpBy8l_MgzOJjvSnq7ASYbR1_](https://drive.google.com/file/d/1y4efClikpBy8l_MgzOJjvSnq7ASYbR1_/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH05-LMK-002` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A platform of poles on a boulder overlooking the plain, its ladder half gone, a slit drum split by lightning.
> - Architecture: None built on the mountain; one hill village below. People only cut the rock or drive iron into it.
> - Materials: Granite, hand-forged iron, fibre rope, faded red cloth; mud and thatch in the village.
> - Lighting: Hard storm light; lightning white only, never coloured.
> **Required assets.** Platform, ladder, split drum.
> **Notes.** Platform reachable by climbing; no hut.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`279698`bytes; MD5`870ae1174e70b77d23973470d7236439`; SHA256`8649b4b307398ff22a80880ca3b08ba18c3828ba606fc2955a6d869427b1b29f`.
- Research:`2373`bytes; MD5`e1c2794f6e602c2822d244ab0d3f88c8`; SHA256`6aaf7bf9aa4efe6799bf93a25377a66044ddab0c7d241869b07d479956cbb322`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B38_ENV_CH05-LMK-002_THE_ABANDONED_WATCHPOST_V001.md](https://drive.google.com/file/d/1WV7jHnoOoEzdVTjGX2EMB6aV_QC1AFYY/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly view of a ruined round stone structure on a grassy mountain ridge. Its walls are dry-stone, with a doorway opening on the front. The top is open, with a frame of brushwood or lath sticking up at an angle, partly collapsed. A rubble heap of stones lies against the base at the right. Mountain ridges and cloud fill the background.

**Published flags (original wording, including any error reconciled below):**

> - INTERPRETATION NOT ESTABLISHED: the file name calls it an abandoned watchpost. The image shows a ruined round stone structure; its use as a watch point is not established by the image.
> - UNVERIFIED: the brushwood frame's material and original form are not identified.
> - SETTING NOT ESTABLISHED: the highland location is not placed; the C16 CH05 geography flag applies to this set and is not checked here.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Substantial round masonry tower ruin with doorway and collapsed woven roof frame, rubble pile on exposed ridge; background jagged multi-peak mountains. No pole platform/half-gone ladder/split slit drum identifiable.

**Independent assessment:** Directly fails registered CH05-LMK-002 platform-of-poles on boulder/no hut subject; exact European provenance is unnecessary and unsupported. Not merely a small roof correction.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Stone tower/range backdrop replaces pole platform on boulder, half-ladder and lightning-split slit drum.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Directly fails registered CH05-LMK-002 platform-of-poles on boulder/no hut subject; exact European provenance is unnecessary and unsupported. Not merely a small roof correction.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Directly fails registered CH05-LMK-002 platform-of-poles on boulder/no hut subject; exact European provenance is unnecessary and unsupported. Not merely a small roof correction.

**Dependencies:** CH05_SCOPE; SPLIT_DRUM_REFERENCE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**REJECTION RECOMMENDED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Stone tower/range backdrop replaces pole platform on boulder, half-ladder and lightning-split slit drum.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

REJECTION RECOMMENDED for submitted watchpost design. Owner confirms proposed setting; Research/CD must specify platform/ladder/drum (including cultural gate for drum) before separately authorised new brief. No generic round-tower patch.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b39"></a>

# B39 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B39` · **Filename:** `ENV_CH05-SET-002_THE_UPPER_HAMLET_V001.jpg`

**Source:** [1FodM5tkMCetTrp3e1ln4T-_Fb9rKGuv3](https://drive.google.com/file/d/1FodM5tkMCetTrp3e1ln4T-_Fb9rKGuv3/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH05-SET-002` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Three houses and a terrace wall higher than the village, lived in by one family that will not move down.
> - Architecture: None built on the mountain; one hill village below. People only cut the rock or drive iron into it.
> - Materials: Granite, hand-forged iron, fibre rope, faded red cloth; mud and thatch in the village.
> - Lighting: Hard storm light; lightning white only, never coloured.
> **Required assets.** 3 houses, terrace, livestock.
> **Notes.** Rams are ordinary livestock (OAD-19).

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`276360`bytes; MD5`2df390431801009ed46a2fd4d56d3eef`; SHA256`8fa5d3942d406cff5c8313c00ad6186ae8061e96452cfa4ee667cb069635e5a7`.
- Research:`2144`bytes; MD5`c5fc5ca11772af77b4a8abae5ca410ad`; SHA256`6a04e624f1e9ba91a77e7864a68d01ae75e12428adc9cd366f7317b3b88c8611`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B39_ENV_CH05-SET-002_THE_UPPER_HAMLET_V001.md](https://drive.google.com/file/d/1kqY9jv3pqcwVAayM7fGChMQa5IIOlauU/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly highland hamlet on terraced grassland. Low dry-stone houses with thatched roofs and a few chimney stacks sit on the slopes; stone retaining walls and stone steps link the levels. A grassy open space lies at the centre. Steep mountains and cloud fill the background.

**Published flags (original wording, including any error reconciled below):**

> - SETTING NOT ESTABLISHED: the highland hamlet is not placed; its fit to the CH05 brief is not checked here; the C16 CH05 geography flag applies.
> - UNVERIFIED: the chimney stacks and thatch material are visual readings only.
> - UNVERIFIED: the snow on the peaks is a depicted feature; the altitude and climate are not established.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Many stone-walled, chimneyed thatch houses on stepped terraces against jagged mountain ranges; well over three principal houses; no ordinary livestock clearly visible. Pale high-peak areas cannot be geologically authenticated from image.

**Independent assessment:** Fails registered3-house single-family scale and isolated rounded-dome/mud-thatch village direction; chimneys and stone-town programme not established. Do not state exact Apennine location or snow as measured fact.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Multi-house stone mountain village replaces the three-house mud/thatch settlement and isolated-dome setting.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Fails registered3-house single-family scale and isolated rounded-dome/mud-thatch village direction; chimneys and stone-town programme not established. Do not state exact Apennine location or snow as measured fact.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Fails registered3-house single-family scale and isolated rounded-dome/mud-thatch village direction; chimneys and stone-town programme not established. Do not state exact Apennine location or snow as measured fact.

**Dependencies:** CH05_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**REJECTION RECOMMENDED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Multi-house stone mountain village replaces the three-house mud/thatch settlement and isolated-dome setting.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

REJECTION RECOMMENDED for current Upper Hamlet use; scope/rebrief must restore3-house terrace family settlement and approved terrain/material kit; ordinary livestock only if approved scope. No unsupported global ban on stone footings.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b40"></a>

# B40 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B40` · **Filename:** `ENV_CH05-SUB-003_THE_CLIMBERS_CAMP_V001.jpg`

**Source:** [17uomx2sn8Jp8p7GZQFqzJz7zlBNOThg7](https://drive.google.com/file/d/17uomx2sn8Jp8p7GZQFqzJz7zlBNOThg7/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH05-SUB-003` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A flat shelf where people who meant to go up stopped: two hearths, a bundle never collected.
> - Architecture: None built on the mountain; one hill village below. People only cut the rock or drive iron into it.
> - Materials: Granite, hand-forged iron, fibre rope, faded red cloth; mud and thatch in the village.
> - Lighting: Hard storm light; lightning white only, never coloured.
> **Required assets.** Hearths, bundle, mats.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`319527`bytes; MD5`97d405e15e2969515e4a3329c3202975`; SHA256`0912850cf37e459a634708245c8b203722fac1230042abc92aa96da89f8eeedf`.
- Research:`2332`bytes; MD5`d35166c0d9d499caa1d26d0b5d9205de`; SHA256`84435272a3ac645e65a122f7534958d93ce662d4f36f0f035066a30c2fcc409b`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B40_ENV_CH05-SUB-003_THE_CLIMBERS_CAMP_V001.md](https://drive.google.com/file/d/1L0rXx1mClZKMPslFnyRZlmlRgN_Ru3id/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly rock ledge on a cliff face above cloud-filled valleys. A wooden rung ladder leans against the rock at the left. Two lean-to shelters, each with a timber A-frame and a hide or mat cover, stand against the rock. A ring of stones sits in the centre, and coiled rope lies at the lower right beside a fallen pile of poles.

**Published flags (original wording, including any error reconciled below):**

> - NAME-LABEL ONLY: the file name calls it a climbers' camp. The image shows a ledge with shelters and a ladder; the use is not established by the image.
> - UNVERIFIED: the ring of stones is not identified; the image does not show whether it held a fire.
> - UNVERIFIED: the cover materials are not identified.
> - SAFETY NOTE: the ledge is shown at a cliff edge; this report makes no claim about its safety for use.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Narrow cliff ledge above misty serrated peaks, two hide/mat-like lean-tos, pole ladder, one stone ring with dark centre, rope coils and loose poles. No clearly identified uncollected bundle or second hearth.

**Independent assessment:** Camp cues visible, but registered flat-shelf/two-hearth/bundle beat and isolated dome terrain not established. Ring is not proven hearth or ritual object. Dramatic cliff image is not evidence of safe traversal.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Cliff-camp geography and missing clearly delivered two-hearth/bundle/mat staging remain recorded.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Camp cues visible, but registered flat-shelf/two-hearth/bundle beat and isolated dome terrain not established. Ring is not proven hearth or ritual object. Dramatic cliff image is not evidence of safe traversal.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Camp cues visible, but registered flat-shelf/two-hearth/bundle beat and isolated dome terrain not established. Ring is not proven hearth or ritual object. Dramatic cliff image is not evidence of safe traversal.

**Dependencies:** CH05_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**CORRECTION REQUIRED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Cliff-camp geography and missing clearly delivered two-hearth/bundle/mat staging remain recorded.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

CD settles scope and required shelf/camp staging; reconcile terrain and make two-hearth/bundle beat legible if retained. Do not invent climbing-safety engineering or treat unidentified ring as sacred.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b41"></a>

# B41 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B41` · **Filename:** `ENV_CH06-INT-004_A_ROOM_THAT_EXPECTS_YOU_V001.jpg`

**Source:** [1C--Ojw2kN2G_-VmHbac4lMXEDRLJslyb](https://drive.google.com/file/d/1C--Ojw2kN2G_-VmHbac4lMXEDRLJslyb/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH06-INT-004` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A private room laid out for a guest: mat, water pot, folded cloth, all slightly too new.
> - Architecture: The home settlement's earthen architecture, copied imperfectly.
> - Materials: Laterite mud, palm thatch, hardwood, pale raw wood, still water, hammered bronze. No glass.
> - Lighting: Shadowless dusk with a dull warm glow from no source.
> **Required assets.** Room kit.
> **Notes.** Private illusion chamber. No inhabitants shown.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`172472`bytes; MD5`705516f8cb143eee9525b70fd354490d`; SHA256`45f1535e3e31c7c7cb8781f25cab4347be552a2de3d9d093a4ac23cb2b99fd1b`.
- Research:`2456`bytes; MD5`b1f54c182e6df1b978c2e6a0cf6a74f3`; SHA256`ab6560b98c51a211d2ca50e0b82395412589a4767ba7989ab556cedeeffec4f9`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B41_ENV_CH06-INT-004_A_ROOM_THAT_EXPECTS_YOU_V001.md](https://drive.google.com/file/d/1qrk3FikPnbRU7oS2xKXe9rTPkiN8oC-F/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly interior of a plain, pale-walled room. A single bed with a white pillow and sheet stands at the right beside a window with a dark sky outside. A wooden armchair faces the room in the centre. A dresser with a potted plant sits at the left, next to a wall sconce and a framed picture. An open door with a dark gap shows a second room beyond. A white cup sits on a bedside table.

**Published flags (original wording, including any error reconciled below):**

> - OUTSIDE THE ESTABLISHED RESEARCH BASE: per the standing refresh rules, B41 is not part of the established base. This report records the image only.
> - BATCH RECORD CONFLICT: the C16 record flags CH06 room failures. This report does not check the room against the CH06 brief and does not clear or confirm that finding.
> - UNVERIFIED: the room's period, the function of the empty chair, and the reason for the open door are not established by the image.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Pale furnished bedroom, metal-looking bedframe with pillow/white sheet, painted dresser, moulded-panel door and wall trim, upholstered chair, wall sconce and window/curtains with dark exterior. No guest mat/water pot/folded cloth as required room-kit cues.

**Independent assessment:** Direct conflict with LMR CH06-INT-004 imperfect-copy earthen-home-settlement/no-glass material brief and guest-room subject. Latest exact Research records pixels only and is OUTSIDE established research base; cannot supply cultural/canon clearance.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Modern bedroom/window/night treatment conflicts with earthen-home, no-glass, guest-mat/water-pot/folded-cloth and fixed-dusk direction.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Direct conflict with LMR CH06-INT-004 imperfect-copy earthen-home-settlement/no-glass material brief and guest-room subject. Latest exact Research records pixels only and is OUTSIDE established research base; cannot supply cultural/canon clearance.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Direct conflict with LMR CH06-INT-004 imperfect-copy earthen-home-settlement/no-glass material brief and guest-room subject. Latest exact Research records pixels only and is OUTSIDE established research base; cannot supply cultural/canon clearance.

**Dependencies:** CH06_SCOPE; RESEARCH_BASE_GAP

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**REJECTION RECOMMENDED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Modern bedroom/window/night treatment conflicts with earthen-home, no-glass, guest-mat/water-pot/folded-cloth and fixed-dusk direction.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

REJECTION RECOMMENDED for current submitted room. Owner/Research first establish CH06 scope and approved imperfect-home kit; separately authorised rebrief should use registered mat/pot/cloth and shadowless dusk, not patch this Western-type furnished room.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b42"></a>

# B42 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B42` · **Filename:** `ENV_CH06-INT-005_THE_FORGOTTEN_ROOM_V001.jpg`

**Source:** [1TdWrO3lkNCTHPqlrAgjFKkBfeth9wowP](https://drive.google.com/file/d/1TdWrO3lkNCTHPqlrAgjFKkBfeth9wowP/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH06-INT-005` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A room the kingdom has stopped remembering: walls fading to bare frame at the corners, objects without detail.
> - Architecture: The home settlement's earthen architecture, copied imperfectly.
> - Materials: Laterite mud, palm thatch, hardwood, pale raw wood, still water, hammered bronze. No glass.
> - Lighting: Shadowless dusk with a dull warm glow from no source.
> **Required assets.** Room kit in fading stages.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`258955`bytes; MD5`6eb6eb87b511e9be56bd95f81316295e`; SHA256`a7ceff70d41c3f68a13fa35f335b4098f8f300eb83e7a32d13b09c5c335978e8`.
- Research:`2643`bytes; MD5`e1e6e9027d6e2476bcd12a0b7f71b98c`; SHA256`eacf18fe41a056274a5492742c351df2927ce1bb4cc9a09fac1f4611b951a4b7`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B42_ENV_CH06-INT-005_THE_FORGOTTEN_ROOM_V001.md](https://drive.google.com/file/d/16bQOjSruVJaPz0TCxqiZ1Iz5-ivDvIVp/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A painterly, decayed room with peeling plaster, a tall wooden wardrobe with one door open, scattered dead leaves on the floorboards, cobwebs in the corners, a torn lace curtain at the left window, and a framed mirror on the back wall. At the right, a large object is draped with a pale, sheer cloth; its outline is not clear.

**Published flags (original wording, including any error reconciled below):**

> - OUTSIDE THE ESTABLISHED RESEARCH BASE: per the standing refresh rules, B42 is not part of the established base. This report records the image only.
> - SHROUDED FORM — NOT A FUNERARY MARKER: the draped object is not identified. Nothing in this file establishes that it is a body, a grave marker or any funerary object; this report does not make that reading.
> - BATCH RECORD CONFLICT: the C16 record flags CH06 room failures. This report does not check the room against the CH06 brief and does not clear or confirm that finding.
> - UNVERIFIED: the decay, cobwebs and leaves are depicted effects; they carry no evidential weight for period or use.
> - ORIGINAL item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Elaborate tall wardrobe, framed reflective mirror-like panel, fireplace/mantel, lace-like curtain, floorboards, cobwebs and draped upright furniture-like form. Contents under drape unidentified; no demonstrated human remains.

**Independent assessment:** Material/furniture/horror-decay programme conflicts with CH06-INT-005 no-glass earthen-home copy and fading-to-frame/object-detail-loss brief. A shrouded object is NOT established funerary evidence. Latest Research outside established base, no clearance.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Ornate decayed-room treatment replaces an earthen room fading to a bare frame through detail loss.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Material/furniture/horror-decay programme conflicts with CH06-INT-005 no-glass earthen-home copy and fading-to-frame/object-detail-loss brief. A shrouded object is NOT established funerary evidence. Latest Research outside established base, no clearance.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Material/furniture/horror-decay programme conflicts with CH06-INT-005 no-glass earthen-home copy and fading-to-frame/object-detail-loss brief. A shrouded object is NOT established funerary evidence. Latest Research outside established base, no clearance.

**Dependencies:** CH06_SCOPE; RESEARCH_BASE_GAP

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**REJECTION RECOMMENDED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Ornate decayed-room treatment replaces an earthen room fading to a bare frame through detail loss.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

REJECTION RECOMMENDED for this submitted room, not because of invented burial claim. Owner/Research establish fading-room grammar and approved kit before new brief; distinguish forgetting from ornate haunted-house decay.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C16 source](https://drive.google.com/file/d/1qbi6WbMMAWgCuWycafd9oJJTTJiaInaG/view) — archive`assessments/C16.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="b43"></a>

# B43 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `B43` · **Filename:** `PROP_ADANNA_SCABBARD_SIMPLE_LEATHER_V001.jpg`

**Source:** [1gAun9ET_l0Ro8-oD2yIeKILp9jBx0rjJ](https://drive.google.com/file/d/1gAun9ET_l0Ro8-oD2yIeKILp9jBx0rjJ/view) · Drive versionD2 · parent`1YUCfczTDGsdcMGz3favvphMabMR9q9PJ` (ORIGINAL).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1024×1536 JPEG; decoded modeRGB. 

- Source:`140951`bytes; MD5`5e7831862e0803edde1850bbc730b287`; SHA256`6af7be076a921037e3187fd886231bf2af39398f1f8723d4a665873daacfb024`.
- Research:`2384`bytes; MD5`656bae8cf27ff63178ef4837a4d07937`; SHA256`a58103e7d6cba509920bbf60dca0d04ff54da68c1cc410f7ea243a3d6e85f7e5`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[B43_PROP_ADANNA_SCABBARD_SIMPLE_LEATHER_V001.md](https://drive.google.com/file/d/1DQ4-4kZ-kWI9ypFc0cIzKHRsbghYRJ_m/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographed plain leather sheath on a dark grey backdrop, shown upright. The sheath is dark brown, with a stitched seam running down one edge, a loop at the top for a belt or cord, a band near the top, and a rounded tip with a small reinforcing tab. No blade is present in the sheath; no scale reference is visible.

**Published flags (original wording, including any error reconciled below):**

> - CQ-9 NOT CLEARED: this sheath does not establish the blade. The turnaround sheets (D01–D06) print 'CQ-9 blade and scabbard OPEN: no blade or scabbard is depicted here'. Per the standing refresh rules, B43 does not clear U-10 / D7; blade approval is separate.
> - SCALE NOT ESTABLISHED: no scale reference is visible; the sheath's size cannot be checked here.
> - UNVERIFIED: the leather type and finish are visual readings only.
> - PROP item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Portrait isolated brown leather-looking tapered sheath, plain stitched side seam, simple suspension loop and plain toe reinforcement. No blade, symbols/text/medallions or hand/character scale; mouth/hilt interface not shown in use.

**Independent assessment:** Visually consistent with submission's limited plain-leather artistic-prop claim. Does not establish blade fit, leather species, material authentication, length or rigging. CQ-9 remains independent. C08's 'approved plain decision' is submission assertion pending controlling owner record.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Visually consistent with submission's limited plain-leather artistic-prop claim. Does not establish blade fit, leather species, material authentication, length or rigging. CQ-9 remains independent. C08's 'approved plain decision' is submission assertion pending controlling owner record.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Visually consistent with submission's limited plain-leather artistic-prop claim. Does not establish blade fit, leather species, material authentication, length or rigging. CQ-9 remains independent. C08's 'approved plain decision' is submission assertion pending controlling owner record.

**Dependencies:** CQ-9; PROP_SCOPE_AUTHORITY; HAND_SCALE_INTERFACE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD integrated-weapon/production recommendation pending CD confirmation of standalone prop scope and CQ-9 design authority plus hand-scale/interface reference. No arbitrary resize, 60cm target, figure retouch or Adanna-version increment instructed. A limited aesthetic concept decision could be separated by owner; it is not made here.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C08 source](https://drive.google.com/file/d/1imiOKufYUwaj-hcc6ojlbQTwKnmUjGON/view) — archive`assessments/C08.md`; [F01 source](https://drive.google.com/file/d/1QFJ_9JSjmgNIiRhncDWfObk_cJsfi5SU/view) — archive`assessments/F01.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

