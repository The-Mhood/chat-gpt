from pathlib import Path
import json,hashlib,re,csv,collections,subprocess,zipfile
R=Path(__file__).resolve().parents[1];S=R/'_full_refresh_stage';O=R/'OUR_EYES_FULL_PENDING_REFRESH_v1';G=R/'google_drive'
rows=json.loads((S/'current_inventory_normalized.json').read_text());ass=json.loads((O/'ASSESSMENTS.json').read_text());ext=json.loads((O/'EXTERNAL_EVIDENCE.json').read_text())
def h(b,a='sha256'):return hashlib.new(a,b).hexdigest()
checks=[]
def check(name,test):
    if not test:raise AssertionError(name)
    checks.append({'check':name,'pass':True})
check('correct active repository branch',subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='arena/dd1d2707-chat-gpt')
check('tracked review pack/root screenshots and other tracked bytes unchanged',subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=R).returncode==0)
check('193 unique source IDs and193 unique report IDs',len(rows)==193 and len({r['source_id'] for r in rows})==193 and len({r['research_id'] for r in rows})==193)
check('scope split root1/original62/assistant130',collections.Counter(r['group'] for r in rows)=={'ROOT':1,'ORIGINAL':62,'ASSISTANT':130})
check('105 individually inspected rasters /88 fully read texts',sum(r['visual_inspected'] for r in rows)==105 and sum(r['source_text_read'] for r in rows)==88)
check('193 exact Research fully read/hash/body-ID verification flags',all(r['research_content_read'] and r['research_payload_hash_verified'] and r['research_body_source_identity_verified'] for r in rows))
for r in rows:
    sb=(G/r['name']).read_bytes();rb=(G/r['report_name']).read_bytes()
    check(r['code']+' source full payload MD5/size/SHA256',len(sb)==r['source_size'] and h(sb,'md5')==r['source_md5'] and h(sb)==r['source_sha256'])
    check(r['code']+' Research full payload fresh-metadata MD5/size/SHA256/body sourceID',len(rb)==r['research_drive_size'] and h(rb,'md5')==r['research_drive_md5'] and h(rb)==r['research_sha256'] and r['source_id'] in rb.decode())
    p=O/'assessments'/f'{r["code"]}.md';t=p.read_text();q=next(a for a in ass if a['code']==r['code'])
    check(r['code']+' individual12-component report/hash/identities',re.findall(r'^## (\d{2})\. ',t,re.M)==[f'{i:02}' for i in range(1,13)] and r['source_id'] in t and r['research_id'] in t and h(t.encode())==q['local_report_sha256'] and 'not an executed verdict' in t)
    check(r['code']+' report byte-mirrored in annex',t in (O/f'ASSESSMENTS_{r["code"][0]}.md').read_text())
for e in ext:
    b=(G/e['name']).read_bytes();check('external '+e['name'],len(b)==int(e['size']) and h(b,'md5')==e['md5'] and h(b)==e['local_sha256'])
check('23 exact external payloads verified',len(ext)==23 and all(e['payload_verified'] for e in ext))
check('trashed supplementary evidence remains marked historical',next(e for e in ext if e['source_id']=='1MwntmTwy44imNKFiV7ZGF5yGN5wX8y0r')['trashed']=='true')
check('88 documents/76 creative/26 comparison/1 diagnostic/2 blocked guides',collections.Counter(r['role'] for r in rows)=={'support record':88,'creative raster':76,'comparison aid':26,'diagnostic aid':1,'blocked retouch guide':2})
check('56 current-or-preserved /20 superseded creative',sum(r['role']=='creative raster' and not r['currency'].startswith('superseded') for r in rows)==56 and sum(r['currency'].startswith('superseded') for r in rows)==20)
old=[r for r in rows if 'standing_cd_outcome' in r]
check('exact38 prior image outcomes retained:6accepted21notapproved11blocked',collections.Counter(r['standing_cd_outcome'] for r in old)=={'ACCEPTED VISUAL PASS ONLY':6,'NOT APPROVED':21,'BLOCKED / PRESERVE':11})
v=(G/'OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md').read_text()
check('all38 prior current-cycle exactsource hashes still agree',all(r['source_id'] in v and r['source_md5'] in v for r in old))
check('six retained passes exactly intended currentV002s',{a['code'] for a in ass if a['recommendation'].startswith('RETAIN EXISTING')}=={'E15','E19','E20','E21','E47','E49'})
check('side/back preservedV003; H3 and item5 distinctholds',all(next(a for a in ass if a['code']==c)['recommendation']=='HOLD — PRESERVE V003 UNAPPROVED' for c in ['D01','D04']) and next(a for a in ass if a['code']=='D07')['recommendation']=='HOLD — H3 D9/RQ-01 UNCHANGED' and next(a for a in ass if a['code']=='D08')['recommendation']=='HOLD — MANDATORY ITEM5')
check('all88 support records assessed as documents, not artwork',all(a['recommendation']=='NOT ASSESSABLE AS ARTWORK — RETAIN DOCUMENTARY EVIDENCE' for a in ass if a['role']=='support record'))
check('review aids/superseded47 not new artwork approvals',sum(a['recommendation'].startswith('NOT ASSESSABLE FOR NEW') for a in ass)==47)
check('C07 reread contradiction corrected before publication','NOTE DOES state' in (O/'assessments'/'C07.md').read_text() and 'correctly reports' in (O/'assessments'/'C07.md').read_text())
check('F68 nine fullSHA256 candidate claims independently matched',all(r['source_sha256'] in (G/'SUBMISSION_BATCH6_CORRECTIONS_2026-11-18.md').read_text() for r in rows if r['code'] in [f'E{i}' for i in range(46,55)]))
check('E51 actual1376x768 recorded without false native target',next(r for r in rows if r['code']=='E51')['image_width']==1376 and next(r for r in rows if r['code']=='E51')['image_height']==768 and 'universal1536' in (O/'assessments'/'E51.md').read_text())
check('193 crosswalk rows identify193 reportfiles',len(list(csv.DictReader((O/'SOURCE_RESEARCH_CROSSWALK.csv').open())))==193 and len(list((O/'assessments').glob('*.md')))==193)
for p in [O/'MASTER.md',O/'INDEX.md',O/'ISSUES.md',O/'EVIDENCE_LIMITS.md',O/'README.md']:
    t=p.read_text()
    for u in re.findall(r'\]\(([^)]+)\)',t):
        if not u.startswith(('http://','https://','#')):
            check('valid local deliverable link '+p.name+' '+u,(p.parent/u.split('#')[0]).is_file())
check('publication has not been falsely flagged complete before verification',all(not r['assessment_published'] for r in rows))
qa={'status':'PASS — local assessment/package checks; Drive handoff pending separate verification','checks_passed':len(checks),'checks_failed':0,'assessment_reports':193,'components_per_report':12,'total_numbered_components':2316,'source_payloads_verified':193,'research_payloads_verified':193,'external_payloads_verified':23,'all_checks':checks,'boundary':'Assessment/documentation only; no artwork/status/hold/source/Research mutation. Local QA is not proof of canonical Drive publication.'}
(O/'QA_RESULTS.json').write_text(json.dumps(qa,indent=2,ensure_ascii=False)+'\n')
(O/'evidence'/'verify_and_package.py').write_bytes(Path(__file__).read_bytes())
# Later handoff files are intentionally outside this immutable assessment snapshot.
exclude={'PACKAGE_MANIFEST.json','SHA256SUMS.txt','OUR_EYES_FULL_PENDING_REFRESH_v1.zip','DRIVE_HANDOFF_RECEIPT_v1.md','PUBLICATION_VERIFIED.json'}
fs=sorted(p for p in O.rglob('*') if p.is_file() and p.name not in exclude)
manifest={'package':'OUR_EYES_FULL_PENDING_REFRESH_v1','scope':'193 twelve-component reports plus final master/index/issues/evidence-limits and method artifacts. No full source/report/artwork duplicates.','archive_exclusions':sorted(exclude),'files':[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'md5':h(p.read_bytes(),'md5'),'sha256':h(p.read_bytes())} for p in fs]}
(O/'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
fs.append(O/'PACKAGE_MANIFEST.json');fs=sorted(fs)
(O/'SHA256SUMS.txt').write_text(''.join(f'{h(p.read_bytes())}  {p.relative_to(O)}\n' for p in fs))
fs.append(O/'SHA256SUMS.txt');fs=sorted(fs)
zp=O/'OUR_EYES_FULL_PENDING_REFRESH_v1.zip'
with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in fs:
        i=zipfile.ZipInfo(str(p.relative_to(O)),date_time=(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o644<<16
        z.writestr(i,p.read_bytes())
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(fs)
    for p in fs:assert z.read(str(p.relative_to(O)))==p.read_bytes()
pack={'package_files':len(fs),'individual_reports':193,'zip_bytes':zp.stat().st_size,'zip_md5':h(zp.read_bytes(),'md5'),'zip_sha256':h(zp.read_bytes()),'local_qa_checks_passed':len(checks),'local_qa_checks_failed':0,'zip_entry_payloads_roundtrip_verified':True}
(S/'package_verification.json').write_text(json.dumps(pack,indent=2)+'\n')
# Exact immutable expected upload fingerprints are saved outside the downloads area.
names=['MASTER.md','INDEX.md','ISSUES.md','EVIDENCE_LIMITS.md',*[f'ASSESSMENTS_{g}.md' for g in 'ABCDEF'],'SOURCE_RESEARCH_CROSSWALK.csv','EXTERNAL_EVIDENCE.json','ASSESSMENTS.json','COUNTS.json','README.md','PACKAGE_MANIFEST.json','QA_RESULTS.json','SHA256SUMS.txt','OUR_EYES_FULL_PENDING_REFRESH_v1.zip']
u=[{'name':n,'file_path':str((O/n).relative_to(R)),'size':(O/n).stat().st_size,'md5':h((O/n).read_bytes(),'md5'),'sha256':h((O/n).read_bytes())} for n in names]
assert max(x['size'] for x in u)<100*1024*1024
(S/'publication_expected.json').write_text(json.dumps(u,indent=2)+'\n')
print(json.dumps(pack,indent=2));print('Expected19 new documentation uploads pinned. No Drive publication claimed.')
