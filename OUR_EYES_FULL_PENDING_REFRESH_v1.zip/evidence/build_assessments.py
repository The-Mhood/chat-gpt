from pathlib import Path
import csv, json, re, hashlib, collections, zipfile, io

ROOT=Path(__file__).resolve().parents[1]
ST=ROOT/'_full_refresh_stage'
SRC=ROOT/'google_drive'
OUT=ROOT/'OUR_EYES_FULL_PENDING_REFRESH_v1'
OUT.mkdir(exist_ok=True)
(OUT/'assessments').mkdir(exist_ok=True)
(OUT/'evidence').mkdir(exist_ok=True)
rows=json.loads((ST/'current_inventory_normalized.json').read_text())
by={r['code']:r for r in rows}
assert len(by)==193
support_rows=list(csv.DictReader((ST/'support_assessment_profiles.tsv').open(),delimiter='\t'))
profiles={r['code']:r for r in support_rows}
assert len(support_rows)==len(profiles)==88
assert all(set(p)=={'code','finding','research_reconciliation','next','links','dependencies'} and all(v for v in p.values()) for p in support_rows)
assert set(profiles)=={r['code'] for r in rows if r['role']=='support record'}
notes={}
for p in sorted(ST.glob('direct_visual_notes_*.json')):
    d=json.loads(p.read_text())
    for c,n in d['candidates'].items():
        assert c not in notes,c
        notes[c]=n.copy()
overrides=json.loads((ST/'formal_reconciliation_overrides.json').read_text())
for c,n in overrides['image_overrides'].items():
    notes[c].update(n)
# Superseded modern-context images are history, not evidence of a prohibited context.
notes['B14']['finding']='Photoreal contemporary market/context and patterned cloth are directly visible. C04 expressly claims owner cultural guidance; C07 supersedes this V001. Without the originating guidance, a global period/material or photoreal-style prohibition is not established. Textile and intended Home Settlement-state continuity remain unverified, not authenticated.'
notes['B14']['proposal']='Preserve V001 as superseded evidence; assess B15 under the actual originating context decision when supplied. No V001 redo, blanket period ban or unsupported locality claim.'
notes['B16']['finding']='Generic non-ritual assembly with contemporary clothing/metal roofs is visible. C04 claims owner context guidance and C07 supersedes this V001. Do not diagnose ceremony or reject solely by assuming an unverified period restriction; OAD55/56 and exact state-model context remain unconfirmed.'
notes['B16']['proposal']='Preserve V001 as superseded evidence; current B17 needs actual owner-guidance scope, not invented ritual correction or automatic regeneration.'
notes['B10']['finding']='Current native1264x843 and broad ring/cluster/gateway/curtain removal direction are directly supported. C05 discloses generative changes from B09 V002, not exact outside-mask preservation; B11 is a later distinct V004. Original owner instruction and ring function remain unverified.'
notes['B10']['proposal']='Preserve superseded V003 and use B11 for current technical/removal-scope decision. Do not demand native1536 detail from this1264 output or infer that ring absence settles identity.'
notes['D03']['proposal']='Retain the existing BLOCKED / no-full-pass outcome. If braided texture requires a future correction, CD must separately file a narrowly bounded cord-only instruction referencing the master and existing seven-correction scope. Do not invent thickness/pendant scale, redraw the figure or increment preserved side/back. No new verdict or action is executed here.'
notes['D04']['proposal']='PRESERVE V003 unchanged and unapproved under the existing CD verdict. Do not relabel V004, change pose/alignment/scale/likeness, invent unseen fastening or add a weapon. Outstanding design authorities remain open; no future assignment is activated by this review.'
notes['E51']['finding']='Nets and bank lean-to fit the proposed subject generally. Actual output is1376×768 versus F68’s stated source1672×941; this is not a native target-size pass and requires asset-specific technical acceptance, not an invented universal1536×1024 rule. Required cold fire and mending needle are not clearly legible. No definite smoke was reproduced and the utility knife is not an Adanna/CQ-9 blade specification.'
notes['D08']['dependencies']=['ESTABLISHING_ITEM5_COMPLETION_OR_EXPLICIT_CD_WAIVER','U-40','NNEKA_REFERENCE_CONTINUITY']
notes['D07']['dependencies']=['D9','RQ-01','VR011_VERSION_IDENTITY']
for cc in ['B03','B05','B07','B13']:
    notes[cc]['dependencies']=['ORIGINATING_OWNER_OVERRIDE','STATE_SERIES_LANDMARK_SCOPE']
notes['B11']['dependencies']=['ORIGINATING_REMOVAL_SCOPE','RESAMPLED_DELIVERY_ACCEPTANCE','ST04_RING_IDENTITY_REMAINS_HISTORICAL']
for cc in ['B15','B17']:
    notes[cc]['dependencies']=['ORIGINATING_OWNER_CULTURAL_GUIDANCE','INTENDED_MODERN_CONTEXT_VS_PARENT_STATE','OAD-55/56']
assert len(notes)==105

ext=json.loads((ST/'external_evidence_verified.json').read_text())['records']
extby={r['name']:r for r in ext}
def link(fid,label='open'):
    return f'[{label}](https://drive.google.com/file/d/{fid}/view)'
def rlink(c):
    return f'[{c}](../assessments/{c}.md)'
def digest(b,alg): return hashlib.new(alg,b).hexdigest()
def quote(t): return '\n'.join('> '+l if l else '>' for l in t.strip().splitlines())
def sec(t,n):
    m=re.search(rf'^## {n}\. [^\n]+\n(.*?)(?=^## |\Z)',t,re.M|re.S)
    assert m,(n,t[:100]);return m.group(1).strip()
def entry_blocks(path):
    t=path.read_text()
    return {m.group(1):m.group(0).strip() for m in re.finditer(r'^### (CH\d\d-[A-Z]+-\d{3})[^\n]*\n.*?(?=^### |\Z)',t,re.M|re.S)}
lmr=entry_blocks(ST/'registered_location_requirements_full.md')
scene=entry_blocks(ST/'applicable_CH01_scene_entries.md')
assert len(lmr)==23,(len(lmr),lmr.keys())
assert len(scene)==19,(len(scene),scene.keys())

def loc_id(r):
    if re.match(r'B(0[2-9]|1[0-7])$',r['code']):return 'CH01-SET-001'
    m=re.search(r'(CH\d\d-(?:INT|SUB|TRV|EXP|SET|LMK)-\d{3})',r['name'])
    return m.group(1) if m else None

def scene_id(r):
    m=re.search(r'(CH01-SCN-\d{3})',r['name']);return m.group(1) if m else None

def brief_excerpt(r):
    lid=loc_id(r);sid=scene_id(r)
    if lid in lmr:
        t=lmr[lid]
        lines=[l for l in t.splitlines() if l.startswith('**Description.') or l.startswith('- Architecture:') or l.startswith('- Materials:') or l.startswith('- Lighting:') or l.startswith('**Required assets.') or l.startswith('**Notes.')]
        return f'Canonical location entry `{lid}` ({link(extby["LOCATION_MASTER_REGISTER.md"]["source_id"],"register")}); proposed/design tiers are preserved:\n\n'+quote('\n'.join(lines))
    if sid in scene:
        t=scene[sid]
        # The entire relevant scene is checked; present concise unmodified source lines.
        scene_labels=['| Scene name','| Parent location ID','| Scene category','| Canon status','- **Physical description.','- **What the player sees.','- **What the player can interact with.','- **Can the player enter','- **NPCs present.','- **Lighting and atmosphere.','- **Required assets.']
        lines=[l for l in t.splitlines() if any(l.startswith(x) for x in scene_labels)]
        return f'Canonical scene entry `{sid}` ({link(extby["SCENE_AND_MICROLOCATION_MASTER_REGISTER.md"]["source_id"],"register")}), not automatically equivalent to the submitted habitat concept:\n\n'+quote('\n'.join(lines[:18]))
    if r['code'] in ['D01','D02','D03','D04','D05','D06','E22','E23'] or ('ADANNA' in r['name'] or 'COSTUME' in r['name']):
        return 'Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.'
    if r['code']=='D08' or 'ESTABLISHING' in r['name']:
        return f'Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ({link(extby["REJECTION_REPORT_ESTABLISHING_V012.md"]["source_id"],"brief")}) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.'
    if 'VR-011' in r['name']:
        return 'VR-011/H3 is independently held on D9/RQ-01 by the current CD record. Fictional framing never waives that gate. Filename/header/Field-of-Cloth subject mapping must not be resolved by visual similarity or version-number assumptions.'
    if 'VR-008' in r['name']:
        return 'Historical VR-008 correction evidence must be read by exact generation and method. Current V009 stays unchanged, exploratory composition only, never14_APPROVED_DESIGNS, with noV010 for four logged chrome errata. CQ-9/RQ-10-1/U-11 qualifications remain.'
    if 'VR-010' in r['name']:
        return 'Washing-place steps are domestic/exploratory history. Actual later CD decision accepts flush-grade runoff/off-frame outlet; U-27 domestic-only qualification remains. No engineering performance or ritual/cultural clearance follows from a plausible picture.'
    if r['role']=='blocked retouch guide':
        return 'Guide execution is blocked on blade authority before hand-scale and rigging; F01 withdraws arbitrary tip/percentage targets. No coordinate/60cm target is adopted as an approved design.'
    return 'Documentation-only record: current standing CD verdict outranks production-log ready labels, author recommendations and old queue counts. Proposed locations remain proposed; file existence, historical design approval and current limited visual acceptance are distinct.'

CONTROL='No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.'
LIMIT='Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.'

def control_refs(r):
    names=['OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md','OPEN_ART_DECISIONS.md','VISUAL_STYLE_GUIDE.md']
    if loc_id(r):names+=['LOCATION_MASTER_REGISTER.md','ENVIRONMENT_DESIGN_REGISTER.md']
    if scene_id(r):names+=['SCENE_AND_MICROLOCATION_MASTER_REGISTER.md','MOODBOARD_GENERATION_LIST.md','ENVIRONMENT_DESIGN_REGISTER.md']
    t=r['name']
    if any(x in t for x in ['ADANNA','COSTUME','VR-008','VR-006','VR-007']):names+=['CHARACTER_DESIGN_REGISTER.md','CHAR_ADANNA_MASTER_REFERENCE_V001.jpg','REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg','WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg']
    if 'ESTABLISHING' in t or r['code']=='D08':names+=['REJECTION_REPORT_ESTABLISHING_V012.md','ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg','ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg']
    return '\n'.join(f'- {link(extby[n]["source_id"],n)} — D{extby[n]["drive_version"]}; {extby[n]["read_scope"]}.' for n in dict.fromkeys(names))

allids={r['source_id']:r['code'] for r in rows}
allnames={r['name']:r['code'] for r in rows}
md5rows={r['source_md5']:r for r in rows}
sharows={r['source_sha256']:r for r in rows}
assessments=[]
for r in rows:
    c=r['code'];r['currency']=('documentary evidence — not an artwork candidate' if r['role']=='support record' else r['currency'])
    source=(SRC/r['name']).read_bytes();research=(SRC/r['report_name']).read_bytes();rt=research.decode()
    assert digest(source,'md5')==r['source_md5'] and len(source)==r['source_size']
    assert digest(source,'sha256')==r['source_sha256']
    assert digest(research,'md5')==r['research_drive_md5'] and len(research)==r['research_drive_size']
    assert digest(research,'sha256')==r['research_sha256']
    assert r['source_id'] in rt
    support=(r['role']=='support record')
    historical=r['currency'].startswith('superseded') or r['role'] in ['comparison aid','diagnostic aid']
    related=[];matches=[]
    if support:
        p=profiles[c];st=source.decode();finding=p['finding'];reconcile=p['research_reconciliation'];direction=p['next']
        deps=p['dependencies'].split(';');observation='Source text fully read. Its structure and specific claims, not a JPEG-style visual verdict, are assessed below.'
        rec='NOT ASSESSABLE AS ARTWORK — RETAIN DOCUMENTARY EVIDENCE'
        issue='DOCUMENTARY / AUTHORITY QUALIFICATION' if c not in ['F32'] else 'DOCUMENTARY COUNT ERRATUM'
        related=p['links'].split()
        for fid,code in allids.items():
            if fid in st and code!=c:related.append(code)
        for name,code in allnames.items():
            if name in st and code!=c:related.append(code)
        for h in set(re.findall(r'(?<![A-Za-z0-9])[a-fA-F0-9]{32}(?![A-Za-z0-9])',st)):
            if h.lower() in md5rows:matches.append((md5rows[h.lower()]['code'],'MD5',h.lower()))
        for h in set(re.findall(r'(?<![A-Za-z0-9])[a-fA-F0-9]{64}(?![A-Za-z0-9])',st)):
            if h.lower() in sharows:matches.append((sharows[h.lower()]['code'],'SHA256',h.lower()))
        matchtext=('\n'.join(f'- `{cc}` {alg} `{h}` matches independently hashed scoped bytes.' for cc,alg,h in sorted(matches)) or 'No embedded complete hash token independently matches a scoped source; this is not a finding that external/unlisted claims are false.')
        inspect='Downloaded exact text source and exact published Research payload; both fully read. Source MD5/size and Research fresh-metadata MD5/size independently matched; both SHA256s computed; Research body source-ID joined.'
        observation+='\n\n**Embedded-hash crosscheck (identified scoped matches only):**\n'+matchtext
    else:
        n=notes[c];finding=n['finding'];direction=n['proposal'];observation=n['observation'];reconcile=n['finding'];deps=n.get('dependencies',[])
        # Historical raster recommendation is not a new correction assignment or artwork approval.
        rec=('NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID' if historical else n['recommendation'])
        if not historical and n.get('scope')=='RETAIN EXISTING VISUAL PASS ONLY':rec='RETAIN EXISTING ACCEPTED VISUAL PASS ONLY'
        if c in ['D01','D04']:rec='HOLD — PRESERVE V003 UNAPPROVED'
        if c=='D07':rec='HOLD — H3 D9/RQ-01 UNCHANGED'
        if c=='D08':rec='HOLD — MANDATORY ITEM5'
        if r['role']=='blocked retouch guide':rec='HOLD — GUIDE EXECUTION BLOCKED'
        if historical:
            direction='**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. '+direction
        issue=('EVIDENCE-ONLY / HISTORICAL QUALIFICATION' if historical else ('NO NEW VISUAL DEFECT DECISION' if rec.startswith('RETAIN EXISTING') else 'BLOCKING FINAL-USE / SCOPE QUALIFICATION'))
        inspect='Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.'
        st=''
        # Related scoped records found in actual support by exact filename/ID, not inferred from number alone.
        for p in profiles.values():
            if c in p['links'].split():related.append(p['code'])
        # Exact-generation family links are navigational only, not authority for supersession.
        family=re.sub(r'_V\d{3}(?:_\d+x\d+)?','',r['name'])
        for rr in rows:
            if rr['code']!=c and re.sub(r'_V\d{3}(?:_\d+x\d+)?','',rr['name'])==family:related.append(rr['code'])
    related=sorted(set(related)-{c})
    assert all(cc in by for cc in related),(c,related)
    standing=r.get('standing_cd_outcome','Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.')
    if 'standing_cd_finding' in r:standing+=' — '+r['standing_cd_finding']
    dims=(f'{r["image_width"]}×{r["image_height"]} {r["image_format"]}; decoded mode{r["image_mode"]}. ' if 'image_width' in r else 'Text record; no visual artwork dimensions. ')
    brief=brief_excerpt(r)
    deptext='; '.join(deps) if deps else 'Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.'
    # Do not use arbitrary automatic artifact counts as evidence beyond the scope snapshot.
    relatedtext='; '.join(link(by[cc]['source_id'],cc+' source')+f' — archive`assessments/{cc}.md`' for cc in related) if related else 'No additional scoped exact source cross-link is required to identify this record.'
    if c in ['D03','D06']:
        inspect+=' Independent RGB test: `evidence/adanna_v004_pixel_verification.json`; four native neck crops are included. The test applies only to its recorded art rectangle and current V003→V004 pair, not alpha/cultural verification or V002→V003 geometry proof.'
    if c=='D08':
        inspect+=' Native foreground crop at(1080,740,1920,1244),840×504, is included as`evidence/ESTABLISHING_V013_foreground_native.png`; it is not a whole-frame figure-count proof.'
    brief_note=('For this support record, these constraints govern its claims/linked outputs, not a fictitious artwork brief. ' if support else '')+'A historical cited assignment is not permission for this refresh to perform it.'
    sections=[
        ('Identity, exact version and file role',f'**Scope code:** `{c}` · **Filename:** `{r["name"]}`\n\n**Source:** {link(r["source_id"],r["source_id"])} · Drive versionD{r["source_drive_version"]} · parent`{r["source_parent_id"]}` ({r["group"]}).\n\n**Role:** {r["role"]}. **Currency:** {r["currency"]}. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.'),
        ('Intended brief and authority',brief+'\n\n'+brief_note),
        ('Evidence actually inspected and integrity',inspect+'\n\n'+dims+f'\n\n- Source:`{r["source_size"]}`bytes; MD5`{r["source_md5"]}`; SHA256`{r["source_sha256"]}`.\n- Research:`{r["research_size"]}`bytes; MD5`{r["research_md5"]}`; SHA256`{r["research_sha256"]}`.\n\nBoth match their selected metadata snapshots. No source or Research payload was overwritten.'),
        ('Exact published Research and attributed summary',f'{link(r["research_id"],r["report_name"])} · Drive versionD{r["research_drive_version"]} · parent`{r["research_parent_id"]}`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.\n\n**Published summary (attributed, not newly verified merely by quotation):**\n\n'+quote(sec(rt,1))+'\n\n**Published flags (original wording, including any error reconciled below):**\n\n'+quote(sec(rt,4))),
        ('Independent content findings', '**Direct source observation:** '+observation+'\n\n**Independent assessment:** '+finding),
        ('Governing-register and standing-control crosschecks',control_refs(r)+'\n\n**Exact prior CD outcome, if present:** '+standing+'\n\nStyle is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.'),
        ('Agreement, disagreement and chronology reconciliation',reconcile+'\n\nAgreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.'),
        ('Issues, dependencies and priority',f'**Assessment issue class:** {issue}.\n\n**Specific issue:** {finding}\n\n**Dependencies:** {deptext}\n\nThe prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.'),
        ('Independent recommendation — not an executed verdict',f'**{rec}**\n\n**Existing CD record retained:** {standing}\n\nNo fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.'),
        ('Scoped future direction and decision required',direction+'\n\nThis is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.'),
        ('Preservation and non-actions',CONTROL+'\n\nNative V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.'),
        ('Evidence limits, closure owner and cross-links',LIMIT+'\n\n**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.\n\n**Related scoped records:** '+relatedtext+'\n\n**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.')
    ]
    text=f'# {c} — Independent PENDING assessment\n\n`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.\n\n'
    for i,(title,body) in enumerate(sections,1):text+=f'## {i:02}. {title}\n\n{body}\n\n'
    (OUT/'assessments'/f'{c}.md').write_text(text)
    recrow={'code':c,'name':r['name'],'role':r['role'],'currency':r['currency'],'recommendation':rec,'standing_cd_outcome':r.get('standing_cd_outcome','not in prior exact image manifest'),'source_id':r['source_id'],'research_id':r['research_id'],'dependencies':deps,'related_codes':related,'finding':finding,'future_direction':direction,'report_path':f'assessments/{c}.md','components':12,'local_report_sha256':digest(text.encode(),'sha256'),'embedded_scoped_hash_matches':len(matches)}
    assessments.append(recrow)
    r['assessment_complete']=True
    r['assessment_local_report']=recrow['report_path']
    r['independent_recommendation']=rec

# Keep all progress objects consistent; publication remains false until verified handoff.
(ST/'current_inventory_normalized.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
(ST/'scope_from_published_index.json').write_text(json.dumps({'provenance':'Derived refreshed progress view, not a pristine copy of the published index; A01 actual-source correction retained. Publication status must be read in the verified handoff receipt.','records':rows},indent=2,ensure_ascii=False)+'\n')
(OUT/'ASSESSMENTS.json').write_text(json.dumps(assessments,indent=2,ensure_ascii=False)+'\n')

# Six readable annexes mirror each individual report byte-for-byte after a navigational title.
for g in 'ABCDEF':
    rr=[r for r in rows if r['code'].startswith(g)]
    h=f'# Group {g} — {len(rr)} independent twelve-component assessments\n\nFile roles and historical/current recommendations are separate from the preserved CD6/21/12 result. Individual Markdown files are in the companion archive at `assessments/CODE.md`.\n\n'
    h+='\n'.join(f'- [{r["code"]}](#{r["code"].lower()}) — `{r["name"]}`' for r in rr)+'\n\n---\n\n'
    for r in rr:
        h+=f'<a id="{r["code"].lower()}"></a>\n\n'+(OUT/'assessments'/f'{r["code"]}.md').read_text()+'\n---\n\n'
    (OUT/f'ASSESSMENTS_{g}.md').write_text(h)

# Durable selected evidence preserves analytical method, not duplicate artwork payloads.
evidence_names=['current_inventory_normalized.json','direct_visual_notes_01.json','direct_visual_notes_02.json','direct_visual_notes_03.json','direct_visual_notes_04.json','direct_visual_notes_05.json','direct_visual_notes_06.json','formal_reconciliation_overrides.json','support_assessment_profiles.tsv','adanna_v004_pixel_verification.json','external_evidence_verified.json','external_metadata_snapshot.tsv','registered_location_requirements_full.md','applicable_CH01_scene_entries.md','image_metadata_snapshot.tsv','text_metadata_snapshot.tsv','research_live_metadata_snapshot.tsv','research_drive_ids.tsv']
for n in evidence_names:(OUT/'evidence'/n).write_bytes((ST/n).read_bytes())
for p in sorted((ST/'crops').glob('*.png')):
    (OUT/'evidence'/p.name).write_bytes(p.read_bytes())
(OUT/'evidence'/'build_assessments.py').write_bytes(Path(__file__).read_bytes())

# Complete immutable crosswalk, excluding workflow publication flags that later change.
fields=['code','group','name','role','currency','source_id','source_parent_id','source_drive_version','source_size','source_md5','source_sha256','report_name','research_id','research_parent_id','research_drive_version','research_size','research_md5','research_sha256','image_width','image_height','image_format','standing_cd_outcome','independent_recommendation','assessment_local_report']
with (OUT/'SOURCE_RESEARCH_CROSSWALK.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:r.get(k,'') for k in fields} for r in rows)
(OUT/'EXTERNAL_EVIDENCE.json').write_text(json.dumps(ext,indent=2,ensure_ascii=False)+'\n')

counts={'files':len(rows),'images':sum('image_width' in r for r in rows),'text_records':len(profiles),'role':dict(collections.Counter(r['role'] for r in rows)),'recommendation':dict(collections.Counter(a['recommendation'] for a in assessments)),'scope_by_group':dict(collections.Counter(r['group'] for r in rows)),'current_or_preserved_creative':sum(r['role']=='creative raster' and not r['currency'].startswith('superseded') for r in rows),'superseded_creative':sum(r['role']=='creative raster' and r['currency'].startswith('superseded') for r in rows),'external_verified':len(ext)}
(OUT/'COUNTS.json').write_text(json.dumps(counts,indent=2)+'\n')
print(json.dumps(counts,indent=2))
print('Created193 individual reports, each12 components; six annexes. Publication not yet verified.')
