from pathlib import Path
import json,csv,collections,re,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[1];ST=ROOT/'_full_refresh_stage';O=ROOT/'OUR_EYES_FULL_PENDING_REFRESH_v1'
a=json.loads((O/'ASSESSMENTS.json').read_text());b={r['code']:r for r in a}; inv=json.loads((ST/'current_inventory_normalized.json').read_text());by={r['code']:r for r in inv};co=json.loads((O/'COUNTS.json').read_text())
def codes(cs):return ', '.join(f'[{c}](assessments/{c}.md)' for c in cs)
def dl(fid,label):return f'[{label}](https://drive.google.com/file/d/{fid}/view)'
retain=[r['code'] for r in a if r['recommendation'].startswith('RETAIN EXISTING')]
holds=[r['code'] for r in a if r['role']=='creative raster' and r['recommendation'].startswith('HOLD')]
corr=[r['code'] for r in a if r['recommendation']=='CORRECTION REQUIRED']
rej=[r['code'] for r in a if r['recommendation']=='REJECTION RECOMMENDED']
assert [len(retain),len(holds),len(corr),len(rej)]==[6,36,9,5]
master=f'''# Our Eyes — Full PENDING assessment refresh
## Independent assessment package · version 1

**Assessment complete: 193 exact source/report pairs, each with a twelve-component individual report.** This is documentation and independent recommendation, not a new CD verdict or production assignment. Canonical publication is established only by the separate verified Drive handoff receipt, not by this document’s existence.

## 1. What was examined

| Submission area | Images | Text records | Total |
|---|---:|---:|---:|
| PENDING root | 0 | 1 | 1 |
| ORIGINAL_VA_SUBMISSIONS | 43 | 19 | 62 |
| ASSISTANT_VA_SUBMISSIONS | 62 | 68 | 130 |
| **Total** | **105** | **88** | **193** |

- All **193 source payloads** downloaded and independently matched to inventoried MD5/byte size; SHA-256 computed.
- All **193 exact published Research reports** downloaded, fully read and independently matched to fresh report metadata; report-body source IDs joined; SHA-256 computed. These are the 193-report family indexed by `00_INDEX_2026-11-18.md`, not substituted older RR/RR11 reports.
- All **105 images individually displayed**; all **88 source texts fully read**. Intake inspection of unchanged accepted images is not a repeat approval decision.
- **23 external evidence payloads** independently hash/size-verified. Relevant complete **23 location entries** and **19 CH01 scene entries** read, plus the governing documents and selected history identified in the evidence ledger. Neither large register nor the full historical art-bible index is claimed read end-to-end.
- Source/report scope and versions are a **snapshot**, not a perpetual assertion that Drive can never change. Dates in source filenames are preserved chronology, not new authority.

## 2. File roles — 193 files are not 193 artworks

| Role | Count | Treatment |
|---|---:|---|
| Current/preserved creative rasters | **56** | Includes six unchanged accepted visual outcomes, two preserved unapproved V003s, H3, Establishing and the separate B23 JPEG; not 56 approvals |
| Superseded creative rasters | **20** | Individually inspected historical evidence; no new approval/correction assigned to the obsolete file |
| Comparison aids | **26** | Historical presentation evidence, not raw current candidate masters |
| Diagnostic aid | **1** | Printed pixel map; arithmetic can be checked without claiming raw masks rerun |
| Blocked retouch guides | **2** | Guide execution remains blocked; no coordinates or percentages adopted |
| Support records | **88** | Individually assessed as documents, not artwork |
| **Total** | **193** | **105 raster files + 88 texts** |

B23 is a decoded, individually inspected JPEG with exact ID`1CFCPrQct-qvsw662-wOZAngxiXAOMfw3`. It is **not** the quarantined Markdown-under-JPEG-name object`1SsRkI8jhMeKC_VOSmRugvuMx3mo5O8uI`. Readable bytes do not establish recovered-original provenance or restoration authority. The completed quarantine/audit is not repeated.

## 3. Recommendation totals for this scope

These recommendations are not executed dispositions and do not replace the closed-cycle count below.

| Current/preserved creative images | Count |
|---|---:|
| Retain existing accepted visual pass only | **6** |
| HOLD / preserve / unresolved scope or evidence | **36** |
| Conditional/future-scope CORRECTION REQUIRED recommendation | **9** |
| REJECTION RECOMMENDED for the submitted intended use | **5** |
| **Current/preserved creative total** | **56** |

The two retouch guides separately remain **HOLD**. The other **135 records** (88 texts + 20 superseded images + 27 aids) receive evidence/role-specific assessments, **not new artwork verdicts**. NOT ASSESSABLE AS ARTWORK never means unread or unreviewed.

- **Retained passes:** {codes(retain)}.
- **HOLD current/preserved rasters:** {codes(holds)}.
- **Nine conditional/future-direction recommendations:** {codes(corr)}. E16 depends on whether full SCN024 scene staging, rather than a habitat parent, is the intended deliverable; no narrow historical brief is silently expanded.
- **Five rejection recommendations:** {codes(rej)}. These concern the submitted CH03/CH05/CH06 use, not removal, archival or regeneration authority.

## 4. Existing CD/user ruling remains intact

The {dl('1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O','standing current-review verdict')} remains **6 accepted visual passes / 21 not approved / 12 blocked**. All38 exact image members present in this inventory retain their source fingerprints and outcomes. The39th old manifest entry is the separately quarantined EXP text object, not B23.

- Sleeping Room, Back Plots, Streets, Wells, Gates and Roads V002 retain their accepted **current-cycle visual outcomes only**. No new cultural authentication, production canon, independent technical acceptance or promotion.
- All21 not-approved outcomes remain, including five historical V001 state boards now retained as superseded evidence. NOT APPROVED does not mean REVISE/REGENERATE/ARCHIVE/MOVE/DELETE.
- All12 blockers remain. LEFT_SIDE/BACK stay **V003 / PRESERVE / UNAPPROVED**; BACK viewer-left is anatomical LEFT. No automatic V004 or geometry, pose, alignment, scale, likeness or drawn LEFT-shoulder→RIGHT-hip baldric change.
- Establishing V013 remains **HOLD** until mandatory item5 is verified complete or explicitly waived by CD. The author’s haze/no-numeric-target explanation is not a waiver.
- H3 remains **D9/RQ-01 HOLD**, untouched and not freshly visually released. H1/H2 prior lifts remain visual-only.
- R6 stays closed; R7 unexecuted. Existing Adanna seven-correction scope, CQ-9/RQ-10-1/U-11 and OAD-55/56 qualifications stay separate and intact.
- VR-008 V009 and CH03-INT003 remain exploratory-only, never14_APPROVED_DESIGNS; noVR-008V010 for chrome errata. SCN028 remains blocked on Research+CD loom specification; SCN030 remains NOT RECOMMENDED/no patch or regeneration/replacement blocked pending CD+Research/living-custodian direction.

## 5. Consequential independent findings

1. **State-board authority needs exact scope, not an invented global rule.** C03–C09 cite later owner instructions, camera variance and modern-context ST06/ST07 guidance. The originating consolidated instruction was not independently found by the completed name/fullText searches. Do not assume it never existed, infer misconduct or dismiss an intended contemporary context under a blanket period ban. Current state proposals are held for that authority/intended-use decision. Photoreal grounded dark fantasy is expressly permitted by the in-review style guide.
2. **Native Adanna evidence is narrower and stronger than a reduced full-sheet read.** FRONT V003→V004 changes763 exact RGB art-box pixels, adding a neck connection, but braid texture remains unresolved. THREE_QUARTER changes16966 art-box pixels (mostly arm repair); native pendant still does not clearly reach the neck despite its author’s completion claim. Thresholds differ from the author’s audit, so differing counts are not themselves falsification. No geometry drift was detected in the tested art rectangle; V002→V003 equality, alpha and cultural status were not proved.
3. **Establishing item5 is explicitly unfinished.** Actual rejection brief, response and standing verdict agree on the outstanding basal-hut/left-flank item. Native foreground crop shows cord-linked plot stakes and side cloth, not a confirmed person. Do not conflate retained plot stakes with the separately removed house-side plank paling.
4. **Scene versus parent coverage is an owner decision.** SCN006/007/008/009/013/015/024 have material differences between registered scene beats and submitted habitat concepts. This does not authorise NPC generation, retroactively invalidate a narrow correction pass or reopen the six unchanged accepted visuals. Other scene/material/process references remain explicitly qualified.
5. **Latest CH03/CH04 detail issues remain scoped.** Firewood not legible in Kitchen; toy’s clay/wood-like material read unresolved; Passage walls’ concrete-like appearance does not prove composition; Fishing Shelter is actually1376×768 and cold-fire/technical acceptance unresolved, without a confirmed smoke diagnosis. Paddles are unclear in Riverbank House. Canoe Shed/Landing warm light conflicts with registered silver overcast; Landing’s stated brief is a **cold/unlit** side-set rack, so smoke must not be added merely to prove its function.
6. **Historical tier and report errors matter.** WashingV005 domestic-onlyU27, CostumeV002 interim partial upper-body and WallV005 exploratory outcomes were resolved from history; none is a full new approval. H2’s visual-only lift was TD-authorised, not self-created by the author. VR008V007 comparison linkage, log coverage and a few label/count interpretations require the non-destructive assessment errata in ISSUES.md; published Research stays untouched.

## 6. Deliverables and navigation

- [193-row index](INDEX.md): exact source/report links, roles, prior outcomes and recommendations.
- [Issues and decision queue](ISSUES.md): priorities, evidence, precise closure condition and responsible decision role; **not an execution queue**.
- [Evidence and limits](EVIDENCE_LIMITS.md): method, hashes, read extent, unavailable inputs, restricted claims and external ledger.
- `assessments/A01.md` through each indexed code: **193 individual12-component reports**. They are also byte-mirrored in six readable `ASSESSMENTS_A.md`–`ASSESSMENTS_F.md` annexes.
- `SOURCE_RESEARCH_CROSSWALK.csv`, `ASSESSMENTS.json`, `EXTERNAL_EVIDENCE.json`, `COUNTS.json`, local QA and SHA256 manifests.
- `evidence/`: provisional notes retained as provisional, final support profiles/reconciliation, exact metadata snapshots, native crops and analytical-test artifact. Final individual reports/assessment data override provisional interpretations; evidence is not silently rewritten as an artwork source.
- Companion ZIP contains the individual reports and evidence with a manifest; artwork/source/Research payloads are **not duplicated** into this documentation package. Canonical source links remain in the crosswalk.

## 7. Action boundary and publication

Only new documentation copies may be published under a dedicated folder in17_DOCUMENTATION/Production_Reports. Do not overwrite source, Research, the CD verdict, prior indices/logs or disposition registers. No artwork production, retouch, regeneration, promotion, copy/move, restore/trash/delete, permissions or gate changes are part of this refresh. Shared Drive publication is not proof of direct notification or individual receipt.

The separate `DRIVE_HANDOFF_RECEIPT_v1.md` records actual canonical IDs, parents and post-download hash checks. Until that receipt is verified, this package must not be described as a verified Drive handoff. No temporary intake material is cleanup-eligible before that verification.
'''
(O/'MASTER.md').write_text(master)

index='# Full PENDING refresh —193 exact-file assessment index\n\nVersion1 · All193 reports complete, each12 components. Individual paths are relative to the companion archive; the six group annexes mirror those files for convenient Drive reading. Current proposals, superseded images, aids and documents are not combined into an artwork count. No new approval or execution authority.\n\n'
index+='| Code | Role / currency | Exact source | Exact Research | Prior CD outcome | Independent recommendation | Individual report |\n|---|---|---|---|---|---|---|\n'
for r in a:
    e=by[r['code']]
    index+=f'| {r["code"]} | {r["role"]}; {r["currency"]} | {dl(e["source_id"],e["name"])} · D{e["source_drive_version"]} | {dl(e["research_id"],e["report_name"])} · D{e["research_drive_version"]} | {r["standing_cd_outcome"]} | {r["recommendation"]} | [{r["code"]}]({r["report_path"]}) · [annex{r["code"][0]}](ASSESSMENTS_{r["code"][0]}.md#{r["code"].lower()}) |\n'
(O/'INDEX.md').write_text(index)

issues=[
('G01','CONTROL — no execution','All193; standing39-entry CD manifest','No new artwork/status/hold/disposition authority.6/21/12 remains its own closed-cycle denominator, not the193-file count.','Preserve all standing outcomes and require a separately explicit CD instruction before any future correction/disposition.','CD/TD'),
('G02','HOLD — mandatory','D08; F14/F39/F40; E32','Actual V012 six-item brief and F40 NOTDONE establish outstanding basal-hut/left-flank item5; haze/no-target explanation is not a waiver.','Verified item5completion against the governing reference/marked target, OR an explicit CD waiver of that item. No inferred waiver or arbitrary percentage.','CD, then exact-file review'),
('G03','HOLD — cultural/dependency','D07; B01; C09; E40','H3 D9/RQ01 remains; new V003 is parallel, not release. Cargo is not proved bodies. FilenameV002/headerV001 and Field-of-Cloth/Landing mapping unresolved.','Non-destructive subject/version lineage note plus CD/Research decision on cloth/cargo/metaphor/locality and any reserved custodian consultation. Keep H3 untouched meanwhile.','CD + Research/custodian where required'),
('G04','PRESERVE / HOLD','D01/D04; F15/F34/F45','BACK viewer-left=anatomicalLEFT is settled. Side/back areV003 unapproved, not missingV004 outputs.','Retain exact geometry/pose/alignment/scale/likeness/baldric and openCQ9/RQ10/U11; only an explicit future ruling can change scope.','CD'),
('G05','HOLD / existing not-approved','D03/D06; F17; native RGB/crops','FRONT neck connection now supported but braid read unresolved. THREE_QUARTER chest-ending cord contradicts completion claim; arm repair improves and changes remain confined in tested art box.','CD decides a narrowly bounded existing-scope cord issue using master/native crop; preserve repaired arm and other pixels. No full rerender/side-back increments assigned now.','CD; Research for separate material/cultural gates'),
('G06','HOLD — authority first','B43; E44/E45; F01','Blade board exists but REVIEWREQUIRED/provisional60cm/nohandscale. Old guide65%/70%/coordinates are withdrawn; F01 handscale-bypass option conflicts with authority-first prerequisite.','Select blade-design authority before hand-scale/fit/rigging and any separately filed narrow direction. Standalone sheath aesthetic decision may be separate, never automatic weapon canon.','CD + Research'),
('G07','HOLD — originating scope','B03/B05/B07/B11/B13/B15/B17; C03-C09','Submissions cite later owner exceptions, accepted camera variance and modern cultural context; originating consolidated instruction was not independently located by scoped searches.','Attach exact owner guidance and define common landmark/model continuity, intended modern-context use and narrow removal/delivery acceptance. Do not infer absence globally or reject an authorised context by assumption.','Owner/CD'),
('G08','HOLD — identity remains historical','B09; B10/B11; C05/C06','Closed stone ring visible in B09 but function unproved. Later removal does not determine what it was. V003 native1264x843; V004 resampled1536x1024, not native larger detail.','Retain earlier ring-identity question; CD accepts/rejects current removal scope and native/resampled delivery with marked residual crop. No speculative ring/ritual or new-removal instruction.','CD + Research for contextual identity'),
('G09','HOLD — intended deliverable','E03/E04/E05/E06/E09/E11/E16 plus other CH01 scenes','Habitat concepts differ from registered store/sleepingcorner/roofrepair/veranda/behindstalls/gearpreparation/barehouse scene beats. Some narrow TD material corrections may nevertheless be addressed.','CD chooses parent/habitat versus complete scene coverage, then separately scopes any missing beat. OAD40/animal allowances must be settled before people/animals are added; no silent brief expansion.','CD + Research source-specific references'),
('G10','RETAIN blockers','E03/E07/E08/E12','LargeCompound textile/material, Smithy process/layout, Market closing/reference and Square pointed-gate idiom remain unresolved by inventories.','Reference-backed textile/material, smithing process, closing-state and accepted gateway decisions, respectively. No invented furnace/ritual/architecture specs.','CD + Research'),
('G11','HOLD / not-approved','E46/E48/E50','Kitchen firewood not legible; toy material unresolved; wall material/footprint termination uncertain. Ash versus alleged snow and concrete-like versus real concrete are not settled by labels.','Marked firewood/material/footprint targets and accepted chapter references in confirmed proposed scope. Any future correction bounded to exact issue; no asserted plant, weather or construction authentication.','CD + Research'),
('G12','HOLD — technical / brief','E51; F68','Actual1376x768 versus source1672x941. Cold hearth/needle not clear. Smoke allegation not independently confirmed; utility knife notCQ9 design.','Asset-specific dimension/aspect acceptance plus marked cold-fire/mending reference; no upscale relabelled as new native detail and no automatic smoke removal/addition.','CD; Research for gear'),
('G13','Future correction recommendation / staging HOLD','E52/E53/E54; F68','Paddles unclear in RiverbankHouse. Warm directional river light conflicts with silver-overcast chapter. Landing assignment explicitly cold/unlit side-set rack, not proof of required smoke.','CD lighting-state decision or explicit alternate scope, sourced paddle/staging reference. Preserve grounded houses, canoe counts, unfinished hull/chips; do not add active smoke/fire to prove rack use.','CD + Research'),
('G14','Proposed scope / future rejection or correction recommendation','B23/B29/B30/B35-B42; C15/C16','Several CH03/05/06 material/geography/microbeat mismatches; no exact foreign geography authenticated. Herders dry-stone windbreak is actually in its own proposed entry.','CD confirms proposed locations and accepted chapter kit/geography before any new brief. Respect isolated-dome/no-glass/dry-cave/doorway rules without invented dimensions or blanket stone bans.','CD + Research/custodian if cultural content'),
('G15','INTEGRITY — preserved external history','B23; F16/F45/F68; old quarantinedEXP object','Valid JPEG exactID differs from the quarantined textID. Completed quarantine/audit does not recover original or authorise restoration/replacement.','No repeat operation. Any recovery/disposition needs separate explicit authority and independently proven source provenance, never JPEG filename alone.','Owner/CD'),
('G16','Historical limited tiers / reserved gates','F11/F30/F35/F42; E24/E36/E39/E42','Washing domestic-onlyU27; Costume interim partial upper-body; Wall and VR008 exploratory only. Supplementary cultural review is currently TRASHED and is historical evidence, not live clearance.','Keep all limited tiers and open gates. NoV010 onVR008, no fullbodycanon from costume, no approved-folder promotion, no restoration of trashed review.','CD + Research'),
('D01','Research interpretation erratum','A01; C01/C02/C05; F04/F18/F25/F48/F55/F56','Wrong A01 index folder link; compatible crossdraw paraphrases; C05 sourceV002 presentB09; F04 actor inference contradicted by raw denial; C10 Wells not extra artwork; H2 lift TD-authorised; E26 incorrectly linked asVR008; logs omitpasses9/10 or contradictpass9 intermediate.','Use exact per-code assessment reconciliations. Preserve published Research and originals, optionally publish a later explicitly authorised erratum rather than silently edit them.','Documentation owner + Research'),
('D02','Raw documentary arithmetic / measurement qualifications','F32; E43/F49/F67','F32 five-vs-seven moves/eight-vs-nine candidates/fourteen-vs-fifteen list errors. E43 arithmetic is valid for1901x1169 art panel. F49 counts use different baselines. F67 own residuals qualify untouched-river wording.','Retain original counts and cross-reference corrected interpretation. Do not rerun historic moves or present old raw masks/pixel assertions as independently reproduced.','Documentation owner'),
('D03','Ownership history — no misconduct inference','F08/F09/F11/F21-F27','Older OriginalVA/rebrief ownership differs from later AssistantVA accounts; H1/H2 exact newer TD owner is confirmed, but no full delegation history was independently retrieved for every item.','Preserve chronology and request originating/newer assignment only if future work needs delegation. Do not infer unauthorised action merely from creator/folder or assign tasks now.','CD/TD'),
('D04','Intermediate/read-boundary limit','C07; F23/F53/F55/F56/F66','C07 explicitly says multi-panel attempts overwritten/not archived; local queue discarded often means notselected/retained, not deleted. Old native pairs/masks/scripts and most external final candidate rasters not independently inspected.','Keep source-specific distinctions and do not reconstruct unavailable attempts. Complete the necessary exact native comparison only when a later authorised decision needs it.','Research/reviewer under new scope')]
iss='# Full PENDING refresh — consolidated issues and evidence-limited decision queue\n\n**Not an artwork execution queue.** Priority means what blocks a claimed final use or needs documentary interpretation; it does not alter any standing CD verdict or authorise work. Per-code reports contain the full twelve components and exact source/report fingerprints.\n\n'
for ident,priority,scope,fact,close,owner in issues:
    iss+=f'## {ident} — {priority}\n\n- **Scope:** {scope}.\n- **Evidence/finding:** {fact}\n- **Precise closure condition / recommendation:** {close}\n- **Decision role:** {owner}.\n- **Executed by this refresh:** none; assessment and new documentation only.\n\n'
(O/'ISSUES.md').write_text(iss)

ext=json.loads((O/'EXTERNAL_EVIDENCE.json').read_text())
lim='''# Evidence coverage, provenance and limits

## Actual coverage

193/193 exact source payloads downloaded and MD5/size matched;193 SHA256s computed.193/193 exact published193-family Research payloads downloaded, fresh-metadata MD5/size matched and body source-ID joined;193 SHA256s computed.193 Research reports and88 source texts fully read.105 images individually displayed.193 complete twelve-component assessments, not just105 provisional notes. No payload mismatch remained.

The source inventory is root1/ORIGINAL62/ASSISTANT130 with no unlisted deeper PENDING scope found in the complete paginated traversal. Both Research195-entry traversals were complete:193 reports plus summary/index. This is a snapshot inventory, not a claim to have inspected every production/rejected/reference object in Drive. Initial/fresh metadata listings were manually transcribed into TSVs, not saved raw API JSON. A01's published index linked the PENDING folder; actual source object was independently resolved and verified.

All relevant23 complete LocationMaster entries and19 complete CH01 scene entries were read, including proposed/design/access/atmosphere/required-image fields. Entire534861-byte LocationMaster and279079-byte SceneMaster were downloaded/hash-verified but not read end-to-end. Environment, style, character, open decisions, moodboard, current CD verdict, cultural desk guide and identified supplementary/rejection/disposition history were fully read. The large v7 art-bible index was read only in identified selected sections/history; no whole-index content audit is claimed.

## What hashes and images establish

- Downloaded payload equals the selected Drive metadata fingerprint/size at that snapshot; independent local SHA256 pins the bytes used.
- Source ID, generation label, Drive version and report version are separate identity dimensions. Older RR11 report DriveD9 is not H3 dependencyD9 and is not the new193-family reportD2.
- Existing six accepted visual source fingerprints match exactly; retained visual outcomes are not a new decision or promotion.
- RGB tests on current Adanna V003→V004 compare the stated art rectangle only. They do not independently prove V002→V003 preservation, alpha masks, orthographic correctness, material braid detail or culture. Different thresholds/baselines explain many different counts.
- D08 foreground crop identifies short cord-linked stakes, but it is not a whole-frame figure census or item5 completion proof.
- E43 printed13618/2222269≈0.6128% is arithmetically consistent. Original raw masks/pair were not rerun; printed audit is not independent measurement merely because arithmetic works.

## What was not established

1. No external primary scholarship was newly retrieved/critically reread. Cultural guide and published Research statements remain attributed; a broad regional label is not a documented exact form. No new living-custodian/cultural-consultant clearance was obtained.
2. No source author’s old operation history, actor attribution, upload-parent bug cause or whole-Drive preservation was retrospectively proved by matching today’s staged bytes. A scoped zero-result query is not global absence or causal proof.
3. No exact physical composition/species/dimensions, body/remains identification, funeral/ritual identity or engineering performance from rendered appearance alone. Concrete-like/wood-like and labels such as mud/clay are material-read evidence, not chemical identification. CH03 white specks may match registered ash, not a proven snowfall/fire history.
4. Originating later owner Cultural-Guidance/override/removal instructions cited in C03-C09 were not independently located by the complete predicates actually searched (name and fullText). This does not prove they never existed, revoke them or authorise a blanket period/style rule. No unrestricted global authority-search claim.
5. Many native external historical candidate masters, working renders/masks/scripts and rejected local attempts were unavailable/not downloaded. Comparison JPEG panels do not prove embedded raw originals’ bytes or all outside-mask equality. Metadata-only Costume/Wall/Washing/VR008/history resolution is not direct native visual review. The primary Adanna master was displayed; its equal-metadata-hash approved duplicate was metadata-only, not a second downloaded-byte comparison.
6. C07 explicitly reports overwritten/unarchived multi-panel attempts; this is retained as author disclosure. Elsewhere discarded means unselected/retained locally where the source says so. No wider deletion event is inferred.
7. The supplementary gate review is trashed=true in retrieved metadata. It is historical evidence only, not current clearance, and it did not inspect H1/H2. Independently read TD reports/current user controls establish visual-only H1/H2 history; no restoration was attempted.
8. B23 validJPEG and the quarantined2537-byte Markdown object are distinct IDs. This refresh neither recovers missing original bytes nor repeats quarantine/restoration. No uploaded image was deemed valid artwork just from its extension.
9. No full technical/production-kit/scene coverage acceptance from a single moodboard frame or previously accepted limited material correction. Proposed location and source-design status remain separate from established story setting.
10. Publication is complete only when newly created canonical documents/ZIP have been read back with exact parents/bytes/hashes and the separate receipt records the result. No permission changes or direct notifications are part of publication.

## Scope of external byte verification

All23 local external payloads below matched the selected exact-ID metadata MD5/size and have independently computed SHA256s in EXTERNAL_EVIDENCE.json. Same-name duplicates found by search were not substituted. This selected ledger was manually transcribed from connector outputs; it is not a raw unfiltered API dump.

| File | Exact source / Drive version | Read/display extent | Trashed? | MD5 | Bytes |
|---|---|---|---|---|---:|
'''
for e in ext:lim+=f'| `{e["name"]}` | {dl(e["source_id"],e["source_id"])} D{e["drive_version"]} | {e["read_scope"]} | {e["trashed"]} | `{e["local_md5"]}` | {e["local_size"]} |\n'
lim+='\n## Precedence and reproducibility\n\nFinal individual assessments/ASSESSMENTS.json supersede provisional visual-note interpretations. Provisional notes are retained for audit, including subsequent corrections; they are not extra approvals or current correction briefs. All report templates carry twelve substantive components; unique per-file observations, source/Research quotes, reconciliation and scope-specific closure are separate from common controls. The supplied build/QA scripts rebuild from the staged exact source payloads and manually authored profiles; source downloads themselves stay at their canonical Drive IDs rather than being duplicated into this documentation archive.\n'
(O/'EVIDENCE_LIMITS.md').write_text(lim)

readme='''# Package guide

Start with MASTER.md, then INDEX.md. Read ISSUES.md and EVIDENCE_LIMITS.md before treating any recommendation as a future decision input.

-193 individual reports: assessments/CODE.md, each exactly12 numbered components.
-Six readable annexes: ASSESSMENTS_A.md to ASSESSMENTS_F.md; each mirrors individual report text. Source links work standalone; annex in-document jump support depends on the viewer.
-Each index row links exact Drive source and exact193-family published Research; candidate source generation is not report Drive version.
-CSV/JSON provide exact hashes, roles and independent recommendations. They are not an executed disposition register.
-Evidence contains manually transcribed metadata, provisional notes labelled provisional, final reconciliation/support profiles, relevant register extracts, native inspection crops and exact RGB test. Full source/report/artwork payloads are not duplicated.
-The six retained visual passes are the existing user outcomes only; all21not-approved and12blockers remain. R6closed/R7unexecuted, no new production.
-Canonical ZIP SHA256 and post-download verification are recorded by the separate Drive handoff receipt. The ZIP does not contain itself or that later receipt.
'''
(O/'README.md').write_text(readme)
(O/'evidence'/'finalize_package.py').write_bytes(Path(__file__).read_bytes())
print('Master/index/issues/evidence-limits created. No Drive publication claimed.')
