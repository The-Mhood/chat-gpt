# Group E — 54 independent twelve-component assessments

File roles and historical/current recommendations are separate from the preserved CD6/21/12 result. Individual Markdown files are in the companion archive at `assessments/CODE.md`.

- [E01](#e01) — `B2_CAND_ENV_CH01-EXP-003_THE_FORGOTTEN_PATH_V002_1672x941.jpg`
- [E02](#e02) — `B2_CAND_ENV_CH01-EXP-004_THE_SMALL_CLEARING_V002_1672x941.jpg`
- [E03](#e03) — `B2_CAND_SCENE_CH01-SCN-006_A_LARGE_FAMILY_COMPOUND_V002_1672x941.jpg`
- [E04](#e04) — `B2_CAND_SCENE_CH01-SCN-007_A_SMALL_FAMILY_HOUSE_V002_1672x941.jpg`
- [E05](#e05) — `B2_CAND_SCENE_CH01-SCN-008_A_SMALL_FAMILY_HOUSE_V002_1672x941.jpg`
- [E06](#e06) — `B2_CAND_SCENE_CH01-SCN-009_ELDERS_HOUSE_V002_1672x941.jpg`
- [E07](#e07) — `B2_CAND_SCENE_CH01-SCN-010_SMITHY_V002_1672x941.jpg`
- [E08](#e08) — `B2_CAND_SCENE_CH01-SCN-012_MARKET_STALLS_V002_1672x941.jpg`
- [E09](#e09) — `B2_CAND_SCENE_CH01-SCN-013_MARKET_BACKROOMS_V002_1672x941.jpg`
- [E10](#e10) — `B2_CAND_SCENE_CH01-SCN-014_WATER_COLLECTION_POINT_V002_1672x941.jpg`
- [E11](#e11) — `B2_CAND_SCENE_CH01-SCN-015_FISHING_STREAM_V002_1672x941.jpg`
- [E12](#e12) — `B2_CAND_SCENE_CH01-SCN-017_VILLAGE_SQUARE_V002_1672x941.jpg`
- [E13](#e13) — `B2_CAND_SCENE_CH01-SCN-019_GATE_GUARD_SHELTER_V002_1672x941.jpg`
- [E14](#e14) — `B2_CAND_SCENE_CH01-SCN-021_BACK_LANES_V002_1672x941.jpg`
- [E15](#e15) — `B2_CAND_SCENE_CH01-SCN-022_STREETS_V002_1672x941.jpg`
- [E16](#e16) — `B2_CAND_SCENE_CH01-SCN-024_AN_EMPTY_HOUSE_V002_1672x941.jpg`
- [E17](#e17) — `B2_CAND_SCENE_CH01-SCN-025_ANIMAL_PENS_V002_1672x941.jpg`
- [E18](#e18) — `B2_CAND_SCENE_CH01-SCN-027_POTTERS_YARD_V002_1672x941.jpg`
- [E19](#e19) — `B2_CAND_SCENE_CH01-SCN-032_WELLS_V002_1672x941.jpg`
- [E20](#e20) — `B2_CAND_SCENE_CH01-SCN-033_GATES_V002_1672x941.jpg`
- [E21](#e21) — `B2_CAND_SCENE_CH01-SCN-034_ROADS_V002_1672x941.jpg`
- [E22](#e22) — `B2_COMPARE_ADANNA_TURNAROUND_V002_alignment.jpg`
- [E23](#e23) — `B2_COMPARE_ADANNA_TURNAROUND_V003_alignment.jpg`
- [E24](#e24) — `B2_COMPARE_COSTUME_BREAKDOWN_V001_vs_V002.jpg`
- [E25](#e25) — `B2_COMPARE_ESTABLISHING.jpg`
- [E26](#e26) — `B2_COMPARE_ESTABLISHING_V005_vs_V007.jpg`
- [E27](#e27) — `B2_COMPARE_ESTABLISHING_V005_vs_V008.jpg`
- [E28](#e28) — `B2_COMPARE_ESTABLISHING_V008_vs_V009.jpg`
- [E29](#e29) — `B2_COMPARE_ESTABLISHING_V009_vs_V010.jpg`
- [E30](#e30) — `B2_COMPARE_ESTABLISHING_V010_vs_V011_CHROME.jpg`
- [E31](#e31) — `B2_COMPARE_ESTABLISHING_V011_vs_V012.jpg`
- [E32](#e32) — `B2_COMPARE_ESTABLISHING_V012_vs_V013.jpg`
- [E33](#e33) — `B2_COMPARE_VR-008.jpg`
- [E34](#e34) — `B2_COMPARE_VR-008_V005_to_V008_with_references.jpg`
- [E35](#e35) — `B2_COMPARE_VR-008_V005_vs_V007.jpg`
- [E36](#e36) — `B2_COMPARE_VR-008_V008_vs_V009.jpg`
- [E37](#e37) — `B2_COMPARE_VR-010.jpg`
- [E38](#e38) — `B2_COMPARE_VR-010_WASHING_PLACE_V002_vs_V004.jpg`
- [E39](#e39) — `B2_COMPARE_VR-010_WASHING_PLACE_V002_vs_V005.jpg`
- [E40](#e40) — `B2_COMPARE_VR-011.jpg`
- [E41](#e41) — `B2_COMPARE_WALL_OF_HOUSES.jpg`
- [E42](#e42) — `B2_COMPARE_WALL_OF_HOUSES_V003_vs_V005.jpg`
- [E43](#e43) — `B2_PIXELDIFF_VR-008_V007.jpg`
- [E44](#e44) — `B2_RETOUCH_GUIDE_VR-006_BLOCKED.jpg`
- [E45](#e45) — `B2_RETOUCH_GUIDE_VR-007_BLOCKED.jpg`
- [E46](#e46) — `ENV_CH03-INT-004_THE_FORGOTTEN_KITCHEN_V002.jpg`
- [E47](#e47) — `ENV_CH03-INT-005_A_SLEEPING_ROOM_V002.jpg`
- [E48](#e48) — `ENV_CH03-SUB-005_A_RESIDENTIAL_COURTYARD_V002.jpg`
- [E49](#e49) — `ENV_CH03-SUB-006_THE_BACK_PLOTS_V002.jpg`
- [E50](#e50) — `ENV_CH03-TRV-003_THE_NARROW_PASSAGES_V002.jpg`
- [E51](#e51) — `ENV_CH04-INT-001_A_FISHING_SHELTER_V002.jpg`
- [E52](#e52) — `ENV_CH04-INT-002_A_RIVERBANK_HOUSE_V002.jpg`
- [E53](#e53) — `ENV_CH04-INT-003_THE_CANOE_SHED_V002.jpg`
- [E54](#e54) — `ENV_CH04-SET-002_THE_TWO_HOUSE_LANDING_V002.jpg`

---

<a id="e01"></a>

# E01 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E01` · **Filename:** `B2_CAND_ENV_CH01-EXP-003_THE_FORGOTTEN_PATH_V002_1672x941.jpg`

**Source:** [1oGMObicz17rFr3O-HRXjjvRIbS2W3QQJ](https://drive.google.com/file/d/1oGMObicz17rFr3O-HRXjjvRIbS2W3QQJ/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-EXP-003` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A footpath almost closed by regrowth, marked only by old cut stumps and a line of flatter ground.
> - Architecture: None standing; only abandoned earthen compounds and posts.
> - Materials: Laterite mud, hardwood posts, palm thatch, fibre rope, white cotton cloth.
> - Lighting: Cool green shade; warm light only at the canopy; natural white shafts.
> **Required assets.** Regrowth set, cut stumps, path ground.
> **Notes.** Optional loop; leads nowhere important by design.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`848513`bytes; MD5`0c6e27076c876b6eaa5714d4b39b7a1e`; SHA256`43ddf105c199fcd94ab84974b7f6b758e3ea147e90fd5093061e09df1f340dce`.
- Research:`2617`bytes; MD5`4d1ba076ea966d1922b98fafda1125e6`; SHA256`27159f9c4fc06c8b89251d7e55efb0b6e27c81a892b77abdd63f7b14babeb292`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E01_B2_CAND_ENV_CH01-EXP-003_THE_FORGOTTEN_PATH_V002_1672x941.md](https://drive.google.com/file/d/1Cay5-8NdOwT_Ys8FtXyKG95VYcNXGUbj/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photoreal-style forest path through dense tropical forest. A reddish-brown dirt path runs between buttressed trunks, creepers and palms, with a fallen moss-covered log crossing the lower left and leaf litter and roots on the path. A misty light opening lies at the path's far end. A caption band at the bottom reads 'ENV_CH01-EXP-003 · THE FORGOTTEN PATH · V002 · EXPLORATORY — NOT APPROVED CANON · STATUS: REVIEW REQUIRED', with 'CH01 · figures 0 (OAD-40) · FICTIONAL design, no cultural claim · VERSIONS KEPT: V001 (rejected), V002 this plate · not to scale'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed, not verified; the image shows no cultural content.
> - V001 REJECTION REASON NOT IN THIS FILE: the sheet says V001 is rejected; the reason is not stated on the plate and is not checked here.
> - UNVERIFIED: the species and the log's identity are visual readings only.
> - ENV item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Dense green rainforest, natural crooked branches/fallen log across red-earth path, roots and mist. No upright cruciform waypost or text in art visible; exploratory/status caption below art.

**Independent assessment:** Earlier cross-like-post issue not reproduced in current frame; same palette/vegetation family as CH01. Canonical proposed path asks for regrowth/old cut stumps/flatter route: path visible but stump provenance/forest landmark continuity not demonstrated. Species not authenticated; full photographic finish is not inherently a violation of style guide (guide explicitly photoreal).

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Earlier cross-like-post issue not reproduced in current frame; same palette/vegetation family as CH01. Canonical proposed path asks for regrowth/old cut stumps/flatter route: path visible but stump provenance/forest landmark continuity not demonstrated. Species not authenticated; full photographic finish is not inherently a violation of style guide (guide explicitly photoreal).

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Earlier cross-like-post issue not reproduced in current frame; same palette/vegetation family as CH01. Canonical proposed path asks for regrowth/old cut stumps/flatter route: path visible but stump provenance/forest landmark continuity not demonstrated. Species not authenticated; full photographic finish is not inherently a violation of style guide (guide explicitly photoreal).

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD final parent-design/production recommendation pending confirmed proposed-location scope and governing forest/source-tree continuity. No removal of natural crossed branches merely because they intersect; no automatic religious diagnosis. If wider view required, source-approved tree model or explicit occlusion reason, not invented location.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C13 source](https://drive.google.com/file/d/1meBZkmzfDX8HY38DbqIdhVDwc7F2WfyE/view) — archive`assessments/C13.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e02"></a>

# E02 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E02` · **Filename:** `B2_CAND_ENV_CH01-EXP-004_THE_SMALL_CLEARING_V002_1672x941.jpg`

**Source:** [1Ji0NUXNJfos4Qvodp8ZNWIzlxAcUWOTk](https://drive.google.com/file/d/1Ji0NUXNJfos4Qvodp8ZNWIzlxAcUWOTk/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH01-EXP-004` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A gap about 15 m across where a giant tree fell; sunlight, tall grass, butterflies, the trunk rotting across it.
> - Architecture: None standing; only abandoned earthen compounds and posts.
> - Materials: Laterite mud, hardwood posts, palm thatch, fibre rope, white cotton cloth.
> - Lighting: Cool green shade; warm light only at the canopy; natural white shafts.
> **Required assets.** Fallen giant, grass, light gap.
> **Notes.** The one bright place in the forest interior.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`692198`bytes; MD5`db2e8b0444aad1fb8779e3ae4f36e5d8`; SHA256`ef25d1d247334c576834fe34d1b457b32bedb3c8c38a3b69337fd6a4a5c78f8a`.
- Research:`2397`bytes; MD5`3a20fc04dee4e5f3426f34bfe4a5ed45`; SHA256`01e70e85af7faccee2bf19576c1c69cb156c162cc9bac22e56c67f2a68da3091`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E02_B2_CAND_ENV_CH01-EXP-004_THE_SMALL_CLEARING_V002_1672x941.md](https://drive.google.com/file/d/1Q6Fi-D1YmKyCgMRWn1uf6-WJruMzQDjs/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photoreal-style forest clearing with a red-brown earth floor covered in leaf litter. A moss-covered fallen log lies across the back, palms and tall trees around it, and moss-covered boulders at the right. A caption band at the bottom reads 'ENV_CH01-EXP-004 · THE SMALL CLEARING · V002 · EXPLORATORY — NOT APPROVED CANON · STATUS: REVIEW REQUIRED', with 'CH01 · figures 0 (OAD-40) · FICTIONAL design, no cultural claim · VERSIONS KEPT: V001 (rejected), V002 this plate · not to scale'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed, not verified.
> - V001 REJECTION REASON NOT IN THIS FILE: not stated on the plate; not checked here.
> - UNVERIFIED: the fungus on the log and the species are visual readings only.
> - ENV item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Open red-earth/leaf-litter clearing, large mossy fallen trunk at back, irregular low rounded mossy boulders at right; dense trees/palms and canopy gap. No upright inscribed memorial slab evident.

**Independent assessment:** Prior monolith reading not reproduced in current frame. Subject approximate but unscaled: registered15m/giant-tree fall/tall grass/butterflies and horizon-tree continuity not independently established. Natural boulders not automatically sacred markers.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Prior monolith reading not reproduced in current frame. Subject approximate but unscaled: registered15m/giant-tree fall/tall grass/butterflies and horizon-tree continuity not independently established. Natural boulders not automatically sacred markers.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Prior monolith reading not reproduced in current frame. Subject approximate but unscaled: registered15m/giant-tree fall/tall grass/butterflies and horizon-tree continuity not independently established. Natural boulders not automatically sacred markers.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD for proposed-parent scope and landscape continuity/scale evidence; do not invent a mandatory slab removal, cultural identity or exact width from unscaled pixels. Keep naturalistic/exploratory framing.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C13 source](https://drive.google.com/file/d/1meBZkmzfDX8HY38DbqIdhVDwc7F2WfyE/view) — archive`assessments/C13.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e03"></a>

# E03 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E03` · **Filename:** `B2_CAND_SCENE_CH01-SCN-006_A_LARGE_FAMILY_COMPOUND_V002_1672x941.jpg`

**Source:** [1nIDlHOGiJbm7MEJ9xt3MJjsC7hAVz_60](https://drive.google.com/file/d/1nIDlHOGiJbm7MEJ9xt3MJjsC7hAVz_60/view) · Drive versionD3 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-006` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | The Compound Store |
> | Parent location ID | CH01-SUB-019 (A Large Family Compound) |
> | Scene category | ENTERABLE INTERIOR |
> | Canon status | **PROPOSED** |
> - **Physical description.** A small windowless store with yams on a rack and jars of oil.
> - **What the player sees.** Stacked produce in dim light.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** In part. PARTIALLY ENTERABLE: a limited section only.
> - **NPCs present.** None.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Rack, yams, jars.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`655645`bytes; MD5`ecac3a9ae184688d22c05250c18b601d`; SHA256`bffb3a073601504e32c43fff163602a84fbf9bb96015ad94cf855f7fe80e8e9c`.
- Research:`3321`bytes; MD5`cfa4a6b4ef14907ac8e424630d273804`; SHA256`2b4abbb0bb998475271da38a4eade6a34199e5e2bb0d4f44b5e8f35f18a4af54`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E03_B2_CAND_SCENE_CH01-SCN-006_A_LARGE_FAMILY_COMPOUND_V002_1672x941.md](https://drive.google.com/file/d/1Mr7v5P-wf6Q-1EbJ5iMuoI52kd7R7gv0/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a mud-walled compound entrance. A pair of weathered plank doors stands open in a red mud wall with a timber lintel; a thatched hut shows behind the gate. Indigo-blue cloths hang on a line over the wall with two pots and three gourds hung on pegs. In the courtyard, a woven mat holds grain with a flat wooden rake and a round basket tray. A thatched open shelter at the right holds stacked firewood, a stone mortar with a pestle, a bench and pots. A caption band reads 'SCENE_CH01-SCN-006 · A LARGE FAMILY COMPOUND · V002 · EXPLORATORY — NOT APPROVED CANON · STATUS: REVIEW REQUIRED', with 'CH01 · figures 0 (OAD-40) · FICTIONAL design, no cultural claim · VERSIONS KEPT: V001 (rejected), V002 this plate · not to scale'.

**Published flags (original wording, including any error reconciled below):**

> - SCALE NOT SHOWN: the caption calls it 'a large family compound', but the frame shows one gate and a small courtyard; the scale is not visible here.
> - CULTURAL CONTENT vs 'NO CULTURAL CLAIM': the plate says 'no cultural claim', yet the image shows indigo cloths, a mortar and pestle, gourds, grain and a rake. These items carry cultural content; the plate's disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNSUPPORTED IDENTITY: the grain, the rake, the gourds and the indigo are not identified; no claim is made about their use or origin.
> - V001 REJECTION REASON NOT IN THIS FILE: not checked here.
> - ENV/SCN item; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Mud compound entrance with rough timber lintel, rectangular panel gate and thatched buildings; plain blue drying cloth, hanging pots/gourds, mat/rake/basket and mortar/firewood shelter. No tall domed gate towers or people visible.

**Independent assessment:** Architecture correction versus author's V001 dome concern plausible, not exact raw-original comparison yet. OAD-55/56 textile/material qualifications remain, as does historical blocker. Latest Research did not check actual SCN-006: register says windowless compound STORE/yam rack/oil jars, whereas frame shows exterior gate/yard. Habitat-parent concept is not demonstrated completed scene coverage.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** BLOCKED / PRESERVE — BLOCKED: required textile/material qualifications unresolved; no OAD-55/56 clearance inferred from the picture inventory.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Architecture correction versus author's V001 dome concern plausible, not exact raw-original comparison yet. OAD-55/56 textile/material qualifications remain, as does historical blocker. Latest Research did not check actual SCN-006: register says windowless compound STORE/yam rack/oil jars, whereas frame shows exterior gate/yard. Habitat-parent concept is not demonstrated completed scene coverage.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Architecture correction versus author's V001 dome concern plausible, not exact raw-original comparison yet. OAD-55/56 textile/material qualifications remain, as does historical blocker. Latest Research did not check actual SCN-006: register says windowless compound STORE/yam rack/oil jars, whereas frame shows exterior gate/yard. Habitat-parent concept is not demonstrated completed scene coverage.

**Dependencies:** OAD-55/56; SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** BLOCKED / PRESERVE — BLOCKED: required textile/material qualifications unresolved; no OAD-55/56 clearance inferred from the picture inventory.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD. CD must decide if this is only a parent/habitat study or intended SCN006-store deliverable; if latter, file reference-backed store-interior/rack/yams/jars direction, without adding figures or redesigning whole compound. Research supplies textile/material evidence; no clearance by 'no cultural claim' caption.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C11 source](https://drive.google.com/file/d/1dZ2ufTteb_IOV6SR3B5z5zqTkYGFjq25/view) — archive`assessments/C11.md`; [F21 source](https://drive.google.com/file/d/1Cyu8qfaPdbu3lzWq_PaiD7UrFDIDc_jz/view) — archive`assessments/F21.md`; [F55 source](https://drive.google.com/file/d/15vfEEcf1zelEbQ0aAKUD18sWvOjC75FO/view) — archive`assessments/F55.md`; [F64 source](https://drive.google.com/file/d/1tJ4K-u_vlnw3QC6HmIt3sxoz2KucRhBl/view) — archive`assessments/F64.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e04"></a>

# E04 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E04` · **Filename:** `B2_CAND_SCENE_CH01-SCN-007_A_SMALL_FAMILY_HOUSE_V002_1672x941.jpg`

**Source:** [1hTmInOVfZ_EIHzv4RWIM_BzGru-r4uOp](https://drive.google.com/file/d/1hTmInOVfZ_EIHzv4RWIM_BzGru-r4uOp/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-007` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Sleeping Corner |
> | Parent location ID | CH01-INT-007 (A Small Family House) |
> | Scene category | ENTERABLE INTERIOR |
> | Canon status | **PROPOSED** |
> - **Physical description.** The raised earth sleeping platform with mats and a folded cloth, a peg for a wrapper.
> - **What the player sees.** A small tidy private space.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** Yes. FULLY ENTERABLE: the player can walk in and explore.
> - **NPCs present.** None.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Platform, mats, peg.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`499283`bytes; MD5`864076c118c639c5fe79e4621f65a82a`; SHA256`9eb0137053559530b69c894ab30176ad7315c911415a03ce1ca54623b8d76f00`.
- Research:`2892`bytes; MD5`25ee98ed0c1ffaf1cd1f6ed0d79d00df`; SHA256`feb9025c7453cd695cc199fa8a6d5d1d8571045d6b068d28b07f393fe165eb28`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E04_B2_CAND_SCENE_CH01-SCN-007_A_SMALL_FAMILY_HOUSE_V002_1672x941.md](https://drive.google.com/file/d/1LBMHQwlrNSCoRFufUWVHp1x8jg4INIjm/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic dusk view of a mud-walled house with a thatched roof. A timber door frame is open to a blue cloth hanging inside, with a small lamp glowing within. In the yard: a bench, a stone mortar with a pestle, a clay pot, gourds in a bowl, a stack of firewood, and a ring of stones with ash in the centre of the yard. A low mud wall and palms lie behind. The printed caption band reads 'SCENE_CH01-SCN-007 · A SMALL FAMILY HOUSE · DUSK · V002 · EXPLORATORY — NOT APPROVED CANON · STATUS: REVIEW REQUIRED'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items (see Findings) carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - FIRE-RING NOTE: a ring of stones with ash lies in the yard. The research record holds a fire-ring ruling pending on a related central stone ring (see B09). This report does not rule on this ring or link it to that item.
> - UNVERIFIED: the blue cloth, the mortar and the gourds are not identified; no use is claimed.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Dusk earth/thatch house exterior, plain blue doorway cloth, warm lamp, bench/mortar/pot/gourds/firewood. Foreground shows THREE separate dark hearth stones around pale ash, not a clearly closed continuous stone ring.

**Independent assessment:** Research E04 calls a ring; direct three-stone arrangement does not justify importing ST04 V002's unresolved central-square-ring classification. Domestic use plausible but material/function not authenticated. SCN007 registered Sleeping Corner is an interior raised-earth platform/mats/peg, not this exterior.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Research E04 calls a ring; direct three-stone arrangement does not justify importing ST04 V002's unresolved central-square-ring classification. Domestic use plausible but material/function not authenticated. SCN007 registered Sleeping Corner is an interior raised-earth platform/mats/peg, not this exterior.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Research E04 calls a ring; direct three-stone arrangement does not justify importing ST04 V002's unresolved central-square-ring classification. Domestic use plausible but material/function not authenticated. SCN007 registered Sleeping Corner is an interior raised-earth platform/mats/peg, not this exterior.

**Dependencies:** SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD for intended SCN007 versus habitat/exterior scope and domestic-hearth reference. No automatic ritual ruling or ring-removal correction. If SCN007 coverage required, owner briefs platform/mats/peg interior; no figure addition authorised.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C11 source](https://drive.google.com/file/d/1dZ2ufTteb_IOV6SR3B5z5zqTkYGFjq25/view) — archive`assessments/C11.md`; [F22 source](https://drive.google.com/file/d/1WDUWvm66odU4igHjVazyV5JAzAQ6Qx05/view) — archive`assessments/F22.md`; [F55 source](https://drive.google.com/file/d/15vfEEcf1zelEbQ0aAKUD18sWvOjC75FO/view) — archive`assessments/F55.md`; [F65 source](https://drive.google.com/file/d/17Z0oh9v3a9M7Ct2iLu2O0aAs3oEwxEUw/view) — archive`assessments/F65.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e05"></a>

# E05 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E05` · **Filename:** `B2_CAND_SCENE_CH01-SCN-008_A_SMALL_FAMILY_HOUSE_V002_1672x941.jpg`

**Source:** [136GaYOi8QJFC60xb9hfmtr3bp_Rdn2vp](https://drive.google.com/file/d/136GaYOi8QJFC60xb9hfmtr3bp_Rdn2vp/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-008` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Repairing the Roof |
> | Parent location ID | CH01-INT-007 (A Small Family House) |
> | Scene category | WORLD ACTIVITY SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** A ladder against the eaves and bundles of new palm thatch on the ground.
> - **What the player sees.** A man on the roof tying in thatch, another passing bundles up.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** Two men.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Ladder, thatch bundles, cord.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`648234`bytes; MD5`839d585ed0601d7ca760c06b65ee8d75`; SHA256`f03b80f1de03048ef9b8986a9bf3414eb8df86a982bac4c811ef187ebc9bf42b`.
- Research:`2850`bytes; MD5`a86190c077fa1178d4ebd508506e5ef3`; SHA256`68ab92e9e2eac9fdca6b1d82318dc09473c89b89233302b5130b4a2c7919c0a5`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E05_B2_CAND_SCENE_CH01-SCN-008_A_SMALL_FAMILY_HOUSE_V002_1672x941.md](https://drive.google.com/file/d/1vimajdMjXwqgTO3OrA6TvwsC2wwyB7jJ/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic interior of a mud-walled house, with a thatched roof on timber rafters, shown during rain. A woven screen stands at the left; a small clay brazier with a smoking pot sits on the floor. Two rolled woven mats lie on the floor at the right, with folded dark cloths on them. Dried bundles of herbs and cobs hang from the roof beam. Clay pots, a small mortar and a wooden spoon sit on a ledge. An open doorway shows rain and a mud house outside. The caption band reads 'SCENE_CH01-SCN-008 · A SMALL FAMILY HOUSE · INTERIOR, RAIN · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items (see Findings) carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the dried bundles, cobs, herbs and mortar are not identified; the brazier's contents are not established.
> - UNVERIFIED: the rain outside is a depicted effect.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Rainy earthen house interior, timber/thatch roof, woven upright screen, mats/folded cloths, hanging dry bundles/cobs and small lit/ember brazier. No ladder/thatch repair tools/exterior repair staging visible.

**Independent assessment:** Interior material family improved relative to author's V001 joinery concern, but registered SCN008 Repairing the Roof is roof/eaves/ladder/new-thatch activity, not interior bedding. No exact plant/food identity established. Caption's fiction label does not prove construction sourcing.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Interior material family improved relative to author's V001 joinery concern, but registered SCN008 Repairing the Roof is roof/eaves/ladder/new-thatch activity, not interior bedding. No exact plant/food identity established. Caption's fiction label does not prove construction sourcing.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Interior material family improved relative to author's V001 joinery concern, but registered SCN008 Repairing the Roof is roof/eaves/ladder/new-thatch activity, not interior bedding. No exact plant/food identity established. Caption's fiction label does not prove construction sourcing.

**Dependencies:** SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD scene-coverage/parent-kit decision; if intended roof-repair deliverable, owner must file supported eaves/ladder/new-thatch/cord staging and reconcile figureless constraint first. No invented joinery standard or automatic NPC generation.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C11 source](https://drive.google.com/file/d/1dZ2ufTteb_IOV6SR3B5z5zqTkYGFjq25/view) — archive`assessments/C11.md`; [F23 source](https://drive.google.com/file/d/14t17-fgr9WExEx202HSQxCeoU9gMVLL-/view) — archive`assessments/F23.md`; [F55 source](https://drive.google.com/file/d/15vfEEcf1zelEbQ0aAKUD18sWvOjC75FO/view) — archive`assessments/F55.md`; [F66 source](https://drive.google.com/file/d/1KvQ8UTXo9dRexWJpgI-6FduOKRRdan8d/view) — archive`assessments/F66.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e06"></a>

# E06 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E06` · **Filename:** `B2_CAND_SCENE_CH01-SCN-009_ELDERS_HOUSE_V002_1672x941.jpg`

**Source:** [1xtum5Ln3jiXSwtXQJVLr1jw55EnfvmJw](https://drive.google.com/file/d/1xtum5Ln3jiXSwtXQJVLr1jw55EnfvmJw/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-009` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Elder Resting on the Veranda |
> | Parent location ID | CH01-INT-009 (The Elder's House) |
> | Scene category | AMBIENT NPC SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** A deep shaded veranda with a carved stool and a staff against the post.
> - **What the player sees.** Mgbafo seated, watching the lane, greeting passers-by.
> - **What the player can interact with.** Speak to her.
> - **Can the player enter the space?** In part. PARTIALLY ENTERABLE: a limited section only.
> - **NPCs present.** Mgbafo (village elder).
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Veranda, stool, staff.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`562510`bytes; MD5`1f9206fc6dc3d1af924b5bae2644c45c`; SHA256`b8daa2cfb84567c5e5284de310bea50bc9ef18f2aa8fe46eb4826a1826b7d5e8`.
- Research:`2772`bytes; MD5`3805af00e247386aeb324ab4d01d309d`; SHA256`93770a7d8949c4d7cf25c61c4f96a8cf4a956df695425e6a9b9c131f86dabc49`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E06_B2_CAND_SCENE_CH01-SCN-009_ELDERS_HOUSE_V002_1672x941.md](https://drive.google.com/file/d/11k4U1aJU4fdKe6s0Mx68VuJg2TeYeZFN/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic interior of a round mud house with a thatched roof. Three clay pots sit on a wall shelf; two woven baskets and a third sit on a mud bench; a small wooden stool stands on a woven mat. A blue cloth hangs on the wall beside a doorway that opens to a yard with banana plants. Two dried bundles hang from the roof beam, and a small window opening is set in the left wall. The caption band reads 'SCENE_CH01-SCN-009 · ELDER'S HOUSE · INTERIOR · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items (see Findings) carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - IDENTITY NOT ESTABLISHED: 'Elder's house' is the plate's label; the image shows no person and no marker of rank or office. The use of the room is not established.
> - UNVERIFIED: the bundles and baskets' contents are not identified.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Empty warm earth/thatch room, low stool/mat, baskets, three shelf pots, hanging bundles and plain blue cloth; door to green yard. No elder, shaded veranda or staff against veranda post visible.

**Independent assessment:** Label Elder's House is not itself a conflict just because no person is present; however full registered SCN009 veranda/stool/staff beat not delivered by this interior. No invention of elder regalia to prove identity. Habitat-only scope may explain absence, not full-scene completion.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Label Elder's House is not itself a conflict just because no person is present; however full registered SCN009 veranda/stool/staff beat not delivered by this interior. No invention of elder regalia to prove identity. Habitat-only scope may explain absence, not full-scene completion.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Label Elder's House is not itself a conflict just because no person is present; however full registered SCN009 veranda/stool/staff beat not delivered by this interior. No invention of elder regalia to prove identity. Habitat-only scope may explain absence, not full-scene completion.

**Dependencies:** SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD on scope and reference; owner selects parent interior versus veranda microbeat, resolving OAD40 before any people. Do not add rank symbols, alter cultural status markers or assert species from generic bundles.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C12 source](https://drive.google.com/file/d/19Ct7vvsF0xa-ClBi621JVkpxGrzgJQlf/view) — archive`assessments/C12.md`; [F26 source](https://drive.google.com/file/d/19L_kdq4w5q0jZiCZfHc5j07Tx_oTrOdI/view) — archive`assessments/F26.md`; [F57 source](https://drive.google.com/file/d/1_2wlaIkVKLdDBSHJYnH5pmcJWhoKJz2F/view) — archive`assessments/F57.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e07"></a>

# E07 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E07` · **Filename:** `B2_CAND_SCENE_CH01-SCN-010_SMITHY_V002_1672x941.jpg`

**Source:** [1OB-WeC6Z6hrOt3oQquEYoOZ-ICrpbRW2](https://drive.google.com/file/d/1OB-WeC6Z6hrOt3oQquEYoOZ-ICrpbRW2/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-010` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | The Blacksmith at Work |
> | Parent location ID | CH01-INT-005 (Smithy) |
> | Scene category | WORLD ACTIVITY SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** The open-fronted forge with bag bellows, stone anvil and charcoal.
> - **What the player sees.** Omenka hammering a hoe blade, an apprentice on the bellows, sparks.
> - **What the player can interact with.** Speak to him; watch.
> - **Can the player enter the space?** Yes. FULLY ENTERABLE: the player can walk in and explore.
> - **NPCs present.** Omenka (blacksmith), one apprentice.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Forge, bellows, anvil, tools.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`479195`bytes; MD5`2b5b25b34f08274f496cfb12a9a5196d`; SHA256`fa279c74895b9a91a3bd3e71099086496a83226af9b7ccaf465e6ae723b17292`.
- Research:`2971`bytes; MD5`0b9175966b54a11e09ece1dccf11a67d`; SHA256`408aaf0f896d722f47a6d37d4940ad8c3243e0b5b6fd5cca574e0f12b48c4eb0`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E07_B2_CAND_SCENE_CH01-SCN-010_SMITHY_V002_1672x941.md](https://drive.google.com/file/d/1J-zC1D5_w6yLCQHHLem8Y0b1x6jO5Sbh/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of an open-sided smithy shelter with a thatched roof on timber posts, opening to a village of thatched huts at sunset. A clay forge hearth holds a glowing fire with two bellows pieces beside it. Hand tools hang on the back wall and lie on a stone block: tongs, a hammer, and a chisel-like tool. Two long flat iron pieces and several small iron shapes lie on the ash in the foreground. A log trough and clay pots sit at the right.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items (see Findings) carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - BLADE QUESTION NOT CLEARED: the two long flat iron pieces on the ash are blade-like in shape. This report does not identify them as blades, blanks or tools. Under the standing rules, no blade approval or CQ-9 clearance follows from this plate.
> - UNSUPPORTED TECHNOLOGY: the forge, bellows and iron-working processes are depicted; their historical accuracy is not established by the image.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Open earth/thatch smithy, low glowing forge, paired bellows-like pieces, tools on wall/anvil block, long flat blade/hoe-blank-like iron forms on ash, log trough. No figures or weapon approval labels in art.

**Independent assessment:** Smithy subject legible and some registered forge/anvil/tool cues present, but bag-bellows/process layout is unsourced. Two flat pieces do NOT establish Adanna's blade or CQ9 authority; no basis to call any metal sacred. Historical smithy sourcing/layout blocker persists.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** BLOCKED / PRESERVE — BLOCKED: unsourced smithing-layout requirement unresolved; tool inventory is not sourcing or layout sign-off.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Smithy subject legible and some registered forge/anvil/tool cues present, but bag-bellows/process layout is unsourced. Two flat pieces do NOT establish Adanna's blade or CQ9 authority; no basis to call any metal sacred. Historical smithy sourcing/layout blocker persists.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Smithy subject legible and some registered forge/anvil/tool cues present, but bag-bellows/process layout is unsourced. Two flat pieces do NOT establish Adanna's blade or CQ9 authority; no basis to call any metal sacred. Historical smithy sourcing/layout blocker persists.

**Dependencies:** SMITHY_LAYOUT_REFERENCE; SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** BLOCKED / PRESERVE — BLOCKED: unsourced smithing-layout requirement unresolved; tool inventory is not sourcing or layout sign-off.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD. Research/CD supply approved forging-process/bellows/anvil layout reference and intended daylight/activity-state scope before precise layout correction. Do not invent furnace dimensions, tech history, weapon shape or add smith/apprentice automatically.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C10 source](https://drive.google.com/file/d/1xI5v1ZfeXyxE-laueJRmWsymvlFkJGgl/view) — archive`assessments/C10.md`; [F08 source](https://drive.google.com/file/d/11hnYj5qH7LRCD90XUq0M8H3kaBHpLdCN/view) — archive`assessments/F08.md`; [F09 source](https://drive.google.com/file/d/1w5eDzRwcqRTUwDaifnlwK-i4f56wFRGa/view) — archive`assessments/F09.md`; [F54 source](https://drive.google.com/file/d/13aJGxM20F9FCorGDq-2g4DbnDdpTDUlZ/view) — archive`assessments/F54.md`; [F59 source](https://drive.google.com/file/d/1qvIe2S7rmJA0G9eiGsCMvg4HckXAUYSu/view) — archive`assessments/F59.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e08"></a>

# E08 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E08` · **Filename:** `B2_CAND_SCENE_CH01-SCN-012_MARKET_STALLS_V002_1672x941.jpg`

**Source:** [1a4dO7GjSe89mDr1xQXWf2iszj8wAblgh](https://drive.google.com/file/d/1a4dO7GjSe89mDr1xQXWf2iszj8wAblgh/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-012` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Closing the Stall at Night |
> | Parent location ID | CH01-SUB-008 (Market Stalls) |
> | Scene category | AMBIENT NPC SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** The same stall at dusk, goods going into baskets.
> - **What the player sees.** A trader packing by the light of a small fire, counting cowries.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** One trader.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Baskets, fire, cowries.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`601280`bytes; MD5`0e14778fc699ba67676bb28d18696852`; SHA256`ee24e3b5cb7ba6dd19c94d8dfc0223210ad3ed7a025568d5e850ff7eb6c85ff2`.
- Research:`2523`bytes; MD5`ddb59fd4e586d0000c5a45bbdc6939ea`; SHA256`9584bac704e7637cf7d460c66ee9e84ecea92dd92dd70dca74f6e8c82f43811e`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E08_B2_CAND_SCENE_CH01-SCN-012_MARKET_STALLS_V002_1672x941.md](https://drive.google.com/file/d/143E1-umxIvOGfOqJN--FBD4SI7QaZN60/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a village market at sunset. Open stalls with thatched or mat roofs stand around a dirt yard. Tables and mats hold produce: green peppers, yams, plantain, red peppers in bowls, gourds and clay pots. Folded white cloths sit on a table at the left; stacked woven mats lean against a wall. Mud-walled houses with thatched roofs and palms lie beyond. The caption band reads 'SCENE_CH01-SCN-012 · MARKET STALLS · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items (see Findings) carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the produce types are visual readings only (for example the green peppers and plantain); none is identified beyond that.
> - UNVERIFIED: the market's trade, dates and scale are not established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Sunset empty market yard, produce/bowls/pots/plain cloth on open stalls, mat/thatch roofs; some background flat/parapet-like earth buildings, no obvious corrugated metal. Goods mostly displayed, not clear packed-basket/fire/cowrie closure beat.

**Independent assessment:** Visible natural roof replacement acknowledged, but historical closing-state/reference blocker not cleared by generic market inventory. SCN012 registered dusk packing/cowries/fire is materially different; report does not assess it. Removing all people under figureless scope does not excuse missing approved staged beat unless owner accepts habitat-only deliverable.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** BLOCKED / PRESERVE — BLOCKED: closing-state staging and designated reference alignment unresolved.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Visible natural roof replacement acknowledged, but historical closing-state/reference blocker not cleared by generic market inventory. SCN012 registered dusk packing/cowries/fire is materially different; report does not assess it. Removing all people under figureless scope does not excuse missing approved staged beat unless owner accepts habitat-only deliverable.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Visible natural roof replacement acknowledged, but historical closing-state/reference blocker not cleared by generic market inventory. SCN012 registered dusk packing/cowries/fire is materially different; report does not assess it. Removing all people under figureless scope does not excuse missing approved staged beat unless owner accepts habitat-only deliverable.

**Dependencies:** CLOSING_STATE_STAGING_AUTHORITY; SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** BLOCKED / PRESERVE — BLOCKED: closing-state staging and designated reference alignment unresolved.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD: CD confirms designated reference/closing-state tableau and habitat-only scope. File correction only after that: supported packing baskets/small-fire/cowrie read and parent-kit alignment, not invented ceremonial market dressing.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C10 source](https://drive.google.com/file/d/1xI5v1ZfeXyxE-laueJRmWsymvlFkJGgl/view) — archive`assessments/C10.md`; [F08 source](https://drive.google.com/file/d/11hnYj5qH7LRCD90XUq0M8H3kaBHpLdCN/view) — archive`assessments/F08.md`; [F09 source](https://drive.google.com/file/d/1w5eDzRwcqRTUwDaifnlwK-i4f56wFRGa/view) — archive`assessments/F09.md`; [F54 source](https://drive.google.com/file/d/13aJGxM20F9FCorGDq-2g4DbnDdpTDUlZ/view) — archive`assessments/F54.md`; [F59 source](https://drive.google.com/file/d/1qvIe2S7rmJA0G9eiGsCMvg4HckXAUYSu/view) — archive`assessments/F59.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e09"></a>

# E09 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E09` · **Filename:** `B2_CAND_SCENE_CH01-SCN-013_MARKET_BACKROOMS_V002_1672x941.jpg`

**Source:** [1OnmKtOuDB2CaYb71HfzxznLCcLF7un5t](https://drive.google.com/file/d/1OnmKtOuDB2CaYb71HfzxznLCcLF7un5t/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-013` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Behind the Stalls |
> | Parent location ID | CH01-INT-014 (The Market Backrooms) |
> | Scene category | EXTERIOR MICRO-LOCATION |
> | Canon status | **PROPOSED** |
> - **Physical description.** A strip of stores and stacked baskets behind the stall line.
> - **What the player sees.** Bundles, a sleeping dog, a boy minding goods.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** In part. PARTIALLY ENTERABLE: a limited section only.
> - **NPCs present.** One boy.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Stores, baskets, dog.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`550764`bytes; MD5`2c64ccadf76cf78ada9b720fd478347a`; SHA256`955a58037733aa20cd0fb84e4d4a591739a44b8bc677093d92ee4876eb2ee45a`.
- Research:`2428`bytes; MD5`bc23b45c82f5985ca8d5d3d9dc836ff7`; SHA256`ac172f5b994c763b6be29a7ec838f1e315e2e5337165db3672f6a929e1fd06ce`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E09_B2_CAND_SCENE_CH01-SCN-013_MARKET_BACKROOMS_V002_1672x941.md](https://drive.google.com/file/d/1QEgr6_fgyYctgaByOX30S2HVfqRsk2h0/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a backroom store with a thatched roof on timber posts, a door open at the left. Mud-walled shelves hold folded cloths in white, brown and dark blue. Woven baskets with lids and clay pots stand on the floor. A gourd and a dried herb bundle hang from the beam at the right. The caption band reads 'SCENE_CH01-SCN-013 · MARKET BACKROOMS · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items (see Findings) carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the dark blue cloth's dye is not identified; no indigo practice is claimed.
> - UNVERIFIED: the herb bundle and the gourd's use are not established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Earthen shelf/store interior with neatly folded white/brown/blue cloth, lidded baskets, clay pots and hanging gourd/bundle; open door left. No external strip behind stalls, doorpost tally, boy or dog apparent.

**Independent assessment:** Useful store-room concept, but SCN013 Behind the Stalls is exterior micro-location; no automatic defect because objects are cultural, but technology/dye claims not sourced. No false association with H1 Washing Place/market backroom reference visual release.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Useful store-room concept, but SCN013 Behind the Stalls is exterior micro-location; no automatic defect because objects are cultural, but technology/dye claims not sourced. No false association with H1 Washing Place/market backroom reference visual release.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Useful store-room concept, but SCN013 Behind the Stalls is exterior micro-location; no automatic defect because objects are cultural, but technology/dye claims not sourced. No false association with H1 Washing Place/market backroom reference visual release.

**Dependencies:** SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD intended parent-interior versus exterior-microbeat scope. CD supplies source/angle if exterior coverage required; tally marks/figures/dog only under approved staged brief, not automatically generated. Do not invent dye authentication.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C12 source](https://drive.google.com/file/d/19Ct7vvsF0xa-ClBi621JVkpxGrzgJQlf/view) — archive`assessments/C12.md`; [F26 source](https://drive.google.com/file/d/19L_kdq4w5q0jZiCZfHc5j07Tx_oTrOdI/view) — archive`assessments/F26.md`; [F57 source](https://drive.google.com/file/d/1_2wlaIkVKLdDBSHJYnH5pmcJWhoKJz2F/view) — archive`assessments/F57.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e10"></a>

# E10 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E10` · **Filename:** `B2_CAND_SCENE_CH01-SCN-014_WATER_COLLECTION_POINT_V002_1672x941.jpg`

**Source:** [1Ra_Aqb6OIzStdjRhT4lldGlatTuH6sef](https://drive.google.com/file/d/1Ra_Aqb6OIzStdjRhT4lldGlatTuH6sef/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-014` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Fetching Water |
> | Parent location ID | CH01-SUB-015 (Water Collection Point) |
> | Scene category | AMBIENT NPC SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** A worn path down to the water with flat stones at the edge.
> - **What the player sees.** A line of women and girls filling pots and lifting them onto head-pads, talking.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** Five to eight women and girls.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Pots, head-pads, stones.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`717301`bytes; MD5`1f78db2514885ad3d1dc29a009fde71a`; SHA256`24286c6f4bcb17eb094258f326991240bad0ded7cad183c67baf6ff0aab4fd70`.
- Research:`2664`bytes; MD5`1894e342dce3c5d229dca7729ca78cbf`; SHA256`55ebac6a85911f17b861895ca237598e5796d68113b03c769014104c8e3073c0`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E10_B2_CAND_SCENE_CH01-SCN-014_WATER_COLLECTION_POINT_V002_1672x941.md](https://drive.google.com/file/d/1hT2G1kMtn9AKBgxrGRDp8g2bcCWpgK1K/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic riverbank view with a muddy bank, grass and trees on the far side, and a village of thatched mud houses at the right. Five clay pots stand in the shallow water at the left; a wooden bowl on a cord floats near them. On the bank: a woven mat with a gourd and a dark blue cloth, a wooden bowl and a forked stick frame, and scattered potsherds. The caption band reads 'SCENE_CH01-SCN-014 · WATER COLLECTION POINT · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the water-bowl-on-a-cord and the forked stick frame are not identified; their use is not claimed.
> - UNVERIFIED: the potsherds' age and origin are not established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Worn muddy riverbank, five large pots in shallows, tethered floating bowl, bank mat/blue cloth/gourd and forked branch frame, houses on upper bank. No sweep-hoist installed over water or figures visible.

**Independent assessment:** Prior invented-hoist concern plausibly reduced, but branch/frame and bowl construction/use not established. SCN014 requires worn path/flat edge stones/pots/head-pads; no clear flat-stone landing/head-pad detail. Need distinguish current habitat-only snapshot from full water-fetching activity.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Prior invented-hoist concern plausibly reduced, but branch/frame and bowl construction/use not established. SCN014 requires worn path/flat edge stones/pots/head-pads; no clear flat-stone landing/head-pad detail. Need distinguish current habitat-only snapshot from full water-fetching activity.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Prior invented-hoist concern plausibly reduced, but branch/frame and bowl construction/use not established. SCN014 requires worn path/flat edge stones/pots/head-pads; no clear flat-stone landing/head-pad detail. Need distinguish current habitat-only snapshot from full water-fetching activity.

**Dependencies:** WATER_COLLECTION_REFERENCE; SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD for water-collection practice/reference and scene-coverage decision; do not reinstate invented hoist or treat unused forked sticks as technology proof. Support any staged edge/head-pad detail with registered requirement and CD-approved use.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C11 source](https://drive.google.com/file/d/1dZ2ufTteb_IOV6SR3B5z5zqTkYGFjq25/view) — archive`assessments/C11.md`; [F24 source](https://drive.google.com/file/d/1l1tDDWtklqknUP7k7JkzHeVMmJLYocF3/view) — archive`assessments/F24.md`; [F55 source](https://drive.google.com/file/d/15vfEEcf1zelEbQ0aAKUD18sWvOjC75FO/view) — archive`assessments/F55.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e11"></a>

# E11 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E11` · **Filename:** `B2_CAND_SCENE_CH01-SCN-015_FISHING_STREAM_V002_1672x941.jpg`

**Source:** [1keM066YH3olFbX5b1xhxbKqIITSeTJrG](https://drive.google.com/file/d/1keM066YH3olFbX5b1xhxbKqIITSeTJrG/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-015` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Fishermen Preparing Gear |
> | Parent location ID | CH01-SUB-013 (Home Settlement — Local Fishing Stream) |
> | Scene category | WORLD ACTIVITY SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** The bank with canoes drawn up and nets spread on poles.
> - **What the player sees.** Two men mending a net, a third bailing a canoe.
> - **What the player can interact with.** Speak to them.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** Three fishermen.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Canoes, nets, floats.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`812586`bytes; MD5`b5b8924d2e5f7fa1479a12c2cb1ab147`; SHA256`bd648bc7afa1aefeb69d756974c13244a3dc6628f4bdd4ade67f5a313d484a0e`.
- Research:`2542`bytes; MD5`414f2f77d05b59e24b8f324ec3a1959a`; SHA256`4164fe49316255f92a025a60ad39b54680b836a77e10b3970e1aaf5d818c5d94`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E11_B2_CAND_SCENE_CH01-SCN-015_FISHING_STREAM_V002_1672x941.md](https://drive.google.com/file/d/1We53RLWEs8fQr0CkIY_XiqTvwoMFYA9Y/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a shallow stream with a sandy-red bank, fallen branches and grass tufts. Two woven conical traps stand on the bank with a stack of sticks and a gourd. A mud-walled house with a thatched roof and clay pots sits beyond, with palms and forest at the left. The caption band reads 'SCENE_CH01-SCN-015 · FISHING STREAM · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the traps' type and fishing use are visual readings only; the species are not identified.
> - UNVERIFIED: the bank's erosion and the roots are depicted features; no period is established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Narrow shallow stream and roots, two basket/conical trap-like objects, sticks/gourd, mud/thatch house beyond; no canoe or net-on-poles clearly visible.

**Independent assessment:** Stream/trap concept not full SCN015 registered gear-preparation bank/canoe/nets/floats/overturned-vessel storytelling. Latest report is inventory only, not fishing-design authentication. Animal/plant species not established.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Stream/trap concept not full SCN015 registered gear-preparation bank/canoe/nets/floats/overturned-vessel storytelling. Latest report is inventory only, not fishing-design authentication. Animal/plant species not established.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Stream/trap concept not full SCN015 registered gear-preparation bank/canoe/nets/floats/overturned-vessel storytelling. Latest report is inventory only, not fishing-design authentication. Animal/plant species not established.

**Dependencies:** FISHING_GEAR_REFERENCE; SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD intended parent/habitat versus actual SCN015 coverage; owner must confirm canoe/net/pole/float configuration with Research reference before precise corrections or figures. No generic trap-type or fish-species specification invented.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C11 source](https://drive.google.com/file/d/1dZ2ufTteb_IOV6SR3B5z5zqTkYGFjq25/view) — archive`assessments/C11.md`; [F25 source](https://drive.google.com/file/d/1NXUmIb5B4yIXKETU5q3CtsqBW7CC67GC/view) — archive`assessments/F25.md`; [F56 source](https://drive.google.com/file/d/1hkFxPg1TwJN4tZDevMuk-2coi6XoGmV8/view) — archive`assessments/F56.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e12"></a>

# E12 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E12` · **Filename:** `B2_CAND_SCENE_CH01-SCN-017_VILLAGE_SQUARE_V002_1672x941.jpg`

**Source:** [1uUV4ZaZekbL3MfyTfCZDBdLXuj2NFP3s](https://drive.google.com/file/d/1uUV4ZaZekbL3MfyTfCZDBdLXuj2NFP3s/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-017` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | People Talking Under the Tree |
> | Parent location ID | CH01-SUB-006 (Village Square) |
> | Scene category | AMBIENT NPC SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** Log seats under the shade tree.
> - **What the player sees.** Men and women in loose groups talking, one telling a story with his hands.
> - **What the player can interact with.** Overhear.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** Six to ten adults; Unoka (storyteller) some days.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Shade tree, log seats.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`652287`bytes; MD5`f5d9e96da8f5b791a652783297bc0d73`; SHA256`736a0c61d1c7e6ca3d1662626026eaa9ee6b9bc8060cf30d081b8f4f785697ed`.
- Research:`2612`bytes; MD5`041551722cc8c1f3397f2e10314c268b`; SHA256`bc6a57ebbe7fe8af8cbfd6bc670db4da624e5eb03a1f330ca7641cdde8365045`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E12_B2_CAND_SCENE_CH01-SCN-017_VILLAGE_SQUARE_V002_1672x941.md](https://drive.google.com/file/d/1C9eQyqbuk8Z-XD1Zg-1KlmQ3qbPszuCu/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a village square at sunset under a hazy sky. Mud-walled houses with thatched conical roofs and pointed wall finials line the open dirt square. A large tree shades a wooden bench at the right. A clay mortar with a wooden pestle and two clay pots sit at the right foreground. The caption band reads 'SCENE_CH01-SCN-017 · VILLAGE SQUARE · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNSUPPORTED ARCHITECTURE: the pointed wall finials are not supported by any source in this file. The research record flags off-idiom architecture for C10–C14; not checked here.
> - UNVERIFIED: the tree's species and the bench's age are not established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Warm empty square, earth round/conical houses and tall pointed parapet/gate piers; shade tree/bench at right, mortar/pots front. No patterned bands clearly visible.

**Independent assessment:** Tree/seating support generic square; introduced pointed pier architecture remains not reconciled to Home Settlement direction (historical blocker). SCN017 log-seat activity versus bench/pier concept not settled. No assumption every pointed earth form is a named cultural idiom.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** BLOCKED / PRESERVE — BLOCKED: introduced pointed gate/parapet idiom remains unreconciled with Home Settlement direction.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Tree/seating support generic square; introduced pointed pier architecture remains not reconciled to Home Settlement direction (historical blocker). SCN017 log-seat activity versus bench/pier concept not settled. No assumption every pointed earth form is a named cultural idiom.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Tree/seating support generic square; introduced pointed pier architecture remains not reconciled to Home Settlement direction (historical blocker). SCN017 log-seat activity versus bench/pier concept not settled. No assumption every pointed earth form is a named cultural idiom.

**Dependencies:** HOME_GATE_PARAPET_IDIOM; SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** BLOCKED / PRESERVE — BLOCKED: introduced pointed gate/parapet idiom remains unreconciled with Home Settlement direction.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD architectural/source decision: CD supplies accepted gate/parapet reference and parent-square tree/seating plan; only then file exact replacement of introduced unsupported elements. No cultural-clearance inference from empty figures or fictional caption.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C10 source](https://drive.google.com/file/d/1xI5v1ZfeXyxE-laueJRmWsymvlFkJGgl/view) — archive`assessments/C10.md`; [F08 source](https://drive.google.com/file/d/11hnYj5qH7LRCD90XUq0M8H3kaBHpLdCN/view) — archive`assessments/F08.md`; [F09 source](https://drive.google.com/file/d/1w5eDzRwcqRTUwDaifnlwK-i4f56wFRGa/view) — archive`assessments/F09.md`; [F54 source](https://drive.google.com/file/d/13aJGxM20F9FCorGDq-2g4DbnDdpTDUlZ/view) — archive`assessments/F54.md`; [F59 source](https://drive.google.com/file/d/1qvIe2S7rmJA0G9eiGsCMvg4HckXAUYSu/view) — archive`assessments/F59.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e13"></a>

# E13 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E13` · **Filename:** `B2_CAND_SCENE_CH01-SCN-019_GATE_GUARD_SHELTER_V002_1672x941.jpg`

**Source:** [1iR48S7upDhIp-zQ_cVqHTcS8V66xH2Gl](https://drive.google.com/file/d/1iR48S7upDhIp-zQ_cVqHTcS8V66xH2Gl/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-019` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | A Guard on a Quiet Shift |
> | Parent location ID | CH01-INT-013 (The Gate Guard Shelter) |
> | Scene category | AMBIENT NPC SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** The lean-to by the gate.
> - **What the player sees.** Okorie seated with his spear across his knees, half watching the road.
> - **What the player can interact with.** Speak to him.
> - **Can the player enter the space?** In part. PARTIALLY ENTERABLE: a limited section only.
> - **NPCs present.** Okorie (royal guard).
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Bench, spear, shield, water pot.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`764959`bytes; MD5`2f8b0995c40c8c7d391afb46a0052fcb`; SHA256`cace3dbc828818710fb00be4fcf67e7d3d4677127644b8428a0753fb42653908`.
- Research:`2644`bytes; MD5`9dd53ac4f95be3a9ec664a57b146294a`; SHA256`ce722a1fa7be12a4204db9bd84048d976d87a640f8aba654ea92e64effdf17b2`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E13_B2_CAND_SCENE_CH01-SCN-019_GATE_GUARD_SHELTER_V002_1672x941.md](https://drive.google.com/file/d/1r5JRyGn0ELwm1pF3yn17nAg4KUJR1pID/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a thatched gate-guard shelter with a bench, a woven mat leaning against the wall, and a clay pot on the ground. A mud wall runs behind it, and a gateway with a timber lintel and two pointed mud pillars opens onto a dirt track through forest and palms. The caption band reads 'SCENE_CH01-SCN-019 · GATE GUARD SHELTER · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNSUPPORTED ARCHITECTURE: the pointed mud gate pillars are not supported by any source in this file; the research record flags off-idiom architecture for C10–C14; not checked here.
> - UNVERIFIED: the gate's function as a guard post is the plate's label; the image shows no guard.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Simple thatch lean-to/bench, woven mat propped inside, clay pot; earth gateposts with rounded/pointed tops and timber lintel, green forest trail beyond. No guard/spear/shield identifiable.

**Independent assessment:** Arid backdrop concern from V001 not apparent, but pointed gateway form/source and missing guard equipment remain scope/reference gaps. Do not transpose separate F4 gate-guard shield-pattern issue onto a mat-shaped object automatically.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Arid backdrop concern from V001 not apparent, but pointed gateway form/source and missing guard equipment remain scope/reference gaps. Do not transpose separate F4 gate-guard shield-pattern issue onto a mat-shaped object automatically.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Arid backdrop concern from V001 not apparent, but pointed gateway form/source and missing guard equipment remain scope/reference gaps. Do not transpose separate F4 gate-guard shield-pattern issue onto a mat-shaped object automatically.

**Dependencies:** HOME_GATE_PARAPET_IDIOM; GUARD_EQUIPMENT_REFERENCE; SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD accepted gate design and scene-equipment/figureless scope. CD must decide habitat-only versus SCN019 guard-on-shift; any spear/shield details require actual approved equipment references and CQ8/F4 controls, not invented ornament.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F26 source](https://drive.google.com/file/d/19L_kdq4w5q0jZiCZfHc5j07Tx_oTrOdI/view) — archive`assessments/F26.md`; [F57 source](https://drive.google.com/file/d/1_2wlaIkVKLdDBSHJYnH5pmcJWhoKJz2F/view) — archive`assessments/F57.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e14"></a>

# E14 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E14` · **Filename:** `B2_CAND_SCENE_CH01-SCN-021_BACK_LANES_V002_1672x941.jpg`

**Source:** [1ffC9c575D2fzrH_aahnokHg8GXpd5_63](https://drive.google.com/file/d/1ffC9c575D2fzrH_aahnokHg8GXpd5_63/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-021` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | The Path Behind the Houses |
> | Parent location ID | CH01-SUB-020 (The Back Lanes) |
> | Scene category | EXTERIOR MICRO-LOCATION |
> | Canon status | **PROPOSED** |
> - **Physical description.** A shoulder-wide path between wall backs and a hedge.
> - **What the player sees.** Chickens, a drain, small back doors, washing spread on the hedge.
> - **What the player can interact with.** Open some back doors.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** Occasional passer-by.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Wall backs, doors, hedge.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`497748`bytes; MD5`edd2f3e6a0f5aa6cff06dd1f77176330`; SHA256`71e9b36bcffda79e1c79281cfecc8e8180a6dd0f676dd389b775d945cfd0e1a1`.
- Research:`2497`bytes; MD5`09f67cc361c433fea0973b7d1f036469`; SHA256`a78fe79f5a3a00451b9be2951ed69151d6a3556fb99f449d3cf730265208ccb1`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E14_B2_CAND_SCENE_CH01-SCN-021_BACK_LANES_V002_1672x941.md](https://drive.google.com/file/d/1_q4P-M6eOcuqYAsOGBFnyEHJogRozIU8/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic dusk view of a narrow back lane between red mud walls. Thatched conical houses stand at the left and rear; smoke rises from the back. A blue cloth hangs on a line across the lane. At the right, a wooden door is open in a mud wall, with two clay pots beside a plank bridge across a drain. The caption band reads 'SCENE_CH01-SCN-021 · BACK LANES · DUSK · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the blue cloth's dye is not identified; no indigo practice is claimed.
> - UNVERIFIED: the smoke's source is not established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Narrow dusk lane, rough red earth walls, plain blue hanging cloth, doorway/pots, open earthen drain crossed by wooden plank; conical thatched roofs and smoke beyond.

**Independent assessment:** Registered SCN021 includes drain/back doors, consistent visible cues; hedge/washing-on-hedge and exact settlement-source plan not demonstrated. Drain presence is NOT by itself defect: register explicitly includes it. Material/process identity not authenticated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Registered SCN021 includes drain/back doors, consistent visible cues; hedge/washing-on-hedge and exact settlement-source plan not demonstrated. Drain presence is NOT by itself defect: register explicitly includes it. Material/process identity not authenticated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Registered SCN021 includes drain/back doors, consistent visible cues; hedge/washing-on-hedge and exact settlement-source plan not demonstrated. Drain presence is NOT by itself defect: register explicitly includes it. Material/process identity not authenticated.

**Dependencies:** SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD final micro-location/source alignment and parent-kit decision, no invented drainage ban. If hedge/door-access coverage required, owner files source-backed composition; no automatic crowd/chickens or new roof design.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C12 source](https://drive.google.com/file/d/19Ct7vvsF0xa-ClBi621JVkpxGrzgJQlf/view) — archive`assessments/C12.md`; [F26 source](https://drive.google.com/file/d/19L_kdq4w5q0jZiCZfHc5j07Tx_oTrOdI/view) — archive`assessments/F26.md`; [F57 source](https://drive.google.com/file/d/1_2wlaIkVKLdDBSHJYnH5pmcJWhoKJz2F/view) — archive`assessments/F57.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e15"></a>

# E15 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E15` · **Filename:** `B2_CAND_SCENE_CH01-SCN-022_STREETS_V002_1672x941.jpg`

**Source:** [1lnMePbbXNHmDZTnbmcJW47RGbMtIfjo4](https://drive.google.com/file/d/1lnMePbbXNHmDZTnbmcJW47RGbMtIfjo4/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-022` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | The Gap Between Two Houses |
> | Parent location ID | CH01-SUB-009 (Streets) |
> | Scene category | EXTERIOR MICRO-LOCATION |
> | Canon status | **PROPOSED** |
> - **Physical description.** A space an arm wide between two house walls with a water jar in the shade.
> - **What the player sees.** Cool shadow, a jar, a cat.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** None.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Walls, jar.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`653983`bytes; MD5`5de0d4a73317c9a9a994b8c4cfbfdb34`; SHA256`673236db7cb1fa4456865806d2305cb20ca01b49fed2c5f3c3fe0966d30b1a8a`.
- Research:`2547`bytes; MD5`f567cbbb819f2e4ff1dcffc4b63c3d6c`; SHA256`170da97903c89b9deaeadcca50721df114d2dc2c0703a90ac50e3616d14c74b5`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E15_B2_CAND_SCENE_CH01-SCN-022_STREETS_V002_1672x941.md](https://drive.google.com/file/d/1c6wrflvqiS7B-29ZF7vKAM6X6_U-BSbV/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a narrow dirt street between mud-walled houses. A timber-framed roof-lattice of thatch and poles crosses the lane above. A pale cloth hangs on a line at the right, with a bunch of gourds on a peg. A clay pot and a wooden mortar with a pestle stand at the right. The house doors are timber, set in mud walls. The caption band reads 'SCENE_CH01-SCN-022_STREETS · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the lattice's purpose is not established by the image.
> - UNVERIFIED: the gourds' use and the cloth's material are not identified.
> - PRINTED LABEL: the file's label is 'SCN-022_STREETS'; the register names this as SCN-022 STREETS; no conflict found in this check.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Rough earth walls/timber doors, thatch/pole overhead shade lattice, plain cream cloth, gourds/pot/mortar; narrow dirt lane, no people visible. Current MD5 exactly equals closed-cycle accepted Streets V002.

**Independent assessment:** RETAIN existing visual pass; no material pixel/reference evidence to reverse it. Latest Research does not authenticate lattice technology; its function uncertainty is not proof of visual failure. SCN022 arm-wide gap/jar/cat details are future intended-use coverage questions, not authority to reopen identical accepted art.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Rough earth/timber/thatch lane and plain cloth correction outcome retained.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

RETAIN existing visual pass; no material pixel/reference evidence to reverse it. Latest Research does not authenticate lattice technology; its function uncertainty is not proof of visual failure. SCN022 arm-wide gap/jar/cat details are future intended-use coverage questions, not authority to reopen identical accepted art.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** NO NEW VISUAL DEFECT DECISION.

**Specific issue:** RETAIN existing visual pass; no material pixel/reference evidence to reverse it. Latest Research does not authenticate lattice technology; its function uncertainty is not proof of visual failure. SCN022 arm-wide gap/jar/cat details are future intended-use coverage questions, not authority to reopen identical accepted art.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**RETAIN EXISTING ACCEPTED VISUAL PASS ONLY**

**Existing CD record retained:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Rough earth/timber/thatch lane and plain cloth correction outcome retained.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

APPROVAL RECOMMENDED strictly for retaining the existing limited visual-review outcome. No new production/canon/cultural clearance. No correction or regeneration directed; owner separately confirms future scene coverage before final-use claim.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C10 source](https://drive.google.com/file/d/1xI5v1ZfeXyxE-laueJRmWsymvlFkJGgl/view) — archive`assessments/C10.md`; [F09 source](https://drive.google.com/file/d/1w5eDzRwcqRTUwDaifnlwK-i4f56wFRGa/view) — archive`assessments/F09.md`; [F22 source](https://drive.google.com/file/d/1WDUWvm66odU4igHjVazyV5JAzAQ6Qx05/view) — archive`assessments/F22.md`; [F59 source](https://drive.google.com/file/d/1qvIe2S7rmJA0G9eiGsCMvg4HckXAUYSu/view) — archive`assessments/F59.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e16"></a>

# E16 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E16` · **Filename:** `B2_CAND_SCENE_CH01-SCN-024_AN_EMPTY_HOUSE_V002_1672x941.jpg`

**Source:** [1VTA7bi3rAcf8o_oTXmmqQS3AjIkrt63H](https://drive.google.com/file/d/1VTA7bi3rAcf8o_oTXmmqQS3AjIkrt63H/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-024` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | The House No One Lives In |
> | Parent location ID | CH01-INT-015 (An Empty House) |
> | Scene category | ENVIRONMENTAL STORYTELLING |
> | Canon status | **PROPOSED** |
> - **Physical description.** An unoccupied house with thinning thatch and bare floor.
> - **What the player sees.** Light through the roof, a single upturned pot, a swept threshold.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** Yes. FULLY ENTERABLE: the player can walk in and explore.
> - **NPCs present.** None.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** House shell, pot.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`526628`bytes; MD5`544f4e97e0796c3bbf32cd9c5c3201f5`; SHA256`5e1ba6a871cbfd97f890f18d29510b8dc978f5b1857b2c3a217245d60882c3f0`.
- Research:`2810`bytes; MD5`c6f1f4caaa3e086c16002529f8f4bc6b`; SHA256`864885ee52a41f57820aeb4fb7ebcbf39a8aa333d41a5bad93cbb24d4a737c9f`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E16_B2_CAND_SCENE_CH01-SCN-024_AN_EMPTY_HOUSE_V002_1672x941.md](https://drive.google.com/file/d/1MYHZCw1ZnVHvrp6Sym_w5De-oUKSwjvg/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic interior of a mud-walled house with a thatched roof; light falls from a roof gap. A wooden mortar and a pestle stand at the left. A woven basket lies on its side, spilling red seeds onto a woven mat. A pale cloth and a blue cloth lie in the back corner. A net bag and a round woven sieve hang on the right wall, above a mud bench holding three clay pots. The caption band reads 'SCENE_CH01-SCN-024 · AN EMPTY HOUSE · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - LABEL CONFLICT: the file name says 'EMPTY HOUSE'; the image shows household objects. Recorded, not corrected.
> - UNVERIFIED: the red seeds are not identified; no crop or use is claimed.
> - UNVERIFIED: the net bag and sieve are not identified.
> - CONFLICT NOTE: the research record places an SCN-024 signature issue in C10–C14; this report does not resolve it.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Unoccupied earthen/thatch room with roof hole/light shaft; mortar/pestle, spilled red seeds on mat from basket, folded cloths, three pots, sieve/net bag. No clear signature in current full frame; no people.

**Independent assessment:** Research's 'EMPTY HOUSE versus objects' label-conflict diagnosis is too literal: register means unoccupied, not zero objects. Nevertheless SCN024 specifically bare floor/single upturned pot/swept threshold is replaced by abundant lived-in/spilled inventory. Raw V001 signature comparison still needs source, not assumed removal evidence.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Research's 'EMPTY HOUSE versus objects' label-conflict diagnosis is too literal: register means unoccupied, not zero objects. Nevertheless SCN024 specifically bare floor/single upturned pot/swept threshold is replaced by abundant lived-in/spilled inventory. Raw V001 signature comparison still needs source, not assumed removal evidence.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Research's 'EMPTY HOUSE versus objects' label-conflict diagnosis is too literal: register means unoccupied, not zero objects. Nevertheless SCN024 specifically bare floor/single upturned pot/swept threshold is replaced by abundant lived-in/spilled inventory. Raw V001 signature comparison still needs source, not assumed removal evidence.

**Dependencies:** SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**CORRECTION REQUIRED**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

CORRECTION REQUIRED if this is SCN024 storytelling coverage: reconcile object staging to canonical unoccupied/bare-floor/single-upturned-pot/swept-threshold brief, without claiming empty must mean featureless. Owner files exact authorised action; no deletion of evidence or regeneration inferred.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C12 source](https://drive.google.com/file/d/19Ct7vvsF0xa-ClBi621JVkpxGrzgJQlf/view) — archive`assessments/C12.md`; [F27 source](https://drive.google.com/file/d/1gCIEHoYYFlPzvQ6gzEqKoGACu_xR4Lsz/view) — archive`assessments/F27.md`; [F58 source](https://drive.google.com/file/d/12Lkat1YdzLdBKPkMHMJUIjTSFzuEQAHB/view) — archive`assessments/F58.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e17"></a>

# E17 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E17` · **Filename:** `B2_CAND_SCENE_CH01-SCN-025_ANIMAL_PENS_V002_1672x941.jpg`

**Source:** [1N9evqu7rf1BspncPBVZZVAs_HKv-ZCkA](https://drive.google.com/file/d/1N9evqu7rf1BspncPBVZZVAs_HKv-ZCkA/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-025` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Goats at Dusk |
> | Parent location ID | CH01-SUB-022 (Animal Pens) |
> | Scene category | ATMOSPHERIC SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** A pen against the wall.
> - **What the player sees.** Goats being driven in by a boy, dust in the low light.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** One boy.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Pen, goats.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`664448`bytes; MD5`9069fc6346e82986aa33085378318293`; SHA256`b996f98a326f17502a1be227537ffbf8af9a6f985b8765135e12d6bc270297cf`.
- Research:`2640`bytes; MD5`ce72f98c4ef61efdd3c5cef8a514c047`; SHA256`a7bb609023861cf3123cbc64bfa2ca1022b05f16cf4fc218a6193d603c44ece6`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E17_B2_CAND_SCENE_CH01-SCN-025_ANIMAL_PENS_V002_1672x941.md](https://drive.google.com/file/d/1VsZOD9eaIZPmwmFqFdLRE6NmSte0t3Z_/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a walled yard. Wattle fencing forms pens, one with upright stakes. A thatched open-sided shed on timber posts stands behind the pens. A round, thatched, mud-walled hut with a dark doorway stands at the right. A long hollowed wooden trough holds water in the foreground, with a puddle at the bottom edge. The caption band reads 'SCENE_CH01-SCN-025 · ANIMAL PENS · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the species the pens would hold is not shown; no animal use is established.
> - UNVERIFIED: the trough's origin and carving method are not established.
> - UNVERIFIED: the round hut's function is not stated by the image.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Wattle pens, trough water, open thatch shed and round hut, green tree backdrop; no people or animals visible.

**Independent assessment:** Pen infrastructure legible. Lack of animals is not automatically OAD40 breach, but registered SCN025 Goats at Dusk/low light is not delivered by this empty daylight habitat. No species can be inferred from pens alone.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Pen infrastructure legible. Lack of animals is not automatically OAD40 breach, but registered SCN025 Goats at Dusk/low light is not delivered by this empty daylight habitat. No species can be inferred from pens alone.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Pen infrastructure legible. Lack of animals is not automatically OAD40 breach, but registered SCN025 Goats at Dusk/low light is not delivered by this empty daylight habitat. No species can be inferred from pens alone.

**Dependencies:** SCENE_VS_PARENT_SCOPE; ANIMAL_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD: CD settles habitat-only versus SCN025 activity/mood scope and applicable figure/animal allowance. Do not automatically add child/goats or infer a sacred-livestock rule. Keep pen construction unvalidated until referenced.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C12 source](https://drive.google.com/file/d/19Ct7vvsF0xa-ClBi621JVkpxGrzgJQlf/view) — archive`assessments/C12.md`; [F27 source](https://drive.google.com/file/d/1gCIEHoYYFlPzvQ6gzEqKoGACu_xR4Lsz/view) — archive`assessments/F27.md`; [F58 source](https://drive.google.com/file/d/12Lkat1YdzLdBKPkMHMJUIjTSFzuEQAHB/view) — archive`assessments/F58.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e18"></a>

# E18 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E18` · **Filename:** `B2_CAND_SCENE_CH01-SCN-027_POTTERS_YARD_V002_1672x941.jpg`

**Source:** [1rWjKHHTvwL7oxaqVs8W1oGO2Vqyvm5Ff](https://drive.google.com/file/d/1rWjKHHTvwL7oxaqVs8W1oGO2Vqyvm5Ff/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-027` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | Pots Drying |
> | Parent location ID | CH01-INT-011 (The Potter's Yard) |
> | Scene category | WORLD ACTIVITY SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** Rows of unfired pots in the sun.
> - **What the player sees.** A potter building a pot by hand from coils, turning round it as she works.
> - **What the player can interact with.** Speak to her.
> - **Can the player enter the space?** Yes. FULLY ENTERABLE: the player can walk in and explore.
> - **NPCs present.** One potter.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Pots, clay, firing place.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`679024`bytes; MD5`bac4b3cff61ef9c698ff6c8a9c0c1f84`; SHA256`524a19c91aaff62be7a82c09dc01ce17a7eb5cfa0dbac136b89b01998645034d`.
- Research:`2811`bytes; MD5`07adab985ba7342d7fb83a075af07bc7`; SHA256`6c2ed34370dc2921995ea7c3c78612142a65543c8826e60a86b47fea4d5234a9`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E18_B2_CAND_SCENE_CH01-SCN-027_POTTERS_YARD_V002_1672x941.md](https://drive.google.com/file/d/1Irs8ScXP-lYux0jtmA1BN4TV3W1tVuJx/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a walled yard with a thatched house at the left and a small open shed. A mud-rimmed circular hearth holds burning and charred wood, with a stack of sticks beside it. Rows of clay bowls and jars sit on woven mats, with jars on a timber rack behind them. A lump of clay sits on a cloth, and two baskets hold potsherds at the right. The caption band reads 'SCENE_CH01-SCN-027 · THE POTTER'S YARD · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the circular hearth is a fire pit in the image; it is not identified as a kiln. The fire-ring question raised for E04 and ST04 V002 applies in kind; not ruled here.
> - UNVERIFIED: the firing method, the clay source and the pots' finish are not established.
> - UNVERIFIED: the covered mound's contents are not identified.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Earthen yard, rows of clay vessels on mats/rack, clay lump, sherd baskets, fuel pile and low round earth-rimmed charred fire area; rear covered mound. No potter; no unmistakable flames (charred coals/ash visible).

**Independent assessment:** Registered SCN027 includes pots/clay/firing place, so generic hearth is relevant, not inherently ritual. Research overstates burning fire/stone-ring analogy: no basis to import ST04 ring ruling wholesale or identify firing technology/kiln from shape. Broad drying/firing staging not culturally authenticated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Registered SCN027 includes pots/clay/firing place, so generic hearth is relevant, not inherently ritual. Research overstates burning fire/stone-ring analogy: no basis to import ST04 ring ruling wholesale or identify firing technology/kiln from shape. Broad drying/firing staging not culturally authenticated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Registered SCN027 includes pots/clay/firing place, so generic hearth is relevant, not inherently ritual. Research overstates burning fire/stone-ring analogy: no basis to import ST04 ring ruling wholesale or identify firing technology/kiln from shape. Broad drying/firing staging not culturally authenticated.

**Dependencies:** POTTERY_FIRING_REFERENCE; SCENE_VS_PARENT_SCOPE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD Research/CD confirmation of firing-place/production-method and habitat-only versus activity-sequence coverage; no invented kiln design, sacred-ring diagnosis or automatic hearth removal.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C12 source](https://drive.google.com/file/d/19Ct7vvsF0xa-ClBi621JVkpxGrzgJQlf/view) — archive`assessments/C12.md`; [F27 source](https://drive.google.com/file/d/1gCIEHoYYFlPzvQ6gzEqKoGACu_xR4Lsz/view) — archive`assessments/F27.md`; [F58 source](https://drive.google.com/file/d/12Lkat1YdzLdBKPkMHMJUIjTSFzuEQAHB/view) — archive`assessments/F58.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e19"></a>

# E19 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E19` · **Filename:** `B2_CAND_SCENE_CH01-SCN-032_WELLS_V002_1672x941.jpg`

**Source:** [1GTFnMdZMqesUXdWeLhFApVdiRsownwb0](https://drive.google.com/file/d/1GTFnMdZMqesUXdWeLhFApVdiRsownwb0/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-032` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | The Well at Noon |
> | Parent location ID | CH01-SUB-014 (Wells) |
> | Scene category | ATMOSPHERIC SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** A dug well with a log rim and a rope worn smooth.
> - **What the player sees.** Empty at midday; a gourd dipper swinging slightly.
> - **What the player can interact with.** Draw water.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** None.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Well rim, rope, dipper.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`770431`bytes; MD5`3e5022b918e6a0e80e62a788ffed98ad`; SHA256`3f34fbfd30eea7e975dd4a94cdbdd6d74ed572ce9e5ebe100458d78f9ebd51ca`.
- Research:`2827`bytes; MD5`dc7967b0c242957b4e5b71a5cf45697b`; SHA256`0e425f36b630e30009964745e86172e0075bd1076404d642be186c258e161d60`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E19_B2_CAND_SCENE_CH01-SCN-032_WELLS_V002_1672x941.md](https://drive.google.com/file/d/1rb5GZaMZHZHpPwjnlxOgPPHy4ZKLdAlD/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a village yard with two round, mud-lined wells, one with a rope coiled on its rim and a gourd bowl on the other. A goat stands at the left by the thatched houses. Gourds hang from a stick near the wells. A shallow water channel runs through the yard. At the right, a wooden mortar and pestle stand by a timber-framed open shed and a conical thatched hut. A broken clay pot lies at the bottom right. The caption band reads 'SCENE_CH01-SCN-032 · WELLS · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - CAPTION CONFLICT: the caption band says 'figures 0 (OAD-40)'; the image shows an animal (goat). Human figures are not shown; the animal is recorded, not corrected.
> - UNVERIFIED: the wells' depth and water level are not visible.
> - UNVERIFIED: the channel's purpose and the gourds' use are not established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Two rough earthen well rims, rope/dipper, shallow runoff channel, pots/shed/thatch houses and goat at left; no people. Exact bytes/hash equal historical accepted Wells V002.

**Independent assessment:** RETAIN accepted visual correction outcome. Research's goat-versus-'figures0' conflict is not established without proving figures meant animals; no instruction to delete goat. Source does not establish engineering depth/sanitation, which was never granted by visual pass. Registered log-rim/noon specifics not silently substituted for accepted earthen-rim correction.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Earthen rims/simple runoff/no windlass visual outcome retained; no engineering or cultural authentication.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

RETAIN accepted visual correction outcome. Research's goat-versus-'figures0' conflict is not established without proving figures meant animals; no instruction to delete goat. Source does not establish engineering depth/sanitation, which was never granted by visual pass. Registered log-rim/noon specifics not silently substituted for accepted earthen-rim correction.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** NO NEW VISUAL DEFECT DECISION.

**Specific issue:** RETAIN accepted visual correction outcome. Research's goat-versus-'figures0' conflict is not established without proving figures meant animals; no instruction to delete goat. Source does not establish engineering depth/sanitation, which was never granted by visual pass. Registered log-rim/noon specifics not silently substituted for accepted earthen-rim correction.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**RETAIN EXISTING ACCEPTED VISUAL PASS ONLY**

**Existing CD record retained:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Earthen rims/simple runoff/no windlass visual outcome retained; no engineering or cultural authentication.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

APPROVAL RECOMMENDED only for retention of existing visual pass; no new engineering/cultural/canon clearance or artwork change. Any future well-engineering/scene-coverage decision must be separately sourced by owner.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C10 source](https://drive.google.com/file/d/1xI5v1ZfeXyxE-laueJRmWsymvlFkJGgl/view) — archive`assessments/C10.md`; [F18 source](https://drive.google.com/file/d/1CQkT3YpHES7krjjGB93bZqERKwe0zv0j/view) — archive`assessments/F18.md`; [F19 source](https://drive.google.com/file/d/12PYjx-mGY86qFkpobliG46-DFklLzdga/view) — archive`assessments/F19.md`; [F53 source](https://drive.google.com/file/d/1ivS14J-IkNs9BkyXqfh0Sy5K0gDJusK8/view) — archive`assessments/F53.md`; [F61 source](https://drive.google.com/file/d/1lyjvnekcrBHdU03Ya5cNCwFaVjSnD45a/view) — archive`assessments/F61.md`; [F62 source](https://drive.google.com/file/d/1ko3w_HJjtpcIWRPNMVlbu9R3XWMTOGrY/view) — archive`assessments/F62.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e20"></a>

# E20 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E20` · **Filename:** `B2_CAND_SCENE_CH01-SCN-033_GATES_V002_1672x941.jpg`

**Source:** [1OwSkuBRB1VMKdI7iPE4sYw3xypr-EyZD](https://drive.google.com/file/d/1OwSkuBRB1VMKdI7iPE4sYw3xypr-EyZD/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-033` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | The Gate at Night |
> | Parent location ID | CH01-LMK-003 (Gates) |
> | Scene category | ATMOSPHERIC SCENE |
> | Canon status | **PROPOSED** |
> - **Physical description.** The settlement gate closed, a fire in the guard shelter.
> - **What the player sees.** Firelight on carved gateposts, the dark road and the forest beyond.
> - **What the player can interact with.** None.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** One guard.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Gate, fire.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`629033`bytes; MD5`995d69623e1233f68573be098aa6bee8`; SHA256`0732dea4123b27229960794f5b444c50bc698799be366cdebaed7bb47e2a5155`.
- Research:`2638`bytes; MD5`91b8d052eb022717e5d62f7fed5a49d3`; SHA256`8595dc7618d15691bd5bda2bdd2f69757ca0c974ba31c8387e240644a369bf31`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E20_B2_CAND_SCENE_CH01-SCN-033_GATES_V002_1672x941.md](https://drive.google.com/file/d/1imc-3U2fFZPeE4M68TCV-jTBh5wDjZcp/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view down a dirt track toward a village. A timber gate frame with two upright posts and a crossbeam, bound with cord, stands across the track. Low mud walls with brushwood fencing on top run left and right of the gate. Thatched mud houses, a conical thatched hut and a distant hill fill the view. The caption band reads 'SCENE_CH01-SCN-033 · GATES · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: whether the gate is a functional entry or a ceremonial frame is not established by the image.
> - UNVERIFIED: the cord-binding method and the brushwood fencing's construction are not identified.
> - UNVERIFIED: the distant hill's name and location are not established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Rough cord-bound timber gateway, brushwood on low earth walls, thatch houses/track beyond, daylight; no people or gate leaf/fire shown. Hash equals historical accepted Gates V002.

**Independent assessment:** RETAIN accepted rough-material gateway visual outcome. Research uncertainty functional-versus-ceremonial is not evidence of ceremonial use. SCN033 gate-at-night/closed/fire mood requirement is a separate incomplete-coverage/intended-use question, not a reversal of accepted material correction.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Rough timber/brush-earth gateway correction outcome retained.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

RETAIN accepted rough-material gateway visual outcome. Research uncertainty functional-versus-ceremonial is not evidence of ceremonial use. SCN033 gate-at-night/closed/fire mood requirement is a separate incomplete-coverage/intended-use question, not a reversal of accepted material correction.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** NO NEW VISUAL DEFECT DECISION.

**Specific issue:** RETAIN accepted rough-material gateway visual outcome. Research uncertainty functional-versus-ceremonial is not evidence of ceremonial use. SCN033 gate-at-night/closed/fire mood requirement is a separate incomplete-coverage/intended-use question, not a reversal of accepted material correction.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**RETAIN EXISTING ACCEPTED VISUAL PASS ONLY**

**Existing CD record retained:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Rough timber/brush-earth gateway correction outcome retained.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

APPROVAL RECOMMENDED only for retaining prior limited visual pass; no new nighttime-state, cultural or production approval. No regeneration or gate-leaf addition automatically authorised.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C10 source](https://drive.google.com/file/d/1xI5v1ZfeXyxE-laueJRmWsymvlFkJGgl/view) — archive`assessments/C10.md`; [F19 source](https://drive.google.com/file/d/12PYjx-mGY86qFkpobliG46-DFklLzdga/view) — archive`assessments/F19.md`; [F62 source](https://drive.google.com/file/d/1ko3w_HJjtpcIWRPNMVlbu9R3XWMTOGrY/view) — archive`assessments/F62.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e21"></a>

# E21 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E21` · **Filename:** `B2_CAND_SCENE_CH01-SCN-034_ROADS_V002_1672x941.jpg`

**Source:** [1CKaEzdNb-Xom9W0DprYxMtPspIphuFqi](https://drive.google.com/file/d/1CKaEzdNb-Xom9W0DprYxMtPspIphuFqi/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical scene entry `CH01-SCN-034` ([register](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view)), not automatically equivalent to the submitted habitat concept:

> | Scene name | A Quiet Resting Place by the Road |
> | Parent location ID | CH01-TRV-005 (Roads) |
> | Scene category | EXTERIOR MICRO-LOCATION |
> | Canon status | **PROPOSED** |
> - **Physical description.** A flat stone under a tree where the farm road leaves the settlement.
> - **What the player sees.** A place to sit, with a view back to the roofs.
> - **What the player can interact with.** Sit.
> - **Can the player enter the space?** Not an interior. Open exterior space the player walks through.
> - **NPCs present.** Sometimes a traveller.
> - **Lighting and atmosphere.** Warm daylight, hearth light at night. Mood: Lived-in, ordered, under strain.
> - **Required assets.** Stone, tree.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`597901`bytes; MD5`fce770de8914f21dbd2b62e12bbc6927`; SHA256`511063aeed82a0162acf90947a8c494c67d14fc5d3910f07db3bb70b9deab284`.
- Research:`2551`bytes; MD5`ee86340138a9f939d89ca1f557ea6f88`; SHA256`d97dab5ce3852dec975c88eb1103e7ddd71521a622d34ba35f7c5295eef58a3a`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E21_B2_CAND_SCENE_CH01-SCN-034_ROADS_V002_1672x941.md](https://drive.google.com/file/d/1MVXfdhTy_tRe0-X6DMPLR28favz1eFDF/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A photographic view of a narrow muddy lane between red mud walls. Thatched roofs with brushwood and thorny stems on the eaves stand at the left. At the right, two doorways have blue cloth hanging in them. Potsherds and a fallen branch lie on the lane; a large tree and palms stand beyond. The caption band reads 'SCENE_CH01-SCN-034 · ROADS · V002'.

**Published flags (original wording, including any error reconciled below):**

> - 'NO CULTURAL CLAIM' IS THE PLATE'S STATEMENT: recorded as printed. The visible items carry cultural content; the disclaimer does not settle that. Flagged for the research base; not interpreted here.
> - UNVERIFIED: the blue cloths' dye is not identified; no indigo practice is claimed.
> - UNVERIFIED: the brushwood on the eaves is not identified and its purpose is not established.
> - UNVERIFIED: the tree's species is not established.
> - ASSISTANT scene plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Continuous red-earth lane walls, plain indigo doorway hangings, rough thatch/eaves brushwood, shards/branches and trees; no people. Hash equals historical accepted Roads V002.

**Independent assessment:** RETAIN visual wall/plain-textile outcome; unverified brushwood function is not reason to reverse it. Does not demonstrate whole road network or specific registered roadside resting-stone/tree beat; that is future coverage/intended-use scope, not an invented defect requiring repeated same review.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [SCENE_AND_MICROLOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) — D3; 19 relevant CH01 complete entries fully read, not entire register.
- [MOODBOARD_GENERATION_LIST.md](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) — D3; full text.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Continuous red-earth wall/plain-cloth correction outcome retained; earlier HOLD lift was visual-only.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

RETAIN visual wall/plain-textile outcome; unverified brushwood function is not reason to reverse it. Does not demonstrate whole road network or specific registered roadside resting-stone/tree beat; that is future coverage/intended-use scope, not an invented defect requiring repeated same review.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** NO NEW VISUAL DEFECT DECISION.

**Specific issue:** RETAIN visual wall/plain-textile outcome; unverified brushwood function is not reason to reverse it. Does not demonstrate whole road network or specific registered roadside resting-stone/tree beat; that is future coverage/intended-use scope, not an invented defect requiring repeated same review.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**RETAIN EXISTING ACCEPTED VISUAL PASS ONLY**

**Existing CD record retained:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Continuous red-earth wall/plain-cloth correction outcome retained; earlier HOLD lift was visual-only.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

APPROVAL RECOMMENDED only to retain existing visual pass; no new production/cultural/canon approval and no artwork correction. Owner confirms future road/micro-location coverage separately.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C10 source](https://drive.google.com/file/d/1xI5v1ZfeXyxE-laueJRmWsymvlFkJGgl/view) — archive`assessments/C10.md`; [F20 source](https://drive.google.com/file/d/1i1gv_CHPnUj-xpr7Gvx06JLxp_BEHk6l/view) — archive`assessments/F20.md`; [F63 source](https://drive.google.com/file/d/1iaev_4IWhgU95v--1S75_NP32dJaTEeJ/view) — archive`assessments/F63.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e22"></a>

# E22 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E22` · **Filename:** `B2_COMPARE_ADANNA_TURNAROUND_V002_alignment.jpg`

**Source:** [17PXQi9TGyQvMcNynmmnYzOsJFKLQczTX](https://drive.google.com/file/d/17PXQi9TGyQvMcNynmmnYzOsJFKLQczTX/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2580×823 JPEG; decoded modeRGB. 

- Source:`277898`bytes; MD5`2c2952fe5ea6b131fb68067ff7b8c652`; SHA256`56451f5f6329211e4bd96be3d740aec05688f10e2135474b652e6349039ab03a`.
- Research:`3146`bytes; MD5`65d4733ac9e2897920e27bf8c397dc95`; SHA256`0abaec7cff36d84a3aba55c5fbed632fced38b7f597bfa59df3dbf52cbaec7e0`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E22_B2_COMPARE_ADANNA_TURNAROUND_V002_alignment.md](https://drive.google.com/file/d/1-SOIXFlNz1bEBwUiSdh8Cg3SxlGVbC7B/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A four-panel orthographic-style turnaround titled 'ADANNA — TURNAROUND V002' on a dark sheet: FRONT, LEFT SIDE, BACK and THREE QUARTER. Each panel shows a standing female figure in a navy bandeau top and a long navy wrap skirt, barefoot, with braids and a crossing strap. Header text: 'Candidate for review — not an approved asset'; and 'No blade depicted in this set — CQ-9 OPEN.'

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN SOURCE: the printed note says the passes put the scabbard on her RIGHT hip; the costume sheet (E24) places the blade on the LEFT hip. Recorded, not resolved.
> - NAME AS PRINTED: 'Our Eyes' is the reviewer label printed on the sheet; not checked against any register.
> - UNVERIFIED: the baldric's route is the strap as drawn; whether it carries a scabbard is not shown.
> - UNVERIFIED: the braid style, skin tone and the scar's identity are visual readings only.
> - CQ-9 OPEN: no blade or scabbard is depicted; this report does not clear the blade question.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Four aligned full-length character panels on neutral grey, labelled FRONT/LEFT SIDE/BACK/THREE QUARTER, indigo wraps, braid knot and brown diagonal strap; no weapon visible. Footer copy explicitly RIGHT shoulder→LEFT hip; numeric crown/floor/height statistics printed.

**Independent assessment:** Historical V002 aid with later-superseded baldric wording. This is exactly the seven-correction copy issue; do not infer new anatomical authority from it or reopen later user ruling. At reduced panel size footwear appears dark/bare-foot-like; cannot override native individual PNGs. Printed metrics not independently recomputed from original V002s.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Historical V002 aid with later-superseded baldric wording. This is exactly the seven-correction copy issue; do not infer new anatomical authority from it or reopen later user ruling. At reduced panel size footwear appears dark/bare-foot-like; cannot override native individual PNGs. Printed metrics not independently recomputed from original V002s.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Historical V002 aid with later-superseded baldric wording. This is exactly the seven-correction copy issue; do not infer new anatomical authority from it or reopen later user ruling. At reduced panel size footwear appears dark/bare-foot-like; cannot override native individual PNGs. Printed metrics not independently recomputed from original V002s.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain historical evidence-only aid and link E23 plus current D03/D04/D01/D06. No original-aid edits or automatic V004 set; no approval from printed geometry claims.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E23 source](https://drive.google.com/file/d/1pijFOgm8JQJNn_2xe4rk3wK4dOYjeYw0/view) — archive`assessments/E23.md`; [F13 source](https://drive.google.com/file/d/1sQLIp0vR0a7A1NRslMatte-aMnSdcKz_/view) — archive`assessments/F13.md`; [F33 source](https://drive.google.com/file/d/1obe3Ry3B8TJosyB4bVyVRUWih-eCNS2l/view) — archive`assessments/F33.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e23"></a>

# E23 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E23` · **Filename:** `B2_COMPARE_ADANNA_TURNAROUND_V003_alignment.jpg`

**Source:** [1pijFOgm8JQJNn_2xe4rk3wK4dOYjeYw0](https://drive.google.com/file/d/1pijFOgm8JQJNn_2xe4rk3wK4dOYjeYw0/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2580×861 JPEG; decoded modeRGB. 

- Source:`300888`bytes; MD5`e10c3802834c3e4d6bf80eed80ab1afe`; SHA256`5ad04cab4b166e000bd13b89bc7b36d76fc944f24f590882aa45713c87d4f7bf`.
- Research:`3240`bytes; MD5`91e96bc1c8255872d44d29761ffe4671`; SHA256`d769b5eaa2a9d6a96253325690f7e101059c0220d0023b39803688914fc467c1`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E23_B2_COMPARE_ADANNA_TURNAROUND_V003_alignment.md](https://drive.google.com/file/d/1k5knH47J0st-LZAQQUhrF5gvaRCh0TL9/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A four-panel turnaround titled 'ADANNA — TURNAROUND V003' on a dark sheet: 1. FRONT, 2. LEFT SIDE, 3. BACK, 4. THREE QUARTER. Each panel shows a standing female figure in a navy bandeau top and a navy wrap skirt, barefoot, with braids and a crossing strap. The header reads 'EXPLORATORY — NOT APPROVED CANON · STATUS: REVIEW REQUIRED · UNAPPROVED — PENDING REVIEW'.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN SOURCE: the baldric route is printed as left shoulder to right hip here, but as right shoulder to left hip on the V002 turnaround (E22). The two sheets differ; the costume sheet (E24) places the blade on the left hip. Recorded, not resolved.
> - UNVERIFIED: the seven rejection answers are printed on the sheet; this report has not checked them against the rejection report, which is not in the registers.
> - UNVERIFIED: the spiral pendant is printed as fictional; no Igbo provenance is claimed or checked here.
> - CQ-9 OPEN: no blade or scabbard is depicted; this report does not clear the blade question.
> - Not approved by this report.

## 05. Independent content findings

**Direct source observation:** Numbered four-panel V003 layout, same neutral framing, plain coil/pendant treatment smaller than full PNG displays; footer now anatomical LEFT shoulder→RIGHT hip, fictional pendant and no-blade/CQ9 text.

**Independent assessment:** Copy correction directly verified relative to E22. No fresh chirality uncertainty: user's BACK viewer-left LEFT override governs, artwork preserved. Adequacy of micro-corrections must use native D images, not this compressed alignment JPEG. Seven-point-complete claim is author assertion, not reviewer pass.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Copy correction directly verified relative to E22. No fresh chirality uncertainty: user's BACK viewer-left LEFT override governs, artwork preserved. Adequacy of micro-corrections must use native D images, not this compressed alignment JPEG. Seven-point-complete claim is author assertion, not reviewer pass.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Copy correction directly verified relative to E22. No fresh chirality uncertainty: user's BACK viewer-left LEFT override governs, artwork preserved. Adequacy of micro-corrections must use native D images, not this compressed alignment JPEG. Seven-point-complete claim is author assertion, not reviewer pass.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve historical V003 alignment evidence; make exact individual-source links in assessment index. Do not use to relabel BACK/LEFT_SIDE or clear cord/orthographic/cultural gates.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E22 source](https://drive.google.com/file/d/17PXQi9TGyQvMcNynmmnYzOsJFKLQczTX/view) — archive`assessments/E22.md`; [F15 source](https://drive.google.com/file/d/1Ay5cP6XKdVc6YWptNgmK0x4liB-PT-wn/view) — archive`assessments/F15.md`; [F34 source](https://drive.google.com/file/d/1-QexQjgdEF8B6qdy3nRWX2GwH6LH7YeJ/view) — archive`assessments/F34.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e24"></a>

# E24 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E24` · **Filename:** `B2_COMPARE_COSTUME_BREAKDOWN_V001_vs_V002.jpg`

**Source:** [16nRB4iN6OAco8K5XN4OKfCqNAOAnNz1E](https://drive.google.com/file/d/16nRB4iN6OAco8K5XN4OKfCqNAOAnNz1E/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Standing CD/user controls and existing Adanna correction scope govern. Approved master is an identity anchor, not a complete weapon/hand-scale/full-body construction authority. Preserve anatomical LEFT identity locks and drawn LEFT-shoulder→RIGHT-hip baldric; BACK viewer-left is anatomical LEFT. CQ-9/RQ-10-1 remain open; U-11 fictional. Native image evidence is required, not a compressed comparison panel.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2200×1088 JPEG; decoded modeRGB. 

- Source:`536913`bytes; MD5`16b40eeea9cdcb44d1cf6a371f8b4f38`; SHA256`34f552f1a5597ba2e7601a88608b524e27283187ebb34fdb439d8b5126ad40a4`.
- Research:`4475`bytes; MD5`4abd75034400319616b237000796370b`; SHA256`37a11118d63c5ae54c5c3a16fa519aeeec30fdcc406949470bb807a6a8954fdb`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E24_B2_COMPARE_COSTUME_BREAKDOWN_V001_vs_V002.md](https://drive.google.com/file/d/1stvbJd1s5pglhWYRwmB7jQEy0DlBfQ2g/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A two-panel comparison titled 'ADANNA — COSTUME BREAKDOWN · V001 rejected -> V002 CANDIDATE'. Left: CHAR_ADANNA_COSTUME_BREAKDOWN_V001, labelled UNAPPROVED — PENDING CD, with a full-front figure, a back-torso panel marked 'UNRESOLVED — NOT APPROVED', a left-temple and armlet detail, a right-side panel marked 'plain by design / nothing added', and a hex palette. Right: V002 candidate sheet, labelled UNAPPROVED — PENDING CD, with a front-and-three-quarter figure, identity-lock swatches, a tag key, unresolved panels for the right side, back torso and lower body, and a palette. Bottom notes list CRITICAL and MAJOR items as printed.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN SOURCE: the V001 sheet places the blade on the LEFT hip; the V002 turnaround note (E22) places the scabbard on the RIGHT hip. Recorded, not resolved.
> - PRINTED DEFECTS: bottom notes list CRITICAL 1 and 2 (beads and scar on the right side and both temples), CRITICAL 3 (misdirected scabbard pointer), MAJOR 4 (invented skirt, detailed unapproved weapon) and MODERATE 5 (hex codes); this report records them as printed and does not verify them.
> - LEGIBILITY: the palette labels 'V001 palette' and 'V002 palette' overlap in the image; the bottom notes are cut off at the right edge.
> - UNVERIFIED: the master reference cited (MD5 901a5009…) is not in the registers.
> - OPEN DEPENDENCY (printed): V001's full front figure and right profile are drawn plates that are not in the approved reference set; V002 cannot reproduce them without new artwork.
> - CQ-9 OPEN: blade and scabbard construction not drawn; this report does not clear the blade question.
> - Unapproved working sheet; not canon. Not approved by this report.

## 05. Independent content findings

**Direct source observation:** Left V001 costume board detailed full/front/right/back concept with unresolved back banner; right V002 has approved-master-looking portrait/detail crops and hatched unresolved zones. Lower palette labels overlap and some annotation is small/cut at canvas edge.

**Independent assessment:** Right-hand method/unfinished-area disclosure materially more honest; standalone V002 source outside PENDING needs resolution, not substitution with this thumbnail. Exact primary/approved-master copies now metadata-resolved; prior Research absence is listing-scope qualification, not global absence. Footnote addresses past right-side/scabbard claims; embedded V001 need not match V002 defect state.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Right-hand method/unfinished-area disclosure materially more honest; standalone V002 source outside PENDING needs resolution, not substitution with this thumbnail. Exact primary/approved-master copies now metadata-resolved; prior Research absence is listing-scope qualification, not global absence. Footnote addresses past right-side/scabbard claims; embedded V001 need not match V002 defect state.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Right-hand method/unfinished-area disclosure materially more honest; standalone V002 source outside PENDING needs resolution, not substitution with this thumbnail. Exact primary/approved-master copies now metadata-resolved; prior Research absence is listing-scope qualification, not global absence. Footnote addresses past right-side/scabbard claims; embedded V001 need not match V002 defect state.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain as historical comparison, not raw costume-master approval. If operational republication of aid authorised, reflow overlapping/cut labels without artwork changes, per style guide exact typeset labels; do not overwrite historical aid or fill hatched areas. Link exact source instead.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C18 source](https://drive.google.com/file/d/18Ehnq1cIcE6eu8fE7Wzidk9aDfNm9aTI/view) — archive`assessments/C18.md`; [F30 source](https://drive.google.com/file/d/14reSojyyOr-qbvuFwJP-sOqCcNSvq95e/view) — archive`assessments/F30.md`; [F35 source](https://drive.google.com/file/d/1uvSrH46ihg7ZNYwBKFNDYQiVUJtalN1H/view) — archive`assessments/F35.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e25"></a>

# E25 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E25` · **Filename:** `B2_COMPARE_ESTABLISHING.jpg`

**Source:** [1HWiL2cB_DYiDG2Kfi3NpeOA_RwdYrPeG](https://drive.google.com/file/d/1HWiL2cB_DYiDG2Kfi3NpeOA_RwdYrPeG/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ([brief](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view)) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1940×734 JPEG; decoded modeRGB. 

- Source:`526257`bytes; MD5`1cd0a2fb4d4eb45a662213f486dafa9b`; SHA256`6e39b2f8e9fcb5f2e0b2d5f0798ac5bd51b75dd3d3401d6933a4f2ed4444f4e8`.
- Research:`3120`bytes; MD5`13ed019d6e724687d75aa4084b63f30d`; SHA256`8f08a890022087aea66044e74503fd49a850b845ed124948bbe06d840576c77b`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E25_B2_COMPARE_ESTABLISHING.md](https://drive.google.com/file/d/1DZkmLsg1e-9iBC4i0MOllpFgGj65fmlF/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A side-by-side comparison titled 'ESTABLISHING VIEW ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING — V005 (REVIEW REQUIRED) -> V006 CANDIDATE (REVIEW REQUIRED)'. Left: ORIGINAL V005 master, 2560x1440. Right: CANDIDATE V006, 2560x1440. Both show a settlement of thatched mud houses in the foreground; a stepped, pyramid-like mound on the right; a long pillared hall at the left; and a pale band across the sky. No figures are visible in either panel.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED ARCHITECTURE: the stepped, pyramid-like mound and the pillared hall are fictional proposals; no source in this file supports them.
> - CONFLICT: the printed note says figures were removed by hand; the figure's removal cannot be checked from the image. Recorded as printed.
> - UNVERIFIED: the printed note says one low house is lit by warm low sun, without naming it; Nneka's house is printed as not visible in V006.
> - NOTE: the printed notes are cut off at the bottom edge.
> - Labelled exploratory; review required; not approved by this report.

## 05. Independent content findings

**Direct source observation:** V005/V006 realm pair with foreground earthen/thatch compounds, long pillared hall, stacked house mound, pale aerial band and inverted overhead settlement. V006 foreground visibly brighter/restaged. Footer includes claimed figure removal and residual drift, bottom text clipped.

**Independent assessment:** A new warm low house/compound treatment does not prove approved Nneka identity; no quantified original pixel preservation here. 'No V006 exists in Drive' is explicitly about requested pre-existing master before output, not a contradiction because a V006 candidate is shown. Fictional realm architecture stays proposed/consultant-gated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [REJECTION_REPORT_ESTABLISHING_V012.md](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) — D2; full text.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) — D3; individual full image display.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

A new warm low house/compound treatment does not prove approved Nneka identity; no quantified original pixel preservation here. 'No V006 exists in Drive' is explicitly about requested pre-existing master before output, not a contradiction because a V006 candidate is shown. Fictional realm architecture stays proposed/consultant-gated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** A new warm low house/compound treatment does not prove approved Nneka identity; no quantified original pixel preservation here. 'No V006 exists in Drive' is explicitly about requested pre-existing master before output, not a contradiction because a V006 candidate is shown. Fictional realm architecture stays proposed/consultant-gated.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain diagnostic history only; do not revive V006 or claim corrected current D08 from this pair. Operational aid reflow, if requested, must preserve old evidence and distinguish source/master absence from output.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F02 source](https://drive.google.com/file/d/1U4xF6NUFrVnSEW3ljz5_FBUWOYMOsZYD/view) — archive`assessments/F02.md`; [F47 source](https://drive.google.com/file/d/1xPD33CTWybukTy10WP5TLN9k6XK3fkFy/view) — archive`assessments/F47.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e26"></a>

# E26 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E26` · **Filename:** `B2_COMPARE_ESTABLISHING_V005_vs_V007.jpg`

**Source:** [1A10-FlflAwN3yuI_OVpgRSPS_nl0eCk0](https://drive.google.com/file/d/1A10-FlflAwN3yuI_OVpgRSPS_nl0eCk0/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ([brief](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view)) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2200×1276 JPEG; decoded modeRGB. 

- Source:`901851`bytes; MD5`4cc128da650b6a34641e9d22e14f8442`; SHA256`380ffde367e8b26802ca508ea426a450fc4528ac759fad4cae5dc3d0b2359ce0`.
- Research:`2833`bytes; MD5`b3642a8955cfd758850b3fcd2d2b0938`; SHA256`717af4731cc4b8eff41e81686167a612bda647ceeeffa06214a8bb252ded4c7e`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E26_B2_COMPARE_ESTABLISHING_V005_vs_V007.md](https://drive.google.com/file/d/1O40d3nLvK2ooGU61cbWJhkjUFHHIC3jq/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A comparison titled 'ESTABLISHING VIEW · ANCESTRAL REALM · V005 base -> V007 CANDIDATE', with 'BASE (unchanged source)' at left and 'CANDIDATE · REVIEW REQUIRED' at right. Detail crops show the settlement mound base and candidate and the mound foot and foreground junction. No figures are visible in either panel.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED ARCHITECTURE: the base mound's stepped form and the pillared hall are fictional proposals; no source supports them.
> - CONFLICT: the printed header says CLIENT REVIEW, CHANGED SINCE V005; status and disclaimer retained as printed.
> - NOT VERIFIED: the pixel counts are printed; this report has not recomputed them. The cited master 'ESTABLISHING V007' (pc3_bN06…) is not in the listing (F50).
> - UNVERIFIED: the 'Hall of Posts' name is a label; its use is not established.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** V007 irregular mound with far fewer/larger houses compared with V005, while hall/foreground look retained at comparison scale. Detail shows mound foot/haze and ladders; footer acknowledges Nneka not placed and flatter surfaces.

**Independent assessment:** Visible large-house/stacked form supports historical scale concern; printed441432/365251/0 counts are not independent measurements. 'Nneka not placed' is honest unresolved Requirement D, not completed integration. Different generation from D08.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [REJECTION_REPORT_ESTABLISHING_V012.md](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) — D2; full text.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) — D3; individual full image display.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Visible large-house/stacked form supports historical scale concern; printed441432/365251/0 counts are not independent measurements. 'Nneka not placed' is honest unresolved Requirement D, not completed integration. Different generation from D08.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Visible large-house/stacked form supports historical scale concern; printed441432/365251/0 counts are not independent measurements. 'Nneka not placed' is honest unresolved Requirement D, not completed integration. Different generation from D08.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve history, link exact V007/raw/rejection records if available; no approval or correction execution on old aid. Do not invent100s-house requirement from its labels.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E27 source](https://drive.google.com/file/d/1lXvNjgnJpWxAlGsRzozDYvVUrd_6gums/view) — archive`assessments/E27.md`; [E28 source](https://drive.google.com/file/d/1CWfG8a7YxBXRdC_2RB8bWwgUqwprAZ1M/view) — archive`assessments/E28.md`; [E29 source](https://drive.google.com/file/d/1kto-RyzxZFt_QgxAK_-UKFpeykFsin7H/view) — archive`assessments/E29.md`; [E31 source](https://drive.google.com/file/d/1CZbSP1PY9LBeoA65WMgmhBZhqFVlH9f6/view) — archive`assessments/E31.md`; [E32 source](https://drive.google.com/file/d/1566AiHfIYW0b03yU_R8dHZg_zoGDWsDb/view) — archive`assessments/E32.md`; [F05 source](https://drive.google.com/file/d/1Wwsibgrlr8bJevMjkRclaQ-iJ-SFgbE_/view) — archive`assessments/F05.md`; [F48 source](https://drive.google.com/file/d/1xDhCmsNgh1xGweNfqldm70AbCTw7CwuL/view) — archive`assessments/F48.md`; [F50 source](https://drive.google.com/file/d/1fNCoel_Z7KnlrMzMBUutBiJEDJ2X9nj0/view) — archive`assessments/F50.md`; [F67 source](https://drive.google.com/file/d/1sRagEJxToeZFTWy7Anx60dVonXRNvDSR/view) — archive`assessments/F67.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e27"></a>

# E27 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E27` · **Filename:** `B2_COMPARE_ESTABLISHING_V005_vs_V008.jpg`

**Source:** [1lXvNjgnJpWxAlGsRzozDYvVUrd_6gums](https://drive.google.com/file/d/1lXvNjgnJpWxAlGsRzozDYvVUrd_6gums/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ([brief](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view)) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2200×1279 JPEG; decoded modeRGB. 

- Source:`931459`bytes; MD5`6ed2698acf07f25541c457a4339ec855`; SHA256`fc718686b3f4be8885d3b7981f2b21aa31ff7cf35fcf13347d922282184768ae`.
- Research:`3110`bytes; MD5`92d8caf9eab9b0292ed45b5bd8bd322f`; SHA256`9dd723c498f0ed7f150f8161c0fd25a8031be8d3a59594dd04176289349094c5`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E27_B2_COMPARE_ESTABLISHING_V005_vs_V008.md](https://drive.google.com/file/d/1rXH4cFdGhfvdCxfi5G8ku6qOqLakbTdT/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A comparison titled 'ESTABLISHING VIEW · ANCESTRAL REALM · V005 base -> V008 CANDIDATE', with 'BASE V005 (unchanged source)' at left and 'CANDIDATE V008 · REVIEW REQUIRED' at right. Detail crops show the mound and the aerial river at the mound flank. No figures are visible in either panel.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED ARCHITECTURE: the stepped base mound and the aerial river are fictional proposals; no source supports them.
> - CONFLICT: the printed note says the mound is 'closer to V005's material weight', not identical; this report records that as printed.
> - UNVERIFIED: the printed pixel proof is not recomputed here.
> - REFERENCE ID: the cited approved reference begins 1JIoAiQ…; the register notes list 1JIoAiQ… as absent (F33–F38). Recorded, not corrected.
> - NOT DELIVERED: Nneka's House is not visible in V008 (printed).
> - Printed status: candidate only; review required; not approved, not canon, not filed.

## 05. Independent content findings

**Direct source observation:** V008 has denser/smaller dwellings than V007 aid, with softened mound flank crossing pale aerial band; foreground large gable remains. Notes expressly RequirementD not delivered/3attempts and give printed mask totals.

**Independent assessment:** Improvement direction visible; total house count, world scale, source identity and exact outside-mask claim not proved by aid. River-band/stacked mound are fictional concepts, not documented ancestor-world images. No unavailability inference from source IDs absent in PENDING.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [REJECTION_REPORT_ESTABLISHING_V012.md](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) — D2; full text.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) — D3; individual full image display.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Improvement direction visible; total house count, world scale, source identity and exact outside-mask claim not proved by aid. River-band/stacked mound are fictional concepts, not documented ancestor-world images. No unavailability inference from source IDs absent in PENDING.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Improvement direction visible; total house count, world scale, source identity and exact outside-mask claim not proved by aid. River-band/stacked mound are fictional concepts, not documented ancestor-world images. No unavailability inference from source IDs absent in PENDING.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Evidence-only preserve; carry D requirement unresolved for that generation and route owner to later D08/F40/item5. No new scale percentages, canon or production pass.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E26 source](https://drive.google.com/file/d/1A10-FlflAwN3yuI_OVpgRSPS_nl0eCk0/view) — archive`assessments/E26.md`; [E28 source](https://drive.google.com/file/d/1CWfG8a7YxBXRdC_2RB8bWwgUqwprAZ1M/view) — archive`assessments/E28.md`; [E29 source](https://drive.google.com/file/d/1kto-RyzxZFt_QgxAK_-UKFpeykFsin7H/view) — archive`assessments/E29.md`; [E31 source](https://drive.google.com/file/d/1CZbSP1PY9LBeoA65WMgmhBZhqFVlH9f6/view) — archive`assessments/E31.md`; [E32 source](https://drive.google.com/file/d/1566AiHfIYW0b03yU_R8dHZg_zoGDWsDb/view) — archive`assessments/E32.md`; [F29 source](https://drive.google.com/file/d/1aa3rlVl9mm7S-YYq80eu3mQAQhiYFPwx/view) — archive`assessments/F29.md`; [F36 source](https://drive.google.com/file/d/1QFFfLHwn1GmfGGi9oqhdzLyy8QsAqJQc/view) — archive`assessments/F36.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e28"></a>

# E28 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E28` · **Filename:** `B2_COMPARE_ESTABLISHING_V008_vs_V009.jpg`

**Source:** [1CWfG8a7YxBXRdC_2RB8bWwgUqwprAZ1M](https://drive.google.com/file/d/1CWfG8a7YxBXRdC_2RB8bWwgUqwprAZ1M/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ([brief](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view)) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2300×3599 JPEG; decoded modeRGB. 

- Source:`1785731`bytes; MD5`0d84d948bfb06352314a51c14b4079f0`; SHA256`1541858ae9419239a23fdfd2a234fd5498ab50ae803bdb1d605b4c572fd83a13`.
- Research:`3186`bytes; MD5`1c857caaa9332083a8ba03c404b1c194`; SHA256`d2b34cea704d386497b2937cfa949c3f72d8b1422ada0c9fc57a65346a3816a2`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E28_B2_COMPARE_ESTABLISHING_V008_vs_V009.md](https://drive.google.com/file/d/1mY0Y9j6WgMGxoVBzEewmmILQoBYlgfMP/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A comparison titled 'ESTABLISHING · V008 → V009 CANDIDATE'. Top: full-frame V008 (superseded, preserved) and V009 CANDIDATE — REVIEW REQUIRED, each with a small inset panel of text. Below: four detail rows labelled A (mound foot), B (lower-right mist veil), C (right compound) and D (Nneka's House and staked plot at 1:1, V009 at 2x). The mound is a stepped, pyramid-like heap with ladders; the pillared hall is at the left; a pale band crosses the sky. No figures are visible.

**Published flags (original wording, including any error reconciled below):**

> - CD RULING CITED: the 'Option A' ruling is cited on the sheet; the ruling document is not among the PENDING items reviewed here and is not verified.
> - UNSUPPORTED ARCHITECTURE: the stepped mound, the pillared hall and the open-porch house form are fictional proposals; no source supports them.
> - UNVERIFIED: the 'five Our Eyes defects' are named on the sheet only; the list is not reproduced in the image.
> - UNVERIFIED: 'Nneka's House' is a named character-owned house; its identity is not established by the image.
> - The superseded V008 is kept on the sheet for comparison; not approved by this report.

## 05. Independent content findings

**Direct source observation:** V008→V009 shows re-staged right yard with small freestanding thatched house, clothing line and short cord-linked plot stakes; detail shows warm compound/mound-foot/dust change. No person definitively identifiable.

**Independent assessment:** House/stakes are visible, but named Nneka identity/OptionA authority cannot be concluded just from label. Short stakes are plot boundary elements, not automatically figures. Restaging is clear, original PNG identity/pixel counts remain external-source checks.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [REJECTION_REPORT_ESTABLISHING_V012.md](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) — D2; full text.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) — D3; individual full image display.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

House/stakes are visible, but named Nneka identity/OptionA authority cannot be concluded just from label. Short stakes are plot boundary elements, not automatically figures. Restaging is clear, original PNG identity/pixel counts remain external-source checks.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** House/stakes are visible, but named Nneka identity/OptionA authority cannot be concluded just from label. Short stakes are plot boundary elements, not automatically figures. Restaging is clear, original PNG identity/pixel counts remain external-source checks.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve historical aid; resolve governing house reference and OptionA/history before invoking as approved reference. No changes directed to current plot stakes or architecture from similarity alone.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E26 source](https://drive.google.com/file/d/1A10-FlflAwN3yuI_OVpgRSPS_nl0eCk0/view) — archive`assessments/E26.md`; [E27 source](https://drive.google.com/file/d/1lXvNjgnJpWxAlGsRzozDYvVUrd_6gums/view) — archive`assessments/E27.md`; [E29 source](https://drive.google.com/file/d/1kto-RyzxZFt_QgxAK_-UKFpeykFsin7H/view) — archive`assessments/E29.md`; [E31 source](https://drive.google.com/file/d/1CZbSP1PY9LBeoA65WMgmhBZhqFVlH9f6/view) — archive`assessments/E31.md`; [E32 source](https://drive.google.com/file/d/1566AiHfIYW0b03yU_R8dHZg_zoGDWsDb/view) — archive`assessments/E32.md`; [F29 source](https://drive.google.com/file/d/1aa3rlVl9mm7S-YYq80eu3mQAQhiYFPwx/view) — archive`assessments/F29.md`; [F31 source](https://drive.google.com/file/d/12D8gVf8cqfSQQzghzJtr026lenc38iI9/view) — archive`assessments/F31.md`; [F37 source](https://drive.google.com/file/d/1tshnIBY20TF2dhveqYjDy0oDC29wTmfz/view) — archive`assessments/F37.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e29"></a>

# E29 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E29` · **Filename:** `B2_COMPARE_ESTABLISHING_V009_vs_V010.jpg`

**Source:** [1kto-RyzxZFt_QgxAK_-UKFpeykFsin7H](https://drive.google.com/file/d/1kto-RyzxZFt_QgxAK_-UKFpeykFsin7H/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ([brief](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view)) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2300×3493 JPEG; decoded modeRGB. 

- Source:`1907538`bytes; MD5`cd427cbe33686b748c832a66c95e5edc`; SHA256`2606a90e9cc7f730f824c4d128270828314b8322071633b735d992f1b90228d0`.
- Research:`2793`bytes; MD5`a26d8ada7290c4bc7d3bc35351c0a346`; SHA256`e0924e0736e3c7a12b790f6230c6253b43700630b7d181e3a3a60eb7ccadc61e`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E29_B2_COMPARE_ESTABLISHING_V009_vs_V010.md](https://drive.google.com/file/d/1RfXU2ngH8wiNNaIzRYo0uD_22A1vqwQY/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A comparison titled 'ESTABLISHING · V009 → V010 CANDIDATE'. Top: full-frame V009 (superseded, preserved) and V010 CANDIDATE — REVIEW REQUIRED. Below: four detail rows: A (hill, dwellings smaller and more numerous, same outline), B (hill foot, scale against the plain village), C (right compound, marked unchanged, 0 px) and D (hill at 1:1 on V010, 2x). The mound is a dense, stepped heap of houses with ladders; the pillared hall is at the left. No figures are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED ARCHITECTURE: the stepped mound, the pillared hall and the terraced hill form are fictional proposals; no source supports them.
> - UNVERIFIED: the printed percentages ('about 30%', 'about twice as many') are not measured here.
> - UNVERIFIED: the printed claim that 0 px changed outside the mound is not recomputed here.
> - Superseded V009 preserved for comparison; V010 is a candidate only and is not approved by this report.

## 05. Independent content findings

**Direct source observation:** V009→V010 mound has visually more small dwellings, same broad outline and right yard thumbnail; enlarged hill crop and printed30%/2x claims. Actual hierarchy still dense layered houses.

**Independent assessment:** Qualitative density change seen; percentages and zero outside-mound statistics unverified here. Same broad silhouette does not establish scale-match to foreground or mandatory basal-hut completion. Later V013 retains open item5.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [REJECTION_REPORT_ESTABLISHING_V012.md](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) — D2; full text.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) — D3; individual full image display.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Qualitative density change seen; percentages and zero outside-mound statistics unverified here. Same broad silhouette does not establish scale-match to foreground or mandatory basal-hut completion. Later V013 retains open item5.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Qualitative density change seen; percentages and zero outside-mound statistics unverified here. Same broad silhouette does not establish scale-match to foreground or mandatory basal-hut completion. Later V013 retains open item5.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain as historical scale-method aid, not approved numeric target or D08 clearance. Exact raw pair required for reproducing original audit; owner must specify/waive current mandatory scale issue explicitly.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E26 source](https://drive.google.com/file/d/1A10-FlflAwN3yuI_OVpgRSPS_nl0eCk0/view) — archive`assessments/E26.md`; [E27 source](https://drive.google.com/file/d/1lXvNjgnJpWxAlGsRzozDYvVUrd_6gums/view) — archive`assessments/E27.md`; [E28 source](https://drive.google.com/file/d/1CWfG8a7YxBXRdC_2RB8bWwgUqwprAZ1M/view) — archive`assessments/E28.md`; [E31 source](https://drive.google.com/file/d/1CZbSP1PY9LBeoA65WMgmhBZhqFVlH9f6/view) — archive`assessments/E31.md`; [E32 source](https://drive.google.com/file/d/1566AiHfIYW0b03yU_R8dHZg_zoGDWsDb/view) — archive`assessments/E32.md`; [F32 source](https://drive.google.com/file/d/1h_s2Zaw5lCgn1ewptkbze4LJsoalrm-4/view) — archive`assessments/F32.md`; [F38 source](https://drive.google.com/file/d/1WLiqPhYiU6DVsFZaFvOge-0DH89uh-Mr/view) — archive`assessments/F38.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e30"></a>

# E30 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E30` · **Filename:** `B2_COMPARE_ESTABLISHING_V010_vs_V011_CHROME.jpg`

**Source:** [1LMwXIN3whaxctH9BQ9xJS9tEVIT6-mtj](https://drive.google.com/file/d/1LMwXIN3whaxctH9BQ9xJS9tEVIT6-mtj/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ([brief](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view)) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1200×660 JPEG; decoded modeRGB. 

- Source:`136059`bytes; MD5`d7b7645c2059eba26253ab74ff606503`; SHA256`2a95fb90ff79919a6e8becf3ba20416716e301b587af16b75468efebbb7ff197`.
- Research:`3328`bytes; MD5`3bf8ebfacbddb73dba5f1e2c4aa839c7`; SHA256`18983c5940d6907153da6dd339ccd91f92a7a249a9a31789cbe51c8465deec74`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E30_B2_COMPARE_ESTABLISHING_V010_vs_V011_CHROME.md](https://drive.google.com/file/d/1XiTIbQu4YMRSYVQYnUoyaWy4-kVwx_8g/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A text-only sheet of stacked review-block and footer panels, with no artwork. Items, top to bottom: 'CLIENT REVIEW BLOCK — V010 (stale round label presented as a client ruling)' showing 'CH08-SUB-001 · CLIENT REVIEW · REVISE. Tenth. Hill dwellings re-scaled to the plain; the right-hand compound is unchanged' with a READ button; 'V011 — PENDING, honest population' showing 'CH08-SUB-001 · CLIENT REVIEW · PENDING. No client ruling is recorded on this version; it is a candidate only' with a READ button; a V010 footer ('no version register') and a V011 footer ('version register added'), each with a swatch #DCC3AA and a disclaimer; and a closing line 'Panel pixels: 0 changed (verified). Chrome: 8,046 px. Panel, camera, colours and all content untouched.'

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT: the V010 block is titled 'stale round label presented as a client ruling', yet it reads as a client ruling; the sheet itself flags it. Recorded as printed, not resolved.
> - UNVERIFIED: the 'Tenth' revision count and the chapter label 'CH08-SUB-001' are printed; not checked against any register here.
> - NOTE: the footer text is cut off at the right edge.
> - The 'figureless by client decision' phrase is printed; this report does not verify the decision.

## 05. Independent content findings

**Direct source observation:** No scene artwork: V010 stale REVISE/Tenth CLIENT REVIEW block above V011 PENDING/no ruling block, plus footer/version-register examples and printed0panel/8046chrome px. Some footer prose cut at right edge.

**Independent assessment:** Honest current-status wording is a correction relative to misleading prior client-ruling field. It does not prove panel equality or any actual CD verdict. Research properly recognises text-only image; stale quote is expressly labelled stale, not new contradiction to adopt.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [REJECTION_REPORT_ESTABLISHING_V012.md](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) — D2; full text.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) — D3; individual full image display.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Honest current-status wording is a correction relative to misleading prior client-ruling field. It does not prove panel equality or any actual CD verdict. Research properly recognises text-only image; stale quote is expressly labelled stale, not new contradiction to adopt.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Honest current-status wording is a correction relative to misleading prior client-ruling field. It does not prove panel equality or any actual CD verdict. Research properly recognises text-only image; stale quote is expressly labelled stale, not new contradiction to adopt.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve chrome audit evidence. Do not regenerate or reapprove art from it. Any new operational sheet must use accurate PENDING/no ruling language and wrapped complete footer under style-guide exact-typeset requirement; historical aid untouched.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F06 source](https://drive.google.com/file/d/1hoh64TdMya1jCslKC_xGARuvsDfHlPOo/view) — archive`assessments/F06.md`; [F10 source](https://drive.google.com/file/d/1epIa9TkphMfiZgNLnySH5vDwkpJXJ-bs/view) — archive`assessments/F10.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e31"></a>

# E31 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E31` · **Filename:** `B2_COMPARE_ESTABLISHING_V011_vs_V012.jpg`

**Source:** [1CZbSP1PY9LBeoA65WMgmhBZhqFVlH9f6](https://drive.google.com/file/d/1CZbSP1PY9LBeoA65WMgmhBZhqFVlH9f6/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ([brief](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view)) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2300×3560 JPEG; decoded modeRGB. 

- Source:`1413487`bytes; MD5`c1d7052eb47e055eee1d164f4032c487`; SHA256`24be9f6fbe4abf638d00f8d51905af3250d791a4d0da43876faf7d6d49098dba`.
- Research:`3576`bytes; MD5`13de115596c0fe044554302d472f299a`; SHA256`49a8f5eef2fdd7acab5c3a26e0ed51f88511f5b0c30816881845052e9507bcbf`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E31_B2_COMPARE_ESTABLISHING_V011_vs_V012.md](https://drive.google.com/file/d/10XYuNUzqqt6qQ5Mtggt-13Xd3rlfvhXc/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A comparison titled 'ESTABLISHING · V011 → V012 CANDIDATE'. Header text (printed): 'Executing the eight-point brief in REJECTION_REPORT_ESTABLISHING_V009. Four zones corrected, summit scale carried, chrome rebuilt. Item 1 (house scale) not attempted — stated, not hidden.' Top: V011 (superseded, preserved) and V012 CANDIDATE — REVIEW REQUIRED. Below: rows A (the yard), B (wall behind the paling), C (lower-right wall) and D (cloth line at 1:1, V012 at 2x). Each row shows V011 at left and V012 at right. The yard shows a thatched house, a cloth line with pale and striped cloths, short stakes and cord. Lower text lists items 2 and 3 and is cut off at the bottom edge.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN IMAGE: the A row is printed as 'paling gone'; in the V012 panel short stakes and cord still appear in the lower centre of the yard. Not confirmed at this resolution; recorded, not corrected.
> - PRINTED GAP: 'Item 1 (house scale) not attempted — stated, not hidden.' The house scale is therefore not corrected in this candidate.
> - UNVERIFIED: the 'eight-point brief' and the rejection report 'REJECTION_REPORT_ESTABLISHING_V009' are named; neither is among the items reviewed here.
> - GENERATIVE PATCH: printed as used in B and in item 3; the generated pixels are not separable by this report.
> - UNSUPPORTED ARCHITECTURE: the thatched house and yard are fictional proposals; no source supports them.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** V011→V012 yard crops: fence of close vertical planks immediately beside house is gone in right-hand rowB. Separate low cord-linked PLOT STAKES remain across yard. Cloth-line longer/restored, house still same broad size; corner wall retone subtle.

**Independent assessment:** Research's possible 'paling gone but stakes remain' conflict conflates TWO different objects. Palings beside house visibly removed; retained plot stakes do not refute that. Item1 house scale expressly not attempted, no full completion. Original pixel/measured claims not independently reproduced.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [REJECTION_REPORT_ESTABLISHING_V012.md](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) — D2; full text.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) — D3; individual full image display.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Research's possible 'paling gone but stakes remain' conflict conflates TWO different objects. Palings beside house visibly removed; retained plot stakes do not refute that. Item1 house scale expressly not attempted, no full completion. Original pixel/measured claims not independently reproduced.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Research's possible 'paling gone but stakes remain' conflict conflates TWO different objects. Palings beside house visibly removed; retained plot stakes do not refute that. Item1 house scale expressly not attempted, no full completion. Original pixel/measured claims not independently reproduced.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve aid and distinguish removed house-side plank paling from retained staked plot in issue register. Do not remove legitimate plot stakes to satisfy a false conflict; no new generation. Link later V013 house-scale evidence and remaining basal-hut hold.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E26 source](https://drive.google.com/file/d/1A10-FlflAwN3yuI_OVpgRSPS_nl0eCk0/view) — archive`assessments/E26.md`; [E27 source](https://drive.google.com/file/d/1lXvNjgnJpWxAlGsRzozDYvVUrd_6gums/view) — archive`assessments/E27.md`; [E28 source](https://drive.google.com/file/d/1CWfG8a7YxBXRdC_2RB8bWwgUqwprAZ1M/view) — archive`assessments/E28.md`; [E29 source](https://drive.google.com/file/d/1kto-RyzxZFt_QgxAK_-UKFpeykFsin7H/view) — archive`assessments/E29.md`; [E32 source](https://drive.google.com/file/d/1566AiHfIYW0b03yU_R8dHZg_zoGDWsDb/view) — archive`assessments/E32.md`; [F14 source](https://drive.google.com/file/d/1kyG28U9QT6meBdGpDxN0JDpYt20AdOYZ/view) — archive`assessments/F14.md`; [F37 source](https://drive.google.com/file/d/1tshnIBY20TF2dhveqYjDy0oDC29wTmfz/view) — archive`assessments/F37.md`; [F39 source](https://drive.google.com/file/d/12gTdtxR76qB_5916pRV_R1p1xK0cl9w3/view) — archive`assessments/F39.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e32"></a>

# E32 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E32` · **Filename:** `B2_COMPARE_ESTABLISHING_V012_vs_V013.jpg`

**Source:** [1566AiHfIYW0b03yU_R8dHZg_zoGDWsDb](https://drive.google.com/file/d/1566AiHfIYW0b03yU_R8dHZg_zoGDWsDb/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Ancestral Establishing remains exploratory/fictional. The exact V012 rejection brief ([brief](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view)) requires six V013 items; current standing CD expressly retains HOLD for mandatory item5. V005 is current-best/in-review, not generally approved; NnekaV004 design approval does not establish story canon.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2118×2456 JPEG; decoded modeRGB. 

- Source:`935882`bytes; MD5`a4d954d2e931f7649482968395f487d8`; SHA256`835a805ed5b5d72f9fd72b17a7df5bb94bc2b54152df4e1a57ff1cbf50723942`.
- Research:`3400`bytes; MD5`d56dba27c66f16aa08f089e53b647008`; SHA256`8c268f995f3a6d164e6497803875bdc4d37671f169fbbdbfb912624b391c0f2a`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E32_B2_COMPARE_ESTABLISHING_V012_vs_V013.md](https://drive.google.com/file/d/115EoA3ieGcDBho9p8yh7JNPK4yHl6osb/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A diagnostic comparison titled 'ESTABLISHING VIEW — V012 vs V013'. Subtitle (printed): 'Candidate V013, unapproved; nothing here implies approval. Approved V005 base preserved untouched. V006 – V012 preserved in 16_REJECTED_DESIGNS.' Rows: A (frame margin and lower-right wall), B (cloth line, right end) and C (Nneka's house in the compound), each showing V012 at left and V013 at right. A printed block lists measured values from the files. No figures are visible.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN STATUS: the subtitle calls V005 'approved', while the V005 comparison sheets (E25–E27) print 'REVIEW REQUIRED' and 'EXPLORATORY — NOT APPROVED CANON'. Recorded as printed; not resolved.
> - UNVERIFIED: 'approved side cloth' is printed; the approval record is not among the items reviewed here.
> - UNVERIFIED: the printed RGB and pixel-height values are not recomputed here.
> - NOT FIXED (printed): basal hill huts not re-proportioned; no measurable target was given for hut size.
> - UNSUPPORTED ARCHITECTURE: the compound, house and hill are fictional proposals.
> - Diagnostic only; V013 is not approved by this report.

## 05. Independent content findings

**Direct source observation:** Native-ish comparison crops show margin warmer/darker in V013, cloth edge and striped side cloth visible, smaller house/greater yard. A pale rectangular repeated-background-looking patch remains above cloth at right of rowB, origin undetermined. Plotted yard stakes retained. Footer states basal huts uncorrected.

**Independent assessment:** Direction of house-size/cloth changes visible, 15% and RGB still printed until raw reference checks. 'Approved V005' wording exceeds earlier REVIEW REQUIRED source labels unless distinct limited authority resolved; keep status claim qualified. Mandatory item5 not fixed or waived. Patch warrants marked evidence, not invented figure diagnosis.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [REJECTION_REPORT_ESTABLISHING_V012.md](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) — D2; full text.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) — D3; individual full image display.
- [ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Direction of house-size/cloth changes visible, 15% and RGB still printed until raw reference checks. 'Approved V005' wording exceeds earlier REVIEW REQUIRED source labels unless distinct limited authority resolved; keep status claim qualified. Mandatory item5 not fixed or waived. Patch warrants marked evidence, not invented figure diagnosis.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Direction of house-size/cloth changes visible, 15% and RGB still printed until raw reference checks. 'Approved V005' wording exceeds earlier REVIEW REQUIRED source labels unless distinct limited authority resolved; keep status claim qualified. Mandatory item5 not fixed or waived. Patch warrants marked evidence, not invented figure diagnosis.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve diagnostic; HOLD current D08 for verifieditem5completion or explicitCDwaiver. Ask owner for reference/specific measured target and marked patch decision if material; no imposed size/house count and no automatic patch/regeneration.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E26 source](https://drive.google.com/file/d/1A10-FlflAwN3yuI_OVpgRSPS_nl0eCk0/view) — archive`assessments/E26.md`; [E27 source](https://drive.google.com/file/d/1lXvNjgnJpWxAlGsRzozDYvVUrd_6gums/view) — archive`assessments/E27.md`; [E28 source](https://drive.google.com/file/d/1CWfG8a7YxBXRdC_2RB8bWwgUqwprAZ1M/view) — archive`assessments/E28.md`; [E29 source](https://drive.google.com/file/d/1kto-RyzxZFt_QgxAK_-UKFpeykFsin7H/view) — archive`assessments/E29.md`; [E31 source](https://drive.google.com/file/d/1CZbSP1PY9LBeoA65WMgmhBZhqFVlH9f6/view) — archive`assessments/E31.md`; [F14 source](https://drive.google.com/file/d/1kyG28U9QT6meBdGpDxN0JDpYt20AdOYZ/view) — archive`assessments/F14.md`; [F39 source](https://drive.google.com/file/d/12gTdtxR76qB_5916pRV_R1p1xK0cl9w3/view) — archive`assessments/F39.md`; [F40 source](https://drive.google.com/file/d/1XTPF-QmHfQ16e8oOVTGNOHT0ojuJ11Wu/view) — archive`assessments/F40.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e33"></a>

# E33 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E33` · **Filename:** `B2_COMPARE_VR-008.jpg`

**Source:** [1oGedLDNFIWEa2rQybWpIdY0NuEtKQ7pX](https://drive.google.com/file/d/1oGedLDNFIWEa2rQybWpIdY0NuEtKQ7pX/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Historical VR-008 correction evidence must be read by exact generation and method. Current V009 stays unchanged, exploratory composition only, never14_APPROVED_DESIGNS, with noV010 for four logged chrome errata. CQ-9/RQ-10-1/U-11 qualifications remain.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1940×734 JPEG; decoded modeRGB. 

- Source:`422578`bytes; MD5`b8e293546275eee5967595cc68528f38`; SHA256`5ad83dbff46f0579fc9bf5b9016d09d0ab62f440bc88932df367a9b0d172a19e`.
- Research:`3413`bytes; MD5`cdda99d2492867b0153ceb7be785ff4a`; SHA256`6411bda7ff20fe7c08dc36bed7c41f41023d251a3f64757435893e4dedfbf6ce`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E33_B2_COMPARE_VR-008.md](https://drive.google.com/file/d/1bUMpgc8cfn6FMNaDhKJQ3IOQH6qN4gs6/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A comparison titled 'VR-008 COMP_ADANNA_SEALED_QUARTER_HAND_ON_SEAL — V005 (REVIEW REQUIRED) -> V006 CANDIDATE (REVIEW REQUIRED)'. ORIGINAL: V005 master, 2560x1440; CANDIDATE: V006, 2560x1440. A standing female figure in a navy top and wrap, with braids, a metal shoulder plate, and her hand flat on a plaster door panel in a mud-walled alley. A clay bowl with red contents and a pot stand at the left foreground; thatch and stacked timber are at the right. Both panels are nearly identical; the crack in the door panel differs.

**Published flags (original wording, including any error reconciled below):**

> - CQ-9 OPEN: the hilted object at the hip is visible; blade and scabbard construction is open and is NOT cleared by this report.
> - UNVERIFIED: the printed 'exactly 0' pixel diff is not recomputed here.
> - REGISTER NOTE: the register notes record VR-008 V006 as rejected; this sheet names V006 as a candidate. Recorded, not corrected.
> - UNSUPPORTED: the pauldron and the sealed-quarter setting are fictional proposals; no source is cited for the mud-wall construction.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Sealed-quarter V005/V006: figure with metallic shoulder cap and covered midriff, hand on sealed plaster door, bowl/pot; fracture stronger in candidate. Caption hand-retouch/no-generative, too-strong-fracture residual.

**Independent assessment:** Crack change visible; no guarantee target hides other inherited identity/pauldron/midriff issues. This is old V006, not preserved exploratory-only V009. Cannot use old candidate status as current approval or reopen after later steps by chronology confusion.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Crack change visible; no guarantee target hides other inherited identity/pauldron/midriff issues. This is old V006, not preserved exploratory-only V009. Cannot use old candidate status as current approval or reopen after later steps by chronology confusion.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Crack change visible; no guarantee target hides other inherited identity/pauldron/midriff issues. This is old V006, not preserved exploratory-only V009. Cannot use old candidate status as current approval or reopen after later steps by chronology confusion.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain history only; no resurrection/retouch direction. Current VR008V009 remains unchanged/exploratory-only/never14_APPROVED and noV010 for chrome errata. CQ9open despite inherited hilt.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F02 source](https://drive.google.com/file/d/1U4xF6NUFrVnSEW3ljz5_FBUWOYMOsZYD/view) — archive`assessments/F02.md`; [F46 source](https://drive.google.com/file/d/1DbUGmu9tmbdKoTmmBBIJ0PgIelRY_icd/view) — archive`assessments/F46.md`; [F47 source](https://drive.google.com/file/d/1xPD33CTWybukTy10WP5TLN9k6XK3fkFy/view) — archive`assessments/F47.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e34"></a>

# E34 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E34` · **Filename:** `B2_COMPARE_VR-008_V005_to_V008_with_references.jpg`

**Source:** [1FSpdjZBhXqzaRXBDt8WzB_HFxdAVjnJk](https://drive.google.com/file/d/1FSpdjZBhXqzaRXBDt8WzB_HFxdAVjnJk/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Historical VR-008 correction evidence must be read by exact generation and method. Current V009 stays unchanged, exploratory composition only, never14_APPROVED_DESIGNS, with noV010 for four logged chrome errata. CQ-9/RQ-10-1/U-11 qualifications remain.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2400×1370 JPEG; decoded modeRGB. 

- Source:`730009`bytes; MD5`cdf09d5f7bf0ee321c971db371516c61`; SHA256`4da4189d4af891e874d15f83d47b9f22862c6c3d9a21a5a049644fddccf97c25`.
- Research:`4311`bytes; MD5`388f030a634f210e3f15b090cf3d2933`; SHA256`b04387e9e5b5954186268d89b085fee853c29f09eb82394437a3a5c37714bf4a`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E34_B2_COMPARE_VR-008_V005_to_V008_with_references.md](https://drive.google.com/file/d/1Jus4LhYzxRYIe8rApONG3F0mrfXL0Iz5/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'VR-008 COMP_ADANNA_SEALED_QUARTER_HAND_ON_SEAL — V005 base -> V008 CANDIDATE'. Top: full-frame BASE V005 master (handover branch, unchanged) and CANDIDATE V008 · REVIEW REQUIRED. A standing female figure in a navy top and wrap, braids and a metal shoulder plate, her right hand flat on a plaster door panel in a mud-walled alley; a clay bowl and pot stand at the left. Below: three defect rows: DEFECT B (bare midriff: V004 reference and V008 restored), DEFECT C (armlet: CHAR master portrait, V007 painted, V008 transferred) and DEFECT A (fracture: V005 and V008). Lower text lists defects A–D, pixel proof and status.

**Published flags (original wording, including any error reconciled below):**

> - CQ-9 OPEN: the hilted object at the hip is visible; the blade and scabbard are not cleared by this report.
> - CONFLICT IN METHOD: this sheet says 'hand retouch only, no generative pass', but the armlet is a transferred patch from a master portrait; the master is cited but is not in the registers (not verified here).
> - CONFLICT IN STATUS: this sheet calls V008 a CANDIDATE; the VR-008 V009 sheet (E36) calls V008 'rejected, preserved'. Recorded, not resolved.
> - UNVERIFIED: the pixel counts, the 0.805 correlation and the 7.6° rotation are printed; not recomputed here.
> - UNVERIFIED: the armlet's identity as the 'approved' coil pattern is not established by the image.
> - REGISTER NOTE: the register notes record VR-008 V006 as rejected; this sheet refers to V006 as the rejected design. Recorded, not corrected.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** V005→V008 top pair plus detail crops: V008 bare-midriff patch, fine coil band transferred-looking versus broad painted V007 band, reference armlet crop, branched plaster fracture. Metal shoulder cap still present.

**Independent assessment:** Directly supports author erratum: master portrait has usable coil patch. Hand retouch including a transferred crop is NOT a method conflict; neither is rejected-later versus candidate-then a status conflict. Source-master now resolved independently. V008's pauldron remains historical later-fixed defect.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Directly supports author erratum: master portrait has usable coil patch. Hand retouch including a transferred crop is NOT a method conflict; neither is rejected-later versus candidate-then a status conflict. Source-master now resolved independently. V008's pauldron remains historical later-fixed defect.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Directly supports author erratum: master portrait has usable coil patch. Hand retouch including a transferred crop is NOT a method conflict; neither is rejected-later versus candidate-then a status conflict. Source-master now resolved independently. V008's pauldron remains historical later-fixed defect.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain evidence, correct interpretation in assessment not by overwriting Research/aids. No canon/weapon authority from inherited weapon; no changes to currentV009.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F04 source](https://drive.google.com/file/d/1fEhvp7x5KK4j8XxxkGmbXk-KTNXSQU3e/view) — archive`assessments/F04.md`; [F07 source](https://drive.google.com/file/d/12WJLRjnQ6IJoMsYigJMQYN7Boy_wEuSo/view) — archive`assessments/F07.md`; [F41 source](https://drive.google.com/file/d/1vqo8RMnVh1UQZNREGwBPFPcIHX88OmDl/view) — archive`assessments/F41.md`; [F49 source](https://drive.google.com/file/d/1mODNxtojxzg8UHjSBuRiXMsKRfYAQofw/view) — archive`assessments/F49.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e35"></a>

# E35 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E35` · **Filename:** `B2_COMPARE_VR-008_V005_vs_V007.jpg`

**Source:** [1aENkNhoAZJewZD6GR1cniUtRnqR_0ctf](https://drive.google.com/file/d/1aENkNhoAZJewZD6GR1cniUtRnqR_0ctf/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Historical VR-008 correction evidence must be read by exact generation and method. Current V009 stays unchanged, exploratory composition only, never14_APPROVED_DESIGNS, with noV010 for four logged chrome errata. CQ-9/RQ-10-1/U-11 qualifications remain.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2400×1345 JPEG; decoded modeRGB. 

- Source:`765180`bytes; MD5`ad788e8f6c871f3e99104fc467e950d1`; SHA256`f6bccf2b98a5bcb4962a24c85e6284a9788690e768f285e07d8403523000b79b`.
- Research:`3612`bytes; MD5`9ad851688420068fec974bf1c50e29a0`; SHA256`722e641b84184cd03c399ce8eb90c86e5131923469c65eb855288199e365cf5b`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E35_B2_COMPARE_VR-008_V005_vs_V007.md](https://drive.google.com/file/d/1Twp5RgTHVyl-8S_MmDj0gv-00RQC8Gj-/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'VR-008 COMP_ADANNA_SEALED_QUARTER_HAND_ON_SEAL V005 (REVIEW REQUIRED) -> V007 CANDIDATE (REVIEW REQUIRED)'. Subtitle (printed): 'Rejection of V006 answered by targeted retouch on the V005 master panel. No generative pass. 0 changed pixels outside the three edit masks.' Top: BEFORE V005 panel (unchanged) and AFTER V007 panel. The figure is the same as E34: standing, braids, metal shoulder plate, hand on the door panel, with a clay bowl and pot at the left. Rows: MIDRIFF (bare midriff restored), LEFT UPPER ARM (armlet) and FRACTURE (crack replaced), each V005 | V007.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN SOURCE: this sheet says the armlet is a painted reconstruction with no approved reference to transfer; E34 (V008) says the armlet is transferred from CHAR_ADANNA_MASTER_REFERENCE_V001. Recorded, not resolved.
> - CQ-9 OPEN: the hilted object at the hip; blade and scabbard not cleared.
> - UNVERIFIED: 'approved short indigo wrap hem' is printed; the approval record is not among the items reviewed here.
> - UNVERIFIED: pixel counts and the correlation are printed; not recomputed here.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** V007 after panel has bare midriff, conspicuous broad five-band-looking armlet below metallic shoulder cap, stronger branched fracture; detailed before/after regions and no-transfer limitation printed.

**Independent assessment:** V007 painted coil visibly unlike finer reference portrait band in E34; author limitation subsequently retracted. This is a corrected historical false claim, not unresolved absence of a master now. Printed0pixels metrics unverified.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

V007 painted coil visibly unlike finer reference portrait band in E34; author limitation subsequently retracted. This is a corrected historical false claim, not unresolved absence of a master now. Printed0pixels metrics unverified.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** V007 painted coil visibly unlike finer reference portrait band in E34; author limitation subsequently retracted. This is a corrected historical false claim, not unresolved absence of a master now. Printed0pixels metrics unverified.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Keep historical source/error record; don't adopt painted band as approved coil standard or reopen preservedBACK/LEFTSIDE. CurrentV009 noV010/noapprovedfolder rule remains.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E36 source](https://drive.google.com/file/d/1JCpUGC37IkeiokNd77cP6I75k5l7tET4/view) — archive`assessments/E36.md`; [F03 source](https://drive.google.com/file/d/1WlPZ0g2zcQPvdGXna-xGfm6XTSf9MbCB/view) — archive`assessments/F03.md`; [F07 source](https://drive.google.com/file/d/12WJLRjnQ6IJoMsYigJMQYN7Boy_wEuSo/view) — archive`assessments/F07.md`; [F41 source](https://drive.google.com/file/d/1vqo8RMnVh1UQZNREGwBPFPcIHX88OmDl/view) — archive`assessments/F41.md`; [F48 source](https://drive.google.com/file/d/1xDhCmsNgh1xGweNfqldm70AbCTw7CwuL/view) — archive`assessments/F48.md`; [F49 source](https://drive.google.com/file/d/1mODNxtojxzg8UHjSBuRiXMsKRfYAQofw/view) — archive`assessments/F49.md`; [F52 source](https://drive.google.com/file/d/1u_ey_gPxdTM5862Bw_3cfhm3NMcETMxL/view) — archive`assessments/F52.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e36"></a>

# E36 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E36` · **Filename:** `B2_COMPARE_VR-008_V008_vs_V009.jpg`

**Source:** [1JCpUGC37IkeiokNd77cP6I75k5l7tET4](https://drive.google.com/file/d/1JCpUGC37IkeiokNd77cP6I75k5l7tET4/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Historical VR-008 correction evidence must be read by exact generation and method. Current V009 stays unchanged, exploratory composition only, never14_APPROVED_DESIGNS, with noV010 for four logged chrome errata. CQ-9/RQ-10-1/U-11 qualifications remain.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2100×3079 JPEG; decoded modeRGB. 

- Source:`967026`bytes; MD5`7f5fbc9b9f31ec4ffb0998403158d7c7`; SHA256`73bde30ac9be84c89df5655a00b8d519d87b321ea214b19bf532a60b9890297a`.
- Research:`3961`bytes; MD5`ada09608e26fe82562a63c8decd7145a`; SHA256`a920917117c6960103856055337c4d4266458838d009b8aaa6b190287707e0b5`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E36_B2_COMPARE_VR-008_V008_vs_V009.md](https://drive.google.com/file/d/1EHR2jl3_QZfaExd7NrIO_QFvzSQLzH2M/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'VR-008 SEALED QUARTER · V008 -> V009 CANDIDATE'. Subtitle (printed): 'Answers REJECTION_REPORT_VR-008_SEALED_QUARTER_V008: the unapproved metal pauldron is removed and the bare shoulder with the plain leather strap restored per OAD-02; stale V004 chrome replaced. Environment untouched.' Top: COMPOSITION — ADANNA'S HAND ON A CRACKED SEAL · WIDE, V008 (rejected, preserved) and V009 CANDIDATE — REVIEW REQUIRED, each with a small inset text panel. Rows: A (left shoulder: bronze pauldron -> bare shoulder, plain leather strap), B (coiled bronze armlet, preserved in place at 2x) and C (sheet chrome: stale V004 comparison language replaced). Lower text lists items 1–3, audit and status.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN METHOD: this sheet says the pauldron was removed by a generative retouch; E34 and E35 say 'hand retouch only, no generative pass'. Recorded, not resolved.
> - CONFLICT IN STATUS: this sheet labels V008 'rejected, preserved'; E34 labels V008 'CANDIDATE'. Recorded, not resolved.
> - UNVERIFIED: 'exactly as CHAR_ADANNA_MASTER_REFERENCE_V001 (OAD-02) specifies' is printed; the master is not in the registers and is not checked here.
> - UNVERIFIED: the 'RQ-10-1 open, U-11 open' references are printed; the register IDs are not checked here.
> - CQ-9 OPEN: the blade reference (WEAPON_ADANNA_PRIMARY_BLADE_V001) is named in sources; blade construction is not cleared by this report.
> - PROVENANCE: the sheet states that V006–V008 are preserved in 16_REJECTED_DESIGNS; not checked here.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** V008 metallic shoulder cap replaced with bare skin and plain brown strap in V009; coil band remains in place, hand/seal scene looks same at thumbnail scale. Lower chrome excerpts partly clipped.

**Independent assessment:** Pauldron-removal outcome directly visible. New shoulder generative patch does NOT contradict earlier versions' non-generative crack/midriff/armlet method; different edit/version. V008 rejected later is legitimate chronology. Aid cannot regrant/revoke underlyingV009 limited exploratory outcome or prove0environmentpx.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Pauldron-removal outcome directly visible. New shoulder generative patch does NOT contradict earlier versions' non-generative crack/midriff/armlet method; different edit/version. V008 rejected later is legitimate chronology. Aid cannot regrant/revoke underlyingV009 limited exploratory outcome or prove0environmentpx.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Pauldron-removal outcome directly visible. New shoulder generative patch does NOT contradict earlier versions' non-generative crack/midriff/armlet method; different edit/version. V008 rejected later is legitimate chronology. Aid cannot regrant/revoke underlyingV009 limited exploratory outcome or prove0environmentpx.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve comparison and currentV009 unchanged, exploratory-only/never14_APPROVED/noV010 for4chromeerrata. No new anatomy/weapon/chirality correction from this aid. Link exact source and historical limited verdict.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E35 source](https://drive.google.com/file/d/1aENkNhoAZJewZD6GR1cniUtRnqR_0ctf/view) — archive`assessments/E35.md`; [F04 source](https://drive.google.com/file/d/1fEhvp7x5KK4j8XxxkGmbXk-KTNXSQU3e/view) — archive`assessments/F04.md`; [F07 source](https://drive.google.com/file/d/12WJLRjnQ6IJoMsYigJMQYN7Boy_wEuSo/view) — archive`assessments/F07.md`; [F12 source](https://drive.google.com/file/d/1QUoYd7yCFGsD9pPrSm7tRSPccHs-R0So/view) — archive`assessments/F12.md`; [F42 source](https://drive.google.com/file/d/1lAESDSpwgtLNr4rjc2RKDEJ4WDU4--lU/view) — archive`assessments/F42.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e37"></a>

# E37 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E37` · **Filename:** `B2_COMPARE_VR-010.jpg`

**Source:** [1v_Sls4vJNSVZHF5XV-RHEM-PQ2c9ImmV](https://drive.google.com/file/d/1v_Sls4vJNSVZHF5XV-RHEM-PQ2c9ImmV/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Washing-place steps are domestic/exploratory history. Actual later CD decision accepts flush-grade runoff/off-frame outlet; U-27 domestic-only qualification remains. No engineering performance or ritual/cultural clearance follows from a plausible picture.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1940×734 JPEG; decoded modeRGB. 

- Source:`510497`bytes; MD5`665fd425d0b6fb7bd1cd5436bf27b34b`; SHA256`ec24c897679ecf42396d8f8045815954c778d57a16a221b7b0d6bbabdfc37559`.
- Research:`3049`bytes; MD5`13d4ae67241850986ee405e3228c6308`; SHA256`e4fa0c6e095e0c4f3b1309ae87719b1cb299d0d029ca542e38d16d76fbca29da`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E37_B2_COMPARE_VR-010.md](https://drive.google.com/file/d/1eGOURsbdQC4PBjvtj_A3v5XBPyI8jnNZ/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'VR-010 ENV_HOME_SETTLEMENT_WASHING_PLACE — V002 (REVIEW REQUIRED) -> V003 CANDIDATE (REVIEW REQUIRED)'. ORIGINAL: V002 master, 2560x1440; CANDIDATE: V003, 2560x1440. A small washing corner: a red mud wall at the left; a woven palm-frond screen behind; upright posts; a towel on the screen; a large clay pot with a wooden dipper, a smaller pot, a flat stone slab, a leaf with soap, chewing sticks, a sponge and straw. In V002 a bright wet channel crosses the yard to the right of the slab; in V003 the channel is replaced by a stone-lined opening cut into the ground at the lower left of the pot.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED ARCHITECTURE: the stone-lined culvert mouth and the wall-foot opening are fictional proposals; no source supports them.
> - UNVERIFIED: the printed 'diff 0' outside the panel is not recomputed here.
> - UNVERIFIED: the printed 'secondary drift' is a claim about the candidate; the exact changes are not measured here.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Washing-place V002 open bright runoff versus V003 stone-edged recess/culvert-like hole under/left of main pot; slab/pots/screen weave/light shift in candidate. Generic props persist.

**Independent assessment:** Recess and drift visible in this olderstep. Historical correction evidence, not currentV005. Recess form not culturally authenticated; does not mean all drains forbidden (SCN021 register includes drain).

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Recess and drift visible in this olderstep. Historical correction evidence, not currentV005. Recess form not culturally authenticated; does not mean all drains forbidden (SCN021 register includes drain).

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Recess and drift visible in this olderstep. Historical correction evidence, not currentV005. Recess form not culturally authenticated; does not mean all drains forbidden (SCN021 register includes drain).

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain oldmethod/problem evidence; no drainage construction spec or culture claim. Link E38/E39 newerstep; no V003promotion.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F02 source](https://drive.google.com/file/d/1U4xF6NUFrVnSEW3ljz5_FBUWOYMOsZYD/view) — archive`assessments/F02.md`; [F28 source](https://drive.google.com/file/d/1I9BzFKPkSpJ8BQa8KVnb79DU26YAsJ00/view) — archive`assessments/F28.md`; [F43 source](https://drive.google.com/file/d/1RO7-agpxO92Vp7ifjB34WEjXCJ5MXobA/view) — archive`assessments/F43.md`; [F47 source](https://drive.google.com/file/d/1xPD33CTWybukTy10WP5TLN9k6XK3fkFy/view) — archive`assessments/F47.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e38"></a>

# E38 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E38` · **Filename:** `B2_COMPARE_VR-010_WASHING_PLACE_V002_vs_V004.jpg`

**Source:** [1Hl40ep9LfPsb2JqQCFjq6TCtTVrwtKnT](https://drive.google.com/file/d/1Hl40ep9LfPsb2JqQCFjq6TCtTVrwtKnT/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Washing-place steps are domestic/exploratory history. Actual later CD decision accepts flush-grade runoff/off-frame outlet; U-27 domestic-only qualification remains. No engineering performance or ritual/cultural clearance follows from a plausible picture.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2200×1252 JPEG; decoded modeRGB. 

- Source:`849845`bytes; MD5`ebd609bd2c9255a5b5752e32d4599d8d`; SHA256`1318f2f08111affad24b8c8831b2183e5e23387ee0e63406b8d94fabd77adbda`.
- Research:`3888`bytes; MD5`6d3d4517abd782f446fb1deaf2689e56`; SHA256`fc738d68c794a15057a5caa31bf8526bff26dfdb3926347f263e61f8888db6ef`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E38_B2_COMPARE_VR-010_WASHING_PLACE_V002_vs_V004.md](https://drive.google.com/file/d/1mhCm3r7uc4UbqUSQINF9D3DOmZTEFyYM/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'WASHING PLACE · ANCESTRAL REALM · V002 base -> V004 CANDIDATE'. Subtitle (printed): 'Answers REJECTION_REPORT_VR-010_WASHING_PLACE_V003. Masked removal of the exposed runoff channel only; every named V002 element is its own pixels.' Top: BASE V002 (unchanged source) and CANDIDATE V004 · REVIEW REQUIRED, showing the same washing corner as E37 with the channel removed in the candidate. Rows: RUNOFF CHANNEL (before/after) and SLAB, POTS, DIPPER, SPLASH EARTH (base | candidate). Lower text lists defects 1–7, pixel proof, declared deviation and status.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN LABEL: the board banner reads 'ANCESTRAL REALM'; the file is an ENV_HOME_SETTLEMENT item; E39 corrects the banner to 'HOME SETTLEMENT'. Recorded, not corrected.
> - CITATION: the footer cites Basden; the Basden 1921 source is in the research base but the printed claim about 'no documented precedent' is not verified here.
> - UNSUPPORTED: any wall-base outlet is printed as a fictional design choice; no source in this file supports a drain form.
> - UNVERIFIED: the printed pixel counts are not recomputed here.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Washing corner V002 bright open channel replaced by damp fairly flush grade in V004, large slab/pots/screens broadly retained; header mistakenly ANCESTRAL REALM. Footer cites Basden and acknowledges off-frame outlet/no wall opening.

**Independent assessment:** Visible drainage-display change acknowledged; title label error and unsupported provenance footnote are real documentary issues corrected nextversion. No conflict simply because V003recess was replaced inV004. Exact pixel preservation not established by small pair.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Visible drainage-display change acknowledged; title label error and unsupported provenance footnote are real documentary issues corrected nextversion. No conflict simply because V003recess was replaced inV004. Exact pixel preservation not established by small pair.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Visible drainage-display change acknowledged; title label error and unsupported provenance footnote are real documentary issues corrected nextversion. No conflict simply because V003recess was replaced inV004. Exact pixel preservation not established by small pair.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preserve oldaid, link E39 correctlyHOMESETTLEMENT and removedcitation; no new culvert to fill off-framegap. Do not claim Basden validates invented exactarchitecture.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E39 source](https://drive.google.com/file/d/1cWfqzGqDckOzKsZtrDCnxajdM5jkygq3/view) — archive`assessments/E39.md`; [F28 source](https://drive.google.com/file/d/1I9BzFKPkSpJ8BQa8KVnb79DU26YAsJ00/view) — archive`assessments/F28.md`; [F43 source](https://drive.google.com/file/d/1RO7-agpxO92Vp7ifjB34WEjXCJ5MXobA/view) — archive`assessments/F43.md`; [F44 source](https://drive.google.com/file/d/1huW7ymhmxkwA2u3hQ-5ijRO33Mv3RLjj/view) — archive`assessments/F44.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e39"></a>

# E39 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E39` · **Filename:** `B2_COMPARE_VR-010_WASHING_PLACE_V002_vs_V005.jpg`

**Source:** [1cWfqzGqDckOzKsZtrDCnxajdM5jkygq3](https://drive.google.com/file/d/1cWfqzGqDckOzKsZtrDCnxajdM5jkygq3/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Washing-place steps are domestic/exploratory history. Actual later CD decision accepts flush-grade runoff/off-frame outlet; U-27 domestic-only qualification remains. No engineering performance or ritual/cultural clearance follows from a plausible picture.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2200×1302 JPEG; decoded modeRGB. 

- Source:`780362`bytes; MD5`8c544516396839f7663a1a8a2e24287e`; SHA256`b2be7cb29878a4594e8f81573140f67c2e0072e446ba3c1f9c1e08bceb71d8cb`.
- Research:`3931`bytes; MD5`0fadef3c0b3bc1b051eba8cd9703ba69`; SHA256`3231da30c44b2cf2735af382badcf831e1f9740adff2be7337a83b0e1ce8767b`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E39_B2_COMPARE_VR-010_WASHING_PLACE_V002_vs_V005.md](https://drive.google.com/file/d/1comyWGP95zyoBDt1mXCQPfEs2fFEG8nr/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'WASHING PLACE · HOME SETTLEMENT · V002 base -> V005 CANDIDATE'. Subtitle (printed): 'Answers CD ruling on V004: chrome only. Artwork is V004 pixels, unchanged — no drain, no wall opening, no recess, no new architecture, camera unmoved.' Top: BASE V002 (source, untouched), runoff channel present; CANDIDATE V005 — flush grade, off-frame outlet. Both show the washing corner: woven screen, slab, pots, dipper and leaf. Rows: BASE V002 (runoff channel), V005 (same ground, flush), V005 (slab, pots, dipper, soap) and V005 (woven screen, no wall opening). Lower text lists defects 1–5, unchanged note and status.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN LABEL: this board names 'HOME SETTLEMENT' (corrected from 'ANCESTRAL REALM' in E38). Recorded.
> - CONFLICT WITH E37: E37 (V003) shows a stone-lined opening at the wall foot; E38 (V004) shows the channel removed with no opening; this sheet (V005) says the artwork is V004 pixels with no drain. Recorded, not resolved.
> - UNVERIFIED: 'byte for byte' is printed; the file hash is not checked here.
> - UNSUPPORTED: 'the settlement forms follow documented types' is printed; no source is cited for this claim in the image.
> - Candidate only; not approved by this report. Returned for fresh Our Eyes inspection (printed).

## 05. Independent content findings

**Direct source observation:** HOMESETTLEMENT banner now correct, V005 dampflush ground/no open channel, screen/slab/pots/soap detail. Notes explain chrome-onlyV004→V005, citation removal, no wall opening.

**Independent assessment:** Does not contradict E37: it deliberately supersedes V003's recess throughV004. 'No visible drain' not proof of off-framedrainage performance; 'documentedforms' caveatnotculturalauthentication. UnderlyingV005notcurrentPENDING, resolveoutside rather than assume missingglobally.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Does not contradict E37: it deliberately supersedes V003's recess throughV004. 'No visible drain' not proof of off-framedrainage performance; 'documentedforms' caveatnotculturalauthentication. UnderlyingV005notcurrentPENDING, resolveoutside rather than assume missingglobally.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Does not contradict E37: it deliberately supersedes V003's recess throughV004. 'No visible drain' not proof of off-framedrainage performance; 'documentedforms' caveatnotculturalauthentication. UnderlyingV005notcurrentPENDING, resolveoutside rather than assume missingglobally.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retain evidence; do not repeat fullscene review/liftH1/H2culturalgates or inferengineering. Any rawV004/V005identityclaim requires originalPNGcomparison, not thisJPEG.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [E38 source](https://drive.google.com/file/d/1Hl40ep9LfPsb2JqQCFjq6TCtTVrwtKnT/view) — archive`assessments/E38.md`; [F06 source](https://drive.google.com/file/d/1hoh64TdMya1jCslKC_xGARuvsDfHlPOo/view) — archive`assessments/F06.md`; [F28 source](https://drive.google.com/file/d/1I9BzFKPkSpJ8BQa8KVnb79DU26YAsJ00/view) — archive`assessments/F28.md`; [F31 source](https://drive.google.com/file/d/12D8gVf8cqfSQQzghzJtr026lenc38iI9/view) — archive`assessments/F31.md`; [F43 source](https://drive.google.com/file/d/1RO7-agpxO92Vp7ifjB34WEjXCJ5MXobA/view) — archive`assessments/F43.md`; [F44 source](https://drive.google.com/file/d/1huW7ymhmxkwA2u3hQ-5ijRO33Mv3RLjj/view) — archive`assessments/F44.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e40"></a>

# E40 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E40` · **Filename:** `B2_COMPARE_VR-011.jpg`

**Source:** [118DT3OivKh789heYdQRUuXlIc7NcK7mG](https://drive.google.com/file/d/118DT3OivKh789heYdQRUuXlIc7NcK7mG/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

VR-011/H3 is independently held on D9/RQ-01 by the current CD record. Fictional framing never waives that gate. Filename/header/Field-of-Cloth subject mapping must not be resolved by visual similarity or version-number assumptions.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1940×734 JPEG; decoded modeRGB. 

- Source:`408974`bytes; MD5`1be8450ca37c5d60654d95c78747e4aa`; SHA256`fa7266a1b8e71353315c91f269da9385d25d285c25fc610a441e0ed26a9066b8`.
- Research:`3030`bytes; MD5`19086e181a7c105d5e0033f2377c98a7`; SHA256`0ceea82d36a94d097fc69a90c3a66b6ee314c50634db27ccb5492cec18585d83`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E40_B2_COMPARE_VR-011.md](https://drive.google.com/file/d/1HkrDQNDFI-damcNGN7XeQEwTdWz9_wk1/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'VR-011 ENV_GATES_DEAD_LANDING_OF_UNCLAIMED — V001 (REVIEW REQUIRED) -> V002 CANDIDATE (REVIEW REQUIRED)'. ORIGINAL: V001 master, 2560x1440; CANDIDATE: V002, 2560x1440. An overcast riverbank landing: dark earth slopes up at the right under a tall bank; thin white strips hang from poles along the top of the bank; dugout canoes lie in rows on the mud; water at the left. In the foreground a canoe holds a bundled cylinder wrapped in cord, a pot, a folded cloth and a draped grey-blue cloth form. No living figures are visible.

**Published flags (original wording, including any error reconciled below):**

> - INTERPRETIVE RISK: the grey-blue cloth form in the foreground canoe may be read as a wrapped body; the image does not establish this. The file name's 'dead landing' and 'unclaimed' are as printed; the sheet's own disclaimer says no burial claim is made. Recorded, not corrected.
> - UNSUPPORTED: the dugout canoes, the cloth-strip rampart and the landing are fictional proposals; no source in this file supports them.
> - UNVERIFIED: the printed 'hundreds' canoe target and the diff 0 are not recomputed here.
> - PROPOSED only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Landing V001→V002 pair: long earthen-looking rampart, rows of dugouts/cargo, riverleft, paleverticalstripsmoreprominent incandidate; no demonstrablehumanbody. Foregroundbundle/grey-bluecoveredsuppliesambiguous.

**Independent assessment:** Cargo may evoke funerary associations but not establishedbody. D9/RQ01H3remains despite fictiondisclaimer; V002comparisondoesnot independentlyresolveD07filename/headerV001mismatch or C09FieldofClothtitle. Printedcanoecount/diff0notverified.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Cargo may evoke funerary associations but not establishedbody. D9/RQ01H3remains despite fictiondisclaimer; V002comparisondoesnot independentlyresolveD07filename/headerV001mismatch or C09FieldofClothtitle. Printedcanoecount/diff0notverified.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Cargo may evoke funerary associations but not establishedbody. D9/RQ01H3remains despite fictiondisclaimer; V002comparisondoesnot independentlyresolveD07filename/headerV001mismatch or C09FieldofClothtitle. Printedcanoecount/diff0notverified.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Preservehistoricalaid. HOLD D07/B01 releasependingexactsubject/versiondecisionandResearch/CDculturaldirection; no reclassifyingbundlesasremains and no genericclothclearance.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [C09 source](https://drive.google.com/file/d/1GbksU93uvNp26nSVs2sx0msW0CNW-acn/view) — archive`assessments/C09.md`; [F02 source](https://drive.google.com/file/d/1U4xF6NUFrVnSEW3ljz5_FBUWOYMOsZYD/view) — archive`assessments/F02.md`; [F47 source](https://drive.google.com/file/d/1xPD33CTWybukTy10WP5TLN9k6XK3fkFy/view) — archive`assessments/F47.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e41"></a>

# E41 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E41` · **Filename:** `B2_COMPARE_WALL_OF_HOUSES.jpg`

**Source:** [1gcB6yB2ERgfTn1mzWBF43_k-k51uR0TM](https://drive.google.com/file/d/1gcB6yB2ERgfTn1mzWBF43_k-k51uR0TM/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Documentation-only record: current standing CD verdict outranks production-log ready labels, author recommendations and old queue counts. Proposed locations remain proposed; file existence, historical design approval and current limited visual acceptance are distinct.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1940×734 JPEG; decoded modeRGB. 

- Source:`425152`bytes; MD5`ff0afa1674baf4951e5e1d46fb36ba76`; SHA256`1980e055fdfff48c71537251c286342c1c3bbb6750d8fda50745ce09a15a4d75`.
- Research:`2902`bytes; MD5`5ce1b8b062bbc673ed80e0668b0a06a1`; SHA256`17c747b7d66fe6d4ce16988b914db6eb7431859c6cd38a8d04b8e925a5ca5a43`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E41_B2_COMPARE_WALL_OF_HOUSES.md](https://drive.google.com/file/d/1lFUhbGlWsUNCCVJm23lJk_ZMthD3l2Jb/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'WALL OF HOUSES ENV_LAST_DAUGHTER_ANCESTRAL_REALM_WALL_OF_HOUSES — V003 (REVIEW REQUIRED) -> V004 CANDIDATE (REVIEW REQUIRED)'. ORIGINAL: V003 master, 2560x1440; CANDIDATE: V004, 2560x1440. A steep hillside of mud-and-thatch houses stacked up the slope in fog, in reddish earth tones. The V004 panel is bluer in the fog, with pale plastered doorways that show cracks and two small thatched houses at the lower right.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN SOURCE: the board states 'NO V004 EXISTS IN DRIVE' and then presents a V004 CANDIDATE panel. Recorded as printed, not resolved.
> - UNSUPPORTED ARCHITECTURE: the stacked mud-and-thatch hillside is a fictional proposal; no source in this file supports it.
> - UNVERIFIED: the printed 'one roof and one opening' per building is not counted here; ladders and stair runs are visible on several houses.
> - UNVERIFIED: the printed 'diff 0' is not recomputed here.
> - Candidate only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Wall of Houses V003/V004 densely stacked mud/thatch hillside, candidate two newlyseparatefront houses withpalecrackedsealeddoors and heavierbluehaze. Notallupperdwellingscanbecountedfromaid.

**Independent assessment:** 'NoV004existsinDrive' explicitly refers to requestedpre-existingmasterbeforethisoutput, not logicalcontradictionwithV004candidate. NextgenerationV005hasrawlineageoutsidescope. Noculturalsettlementchronologyproved.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

'NoV004existsinDrive' explicitly refers to requestedpre-existingmasterbeforethisoutput, not logicalcontradictionwithV004candidate. NextgenerationV005hasrawlineageoutsidescope. Noculturalsettlementchronologyproved.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** 'NoV004existsinDrive' explicitly refers to requestedpre-existingmasterbeforethisoutput, not logicalcontradictionwithV004candidate. NextgenerationV005hasrawlineageoutsidescope. Noculturalsettlementchronologyproved.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retainhistoryonly, do not promoteV004/sourceasapproved. Needrawexactsource/versionifoperationalverdictrequested; not substitutecompressedpanel. No historicalevidenceoverwrite.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F02 source](https://drive.google.com/file/d/1U4xF6NUFrVnSEW3ljz5_FBUWOYMOsZYD/view) — archive`assessments/F02.md`; [F47 source](https://drive.google.com/file/d/1xPD33CTWybukTy10WP5TLN9k6XK3fkFy/view) — archive`assessments/F47.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e42"></a>

# E42 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E42` · **Filename:** `B2_COMPARE_WALL_OF_HOUSES_V003_vs_V005.jpg`

**Source:** [1T9Eziwd_5UcVfBXgxdi_-7Cvr1XYkT3J](https://drive.google.com/file/d/1T9Eziwd_5UcVfBXgxdi_-7Cvr1XYkT3J/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** comparison aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Documentation-only record: current standing CD verdict outranks production-log ready labels, author recommendations and old queue counts. Proposed locations remain proposed; file existence, historical design approval and current limited visual acceptance are distinct.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2200×1202 JPEG; decoded modeRGB. 

- Source:`682415`bytes; MD5`022f4b27099b9e4ae462ba40828e0581`; SHA256`f2048b6d6b39c2f8d7da60996bcf9b69223c2d5bba59f4d2b8301527be7955f6`.
- Research:`3738`bytes; MD5`74dc673f97b38886d16f27df418f35e9`; SHA256`36f61f3fd09b6fb7e06f3f903240f7cb51d93580d992ff6dc7a88afcb15e1658`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E42_B2_COMPARE_WALL_OF_HOUSES_V003_vs_V005.md](https://drive.google.com/file/d/1x9_p5cfapcw_a9uCFtBQJRgy2omSXtFQ/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A board titled 'WALL OF HOUSES · ANCESTRAL REALM · V003 base -> V005 CANDIDATE'. Subtitle (printed): 'Answers REJECTION_REPORT_WALL_OF_HOUSES_V004. Masked architectural repaint of the built mound; sky, mist and frame edges are V003's own pixels.' Top: BASE (unchanged source) and CANDIDATE · REVIEW REQUIRED, the hillside of houses in fog. Rows: FIRST SETTLEMENT AT THE FOOT (base | candidate) and DOORWAY STATES (lit / dark / plain-sealed). Lower text lists defects A, C, D, F, pixel proof, open items and status.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED HISTORY: 'a distinct older first settlement' is a claim about chronology; no source is cited and it is not supported by the image alone.
> - UNSUPPORTED: the 'shrine elements' and 'painted symbols' exclusions are printed; the image shows no such elements at this resolution, but their absence is not verified here.
> - CONFLICT IN CONTEXT: the printed V004-only defects (red bars, glyphs, obstructing left hut, inverted chronology) were not observed in the V004 panel at this resolution (E41). Recorded, not resolved.
> - UNVERIFIED: the printed pixel counts and '0 bright-red pixels' are not recomputed here.
> - Candidate only; not approved by this report. V003 and the rejected V004 are stated as preserved (not checked here).

## 05. Independent content findings

**Direct source observation:** V003→V005 hillside with moreerodedlowerhuts, gaps/paths, crackedmudsealeddoor and bracedtimberdoor, upperwarmopenings/darkdoorways; nofigureseen. TextstatesbaseV003notrejectedV004.

**Independent assessment:** Research'smissingV004glyphdefectsnotobservedinV003panelisnotaconflict: thisaidcomparesV003base, notV004. 'Olderfirstsettlement' isfictionalstorydesignnotdocumentedhistoricalfact; do notauthenticate. Panelexactcounts/sourceoriginalsnotverifiedhere.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Research'smissingV004glyphdefectsnotobservedinV003panelisnotaconflict: thisaidcomparesV003base, notV004. 'Olderfirstsettlement' isfictionalstorydesignnotdocumentedhistoricalfact; do notauthenticate. Panelexactcounts/sourceoriginalsnotverifiedhere.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Research'smissingV004glyphdefectsnotobservedinV003panelisnotaconflict: thisaidcomparesV003base, notV004. 'Olderfirstsettlement' isfictionalstorydesignnotdocumentedhistoricalfact; do notauthenticate. Panelexactcounts/sourceoriginalsnotverifiedhere.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. PreserveandlinkexactV005outsidePENDING; no reapproval/filingfromaid. Keepfictional/exploratoryandculturalqualifications.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F05 source](https://drive.google.com/file/d/1Wwsibgrlr8bJevMjkRclaQ-iJ-SFgbE_/view) — archive`assessments/F05.md`; [F50 source](https://drive.google.com/file/d/1fNCoel_Z7KnlrMzMBUutBiJEDJ2X9nj0/view) — archive`assessments/F50.md`; [F67 source](https://drive.google.com/file/d/1sRagEJxToeZFTWy7Anx60dVonXRNvDSR/view) — archive`assessments/F67.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e43"></a>

# E43 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E43` · **Filename:** `B2_PIXELDIFF_VR-008_V007.jpg`

**Source:** [1NQCWe-zXx7D88p4GnCWqv42IAsQHva1s](https://drive.google.com/file/d/1NQCWe-zXx7D88p4GnCWqv42IAsQHva1s/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** diagnostic aid. **Currency:** historical evidence / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Historical VR-008 correction evidence must be read by exact generation and method. Current V009 stays unchanged, exploratory composition only, never14_APPROVED_DESIGNS, with noV010 for four logged chrome errata. CQ-9/RQ-10-1/U-11 qualifications remain.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1901×1321 JPEG; decoded modeRGB. 

- Source:`346459`bytes; MD5`242fc74f89f384ac870877d866c059da`; SHA256`207f9d5c9d12a5ef242ada3f54418f0132f86d426b3a92196dd3ebfc03316e8b`.
- Research:`3037`bytes; MD5`f5bc6187f19242274427141aa8968a0f`; SHA256`156e80478fd46189751c82062212c58857f907956bf93a715193c05c20b9b9b5`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E43_B2_PIXELDIFF_VR-008_V007.md](https://drive.google.com/file/d/1eGYZZ8xtPfETJslj511hPIcM8FKbBNZ6/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A pixel-difference image titled 'PIXEL DIFFERENCE V005 panel -> V007 panel (threshold: sum |dRGB| > 12)'. The image is a darkened copy of the figure panel: a standing female figure in an alley with a sealed door at the left and a pot and bowl on the ground. Three green boxes mark changed areas: A fracture (1,504 px, a vertical branched white line on the door panel), B midriff (8,481 px, a white blob at the waist), C armlet (3,633 px, a white band on the upper arm). Printed text is at the bottom of the sheet.

**Published flags (original wording, including any error reconciled below):**

> - ARITHMETIC NOTE: the printed panel total 2,222,269 does not equal 2560×1440 (3,686,400); the panel size is not stated on this sheet and the difference is not reconciled here.
> - UNVERIFIED: the printed 0.61% and 'all inside masks' claims are not recomputed here.
> - CQ-9 OPEN: the hilted object at the hip is not shown in the difference image's detail and is not cleared by this report.
> - UNVERIFIED: the midriff source (V004) and the armlet's reconstruction are printed; not checked here.
> - Diagnostic image only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** DarkenedSealedQuarterfigurepanelwith3greenboxes/whitechangedregions, labelledfracture1504/midriff8481/armlet3633; printedtotal13618of2222269,0.61%, thresholdsumRGB>12.

**Independent assessment:** Independentarithmetic:1901×1169=2222269art-panelpixels;13618/2222269×100≈0.6128%. Research'scomparisonwith2560×1440fullsheetmistakespanelareaformissingpixels; printedtotalisconsistentwithF02paneldimensions. Doesnot independentlyrecomputeactualmasks/rawpairdiff, unalteredclaimsorunseenCQ9weapon.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Independentarithmetic:1901×1169=2222269art-panelpixels;13618/2222269×100≈0.6128%. Research'scomparisonwith2560×1440fullsheetmistakespanelareaformissingpixels; printedtotalisconsistentwithF02paneldimensions. Doesnot independentlyrecomputeactualmasks/rawpairdiff, unalteredclaimsorunseenCQ9weapon.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** EVIDENCE-ONLY / HISTORICAL QUALIFICATION.

**Specific issue:** Independentarithmetic:1901×1169=2222269art-panelpixels;13618/2222269×100≈0.6128%. Research'scomparisonwith2560×1440fullsheetmistakespanelareaformissingpixels; printedtotalisconsistentwithF02paneldimensions. Doesnot independentlyrecomputeactualmasks/rawpairdiff, unalteredclaimsorunseenCQ9weapon.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**NOT ASSESSABLE FOR NEW APPROVAL — SUPERSEDED / REVIEW AID**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

**No new correction is assigned to this historical file.** Its content-qualified use/failure is recorded for lineage only. Retaindiagnostic, recordarithmeticreconciliationandprovenancelimit. Noalteringhistoricalaid/Researchandnoapprovalfromprintedmaskcounts.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F03 source](https://drive.google.com/file/d/1WlPZ0g2zcQPvdGXna-xGfm6XTSf9MbCB/view) — archive`assessments/F03.md`; [F41 source](https://drive.google.com/file/d/1vqo8RMnVh1UQZNREGwBPFPcIHX88OmDl/view) — archive`assessments/F41.md`; [F48 source](https://drive.google.com/file/d/1xDhCmsNgh1xGweNfqldm70AbCTw7CwuL/view) — archive`assessments/F48.md`; [F49 source](https://drive.google.com/file/d/1mODNxtojxzg8UHjSBuRiXMsKRfYAQofw/view) — archive`assessments/F49.md`; [F52 source](https://drive.google.com/file/d/1u_ey_gPxdTM5862Bw_3cfhm3NMcETMxL/view) — archive`assessments/F52.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e44"></a>

# E44 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E44` · **Filename:** `B2_RETOUCH_GUIDE_VR-006_BLOCKED.jpg`

**Source:** [1lPnwpnYUXtsVdPAqmVPK0Wu-54vu58dt](https://drive.google.com/file/d/1lPnwpnYUXtsVdPAqmVPK0Wu-54vu58dt/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** blocked retouch guide. **Currency:** blocked / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Guide execution is blocked on blade authority before hand-scale and rigging; F01 withdraws arbitrary tip/percentage targets. No coordinate/60cm target is adopted as an approved design.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2560×1440 JPEG; decoded modeRGB. 

- Source:`950629`bytes; MD5`23e113720ad6d37476bf53e23a2f6be9`; SHA256`0d63edb14289ecb61ebc9f6b396b47ee470f792cb445e6c10c13a72ded9ff2c1`.
- Research:`3745`bytes; MD5`ecd2512dca31b9e3aec597860326808c`; SHA256`9ceb827d7eadca6814c610fb4c90868a4cffd8440860e2a9545333088b910c78`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E44_B2_RETOUCH_GUIDE_VR-006_BLOCKED.md](https://drive.google.com/file/d/1xVLcomMUuyS99iSC3obvmz-8v-uO56ge/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A character composition sheet titled 'COMPOSITION — ADANNA IN THE MOTHERS' COURTYARD' (tag COMP_ADANNA_MOTHERS_COURTYARD_V003, STATUS: REVIEW REQUIRED, CHAPTER 8, EXPLORATORY). A standing female figure at the right with braids, a metal shoulder plate and a bracelet, behind a stone mortar and a tall wooden pestle; a sheathed blade hangs at her left hip, angled back below mid-thigh. The courtyard has a mud wall, a thatched roof at the left, a loom with striped cloth, three clay pots, a broom, a tree and an open doorway. Overlay: 'VR-006 RETOUCH GUIDE — one object only', with a KEEP marker at the hilt and a current-tip marker, a target line, and ACTION and MUST NOT CHANGE lists.

**Published flags (original wording, including any error reconciled below):**

> - CQ-9 OPEN: the blade and sheath are not cleared; the footer says 'approved blade board' while the register records a conflict on that board (F01) and CQ-9 open.
> - FILE NAME: the file is named 'BLOCKED'; the sheet's own status is 'REQUIRES REVISION'. Recorded, not corrected.
> - REFERENCE NAME: 'REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001' differs from 'CHAR_ADANNA_MASTER_REFERENCE_V001' cited elsewhere; neither is in the registers. Recorded, not corrected.
> - A correction instruction in the right box is partly hidden by the overlay.
> - UNVERIFIED: the printed coordinates and 'shorter than V002' are not measured here.
> - Visual development only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** MothersCourtyardV003backgroundwithfigure/metalshouldercap/left-hipdiagonalsheathbehindmortarandpestle; overlaidKEEP/hilt1560,622/currenttip1760,782/verticaltarget1600,880/65%instructions. Footer falselycallsbladeboardapproved.

**Independent assessment:** CQ9authoritygapconfirmedbyactualbladeboardREVIEWREQUIRED/provisional60cm/nohandscale andF01withdrawal. Coordinatesareproposedretouchtargetsnotapprovedspecs. GuideBLOCKEDversusoldunderlyingREQUIRESREVISIONisdifferentrole,notastatusconflict. Portrait/referenceareseparatedistinctfilesnotinherentlynameconflict.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

CQ9authoritygapconfirmedbyactualbladeboardREVIEWREQUIRED/provisional60cm/nohandscale andF01withdrawal. Coordinatesareproposedretouchtargetsnotapprovedspecs. GuideBLOCKEDversusoldunderlyingREQUIRESREVISIONisdifferentrole,notastatusconflict. Portrait/referenceareseparatedistinctfilesnotinherentlynameconflict.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** CQ9authoritygapconfirmedbyactualbladeboardREVIEWREQUIRED/provisional60cm/nohandscale andF01withdrawal. Coordinatesareproposedretouchtargetsnotapprovedspecs. GuideBLOCKEDversusoldunderlyingREQUIRESREVISIONisdifferentrole,notastatusconflict. Portrait/referenceareseparatedistinctfilesnotinherentlynameconflict.

**Dependencies:** CQ-9; BLADE_AUTHORITY; HAND_SCALE_AFTER_AUTHORITY

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD — GUIDE EXECUTION BLOCKED**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD guideexecution. CD/Researchmustresolveselectbladeauthorityandhandscale/riggingbeforefilinganynewtip/angle/lengthbrief; appendnon-destructivewithdrawal/supersessioncrosslinktoF01underownerdecision. No65%/coordinate/verticalhangingimplementation,nofigure/costumechanges,noweaponcanon.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F01 source](https://drive.google.com/file/d/1QFJ_9JSjmgNIiRhncDWfObk_cJsfi5SU/view) — archive`assessments/F01.md`; [F47 source](https://drive.google.com/file/d/1xPD33CTWybukTy10WP5TLN9k6XK3fkFy/view) — archive`assessments/F47.md`; [F51 source](https://drive.google.com/file/d/1LVTcBLlt5eWhbOdX3uqJ3EPIc-_Fv4u5/view) — archive`assessments/F51.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e45"></a>

# E45 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E45` · **Filename:** `B2_RETOUCH_GUIDE_VR-007_BLOCKED.jpg`

**Source:** [1C_jk77ERIws4CsKIyHD1txrfBWwAaiSp](https://drive.google.com/file/d/1C_jk77ERIws4CsKIyHD1txrfBWwAaiSp/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** blocked retouch guide. **Currency:** blocked / not artwork candidate. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Guide execution is blocked on blade authority before hand-scale and rigging; F01 withdraws arbitrary tip/percentage targets. No coordinate/60cm target is adopted as an approved design.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

2560×1440 JPEG; decoded modeRGB. 

- Source:`901594`bytes; MD5`0837a24ad66067361655192b42fb0227`; SHA256`b91940d382abc741d38fe47ca0bfd2c4fa9551d7c606aa08780f8b979f1238c1`.
- Research:`3870`bytes; MD5`30f5d7cd8fa1d4f9d820a33d1507c130`; SHA256`387faf0e44ef96f3f0b6b6fd23025f07de23ca1ea070b740709ce8074ede8669`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E45_B2_RETOUCH_GUIDE_VR-007_BLOCKED.md](https://drive.google.com/file/d/1GQCBoMB8T6Uc5twVLfm5D2T2NA9y_lRK/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A character composition sheet titled 'COMPOSITION — ADANNA INSIDE NNEKA'S HOUSE' (tag COMP_ADANNA_NNEKAS_HOUSE_INTERIOR_V002, STATUS: REVIEW REQUIRED, CHAPTER 8, EXPLORATORY). A seated female figure on a raised sleeping platform in a mud interior with a thatched roof and rafters; she wears a blue wrap skirt and a metal shoulder plate, with braids, turned toward an open doorway at the left. A hearth of three stones with a pot and ash sits on the floor; jars, a basket with white material, a folded striped cloth and a mat are in the room. A long sheath runs from her hip down to the floor. Overlay: 'VR-007 RETOUCH GUIDE — one object only', with a KEEP marker at the pommel, a chape-disc marker, a target line and ACTION and MUST NOT CHANGE lists.

**Published flags (original wording, including any error reconciled below):**

> - CONFLICT IN LENGTH: the sheet computes the sheath at about 90–100 cm (383 px) and separately describes the approved short blade as about 60 cm; the two figures are not reconciled. Recorded, not resolved.
> - CQ-9 OPEN: the blade length is not cleared by this report; the printed 'approved short blade' is not verified against any register.
> - REFERENCE NAME: 'REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001' differs from the CHAR_ADANNA_MASTER_REFERENCE_V001 cited elsewhere; neither is in the registers.
> - A story note in the right box is partly hidden by the overlay; the readable part says 'the cloth is a staging idea only and establishes nothing'.
> - UNVERIFIED: the printed 'one fault noted' and 'the hearth is three stones with a pot again' are not checked here.
> - Visual development only; not approved by this report.

## 05. Independent content findings

**Direct source observation:** SeatedAdannainNnekainteriorV002, shoulderarmourandlongsheathoverlapwrap/platform, three-stonepothearth. Overlaypommel1545,690/tip1357,940/y865/70%/383px≈90–100cm. Printedapprovedshortblade≈60cm.

**Independent assessment:** Comparingclaimedcurrent90–100cmwithtarget60cmisadefectargument,notitselfalogicalcontradiction; BOTHphysicalscaleclaimsunsupportedwithoutgoverningblade/handscale. F01withdrawsarbitrarytargets. Noclearbarebladeonplatformseen,soearlierbare-bladeclaimnotrevived. CQ9OPENandpauldron/characterissuescannotbesilentlylicensedbypreserveinstructions.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [CHARACTER_DESIGN_REGISTER.md](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) — D3; full text.
- [CHAR_ADANNA_MASTER_REFERENCE_V001.jpg](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) — D5; individual full image display.
- [REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) — D3; individual full image display.
- [WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) — D3; individual full image display.

**Exact prior CD outcome, if present:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Comparingclaimedcurrent90–100cmwithtarget60cmisadefectargument,notitselfalogicalcontradiction; BOTHphysicalscaleclaimsunsupportedwithoutgoverningblade/handscale. F01withdrawsarbitrarytargets. Noclearbarebladeonplatformseen,soearlierbare-bladeclaimnotrevived. CQ9OPENandpauldron/characterissuescannotbesilentlylicensedbypreserveinstructions.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Comparingclaimedcurrent90–100cmwithtarget60cmisadefectargument,notitselfalogicalcontradiction; BOTHphysicalscaleclaimsunsupportedwithoutgoverningblade/handscale. F01withdrawsarbitrarytargets. Noclearbarebladeonplatformseen,soearlierbare-bladeclaimnotrevived. CQ9OPENandpauldron/characterissuescannotbesilentlylicensedbypreserveinstructions.

**Dependencies:** CQ-9; BLADE_AUTHORITY; HAND_SCALE_AFTER_AUTHORITY

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD — GUIDE EXECUTION BLOCKED**

**Existing CD record retained:** Not an exact member of the prior38 matched image manifest; no new CD verdict inferred.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD execution. CD/Researchresolvebladeauthoritybeforehandscaleandanynarrownewfileddirection;doNOTimplement70%,y865,60cmor90–100cmfromthisguide.Noartistregeneration/retouch/moveauthorisedbyassessment;originalguidepreservedwithwithdrawalindexed.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [F01 source](https://drive.google.com/file/d/1QFJ_9JSjmgNIiRhncDWfObk_cJsfi5SU/view) — archive`assessments/F01.md`; [F47 source](https://drive.google.com/file/d/1xPD33CTWybukTy10WP5TLN9k6XK3fkFy/view) — archive`assessments/F47.md`; [F51 source](https://drive.google.com/file/d/1LVTcBLlt5eWhbOdX3uqJ3EPIc-_Fv4u5/view) — archive`assessments/F51.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e46"></a>

# E46 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E46` · **Filename:** `ENV_CH03-INT-004_THE_FORGOTTEN_KITCHEN_V002.jpg`

**Source:** [16yJsFYZRa3iE1VAtAqhBTAI3JLuUdCmT](https://drive.google.com/file/d/16yJsFYZRa3iE1VAtAqhBTAI3JLuUdCmT/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-INT-004` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A kitchen shelter with three hearth stones, a pot of something long dried, firewood stacked for a meal never cooked.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Hearth stones, pot, firewood.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`326548`bytes; MD5`fb40cdfd3a8dc941e72732b106529d90`; SHA256`d18bb268f8a316e0bcdb81363dd8116a70b9495f7cea12cb10249fe4f3c9fda2`.
- Research:`2810`bytes; MD5`b2758d6120a1912400958b1c3884d6a4`; SHA256`a72381982376736531577c2f05a09d3884be4fa1622682f0ea8f48b5927e1644`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E46_ENV_CH03-INT-004_THE_FORGOTTEN_KITCHEN_V002.md](https://drive.google.com/file/d/1z35AGX91Z8ZWA-NjSfNe2Nau0GYCM8xt/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> An interior of a mud-walled kitchen in monochrome grey, with a timber-and-thatch roof. A doorway at the left opens onto bare, snow-dusted trees. A blackened clay pot sits on three stones on a bed of grey ash in the centre. Bundles of dried plants hang from a horizontal pole across the back wall. A dark doorway opens at the rear right; a stacked grinding stone and a stone bowl sit at the right. Snow-like speckle falls through the image. No people are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED SETTING: the snow, bare trees and grey palette are visual choices; the setting (CH03) is not established. The CH03 setting scope is unresolved in the research base; the 20 proposed location entries are not cleared here.
> - UNIDENTIFIED: the hanging bundles are not identified by species or use; no herbal claim is made.
> - UNVERIFIED: the ash bed is depicted as cooking residue; no fire or heat is established by the image.
> - NAME AS FILED: 'THE FORGOTTEN KITCHEN' is the file's label; not verified against any register here.
> - ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Grey earthen kitchen, rough rafters/thatch, cold blackened pot on three separate hearth stones over ash; hanging dry bundles, grinding/quern-like stacked stones and bowl right, bare branches outside. No distinct cut-firewood stack is legible; airborne pale specks.

**Independent assessment:** Cold hearth/pot are closer to proposed CH03-INT004/Firewood for a Meal than old V001 metal/tap/chimney treatment. Required firewood for interrupted meal is still not established. Research calls speckle snow, but canonical chapter explicitly slow ash fall/grey daylight; white pixels alone do not establish snow. Plant species or past fire event not authenticated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Required stacked firewood is not clearly established; cold three-stone hearth correction is acknowledged.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Cold hearth/pot are closer to proposed CH03-INT004/Firewood for a Meal than old V001 metal/tap/chimney treatment. Required firewood for interrupted meal is still not established. Research calls speckle snow, but canonical chapter explicitly slow ash fall/grey daylight; white pixels alone do not establish snow. Plant species or past fire event not authenticated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Cold hearth/pot are closer to proposed CH03-INT004/Firewood for a Meal than old V001 metal/tap/chimney treatment. Required firewood for interrupted meal is still not established. Research calls speckle snow, but canonical chapter explicitly slow ash fall/grey daylight; white pixels alone do not establish snow. Plant species or past fire event not authenticated.

**Dependencies:** CH03_PROPOSED_SCOPE; FIREWOOD_STAGING_REFERENCE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**CORRECTION REQUIRED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Required stacked firewood is not clearly established; cold three-stone hearth correction is acknowledged.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

CORRECTION REQUIRED as a proposed final-brief recommendation only: once CH03 proposed-location scope is confirmed, make reference-backed required firewood stack legible while preserving three-stone cold hearth, earthen/thatch shell, flat-grey/ash/empty staging; no magic, people, snow event or cultural plant lore added. Existing NOT APPROVED unchanged; no production correction executed or authorised.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B24 source](https://drive.google.com/file/d/18RHdPeQM-WUSA9N0dvliTi4WWqsfcFVX/view) — archive`assessments/B24.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e47"></a>

# E47 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E47` · **Filename:** `ENV_CH03-INT-005_A_SLEEPING_ROOM_V002.jpg`

**Source:** [1SR7CRZC9MZjTBsEi84_N3b4sesAmDsiq](https://drive.google.com/file/d/1SR7CRZC9MZjTBsEi84_N3b4sesAmDsiq/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-INT-005` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A dark inner room seen through a doorway: mats laid out, cloths folded as if for the night.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Mats, cloths.
> **Notes.** Not enterable: seen from the outer room only.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`220967`bytes; MD5`f8bc416ce2d9f7917973fb4fb0dc9e35`; SHA256`036337bef1fd5b492ce4d9915dc6c1eb4a7194f7b132ba6b03cdf3cc16d5019e`.
- Research:`2438`bytes; MD5`d11efe917743916bb09a9783f9f05791`; SHA256`b63c844a327f54722cf82ffc5540fc45741b739e0e84185b22edefe8717bdaf8`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E47_ENV_CH03-INT-005_A_SLEEPING_ROOM_V002.md](https://drive.google.com/file/d/1WZZk5Xp6qZayjl6pXV2RgvjGb6tkJOjU/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> An interior in monochrome grey, seen through a timber-framed doorway. A raised platform of planks stands against the back wall, with a folded cloth at its right end; cobwebs hang across the upper corner. A clay pot and a small bowl sit on the earthen floor at right. The walls are mud-plastered; the doorway frame is timber. No people are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED SETTING: the monochrome treatment and the room's use as a sleeping room are the file's label; the image shows a platform and a cloth but no sleeper. CH03 setting unresolved; the 20 proposed location entries are not cleared here.
> - UNIDENTIFIED: the platform's material and the folded cloth's material are not established.
> - UNVERIFIED: the bowl and pot are not identified by type or use.
> - ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Doorway-framed dark earthen room, low rough plank platform with woven mat and folded dark cloth, jar and bowl on dusty floor, cobwebs above. No person or remains visible; no status band.

**Independent assessment:** Exact MD5 f8bc416ce2d9f7917973fb4fb0dc9e35 equals CD accepted Sleeping Room V002. Direction of mats/folded cloth correction is present. Research's inability to prove function from a label does not supply a material reason to reopen accepted visual outcome. Platform construction/use not culturally or technically authenticated, and whole production room-kit coverage is not established.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Doorway-framed room, mat and folded-cloth correction outcome retained.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Exact MD5 f8bc416ce2d9f7917973fb4fb0dc9e35 equals CD accepted Sleeping Room V002. Direction of mats/folded cloth correction is present. Research's inability to prove function from a label does not supply a material reason to reopen accepted visual outcome. Platform construction/use not culturally or technically authenticated, and whole production room-kit coverage is not established.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** NO NEW VISUAL DEFECT DECISION.

**Specific issue:** Exact MD5 f8bc416ce2d9f7917973fb4fb0dc9e35 equals CD accepted Sleeping Room V002. Direction of mats/folded cloth correction is present. Research's inability to prove function from a label does not supply a material reason to reopen accepted visual outcome. Platform construction/use not culturally or technically authenticated, and whole production room-kit coverage is not established.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**RETAIN EXISTING ACCEPTED VISUAL PASS ONLY**

**Existing CD record retained:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Doorway-framed room, mat and folded-cloth correction outcome retained.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

APPROVAL RECOMMENDED strictly to RETAIN EXISTING LIMITED VISUAL PASS. No new cultural, technical, production-canon or proposed-location clearance; no regeneration or addition of sleepers. Preserve accepted bytes and resolve any future kit/access/culture scope separately with CD/Research.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B25 source](https://drive.google.com/file/d/1xxQFlOkqg045hnmWm-wJY428u0xSV3-K/view) — archive`assessments/B25.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e48"></a>

# E48 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E48` · **Filename:** `ENV_CH03-SUB-005_A_RESIDENTIAL_COURTYARD_V002.jpg`

**Source:** [1xDJaz1ip1sU4mNFkUpjjPFcCkOGu1d-N](https://drive.google.com/file/d/1xDJaz1ip1sU4mNFkUpjjPFcCkOGu1d-N/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-SUB-005` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A family courtyard with a mortar and pestle left standing, mats rolled, a child's clay toy.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Mortar, mats, toy.
> **Notes.** No remains shown.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`289520`bytes; MD5`3089de400520bb8bb59912134790af82`; SHA256`47ac2c340ffdf929b30dbda775e3b5527a626d7125a879ee0b45a65dabfc190e`.
- Research:`2623`bytes; MD5`93a81eabdb09c26e629f6fd1a1bfffd1`; SHA256`36b7b58f675ebb1977f35947ef68b54a50b4865585efc875369b3329430c7d8a`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E48_ENV_CH03-SUB-005_A_RESIDENTIAL_COURTYARD_V002.md](https://drive.google.com/file/d/1tadIirAFNwHY3VRmatJHbPjoU2KzS34L/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A courtyard in grey, snow-speckled light. A thatched mud house at the right has a wooden mortar with a pestle standing against its wall, beside two rolled woven mats. A small carved bird figure sits on the ground in the foreground. At the left, a rope between two posts carries two cloths: one blue with pale stripes, one plain dark blue. A low mud wall runs across the left; a thatched roof shows behind it. No people are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNIDENTIFIED: the carved bird figure's species or meaning is not established; no cultural claim is made.
> - UNIDENTIFIED: the mats' weave and pattern are not identified; the striped blue cloth's dye is not identified and no indigo practice is claimed.
> - UNSUPPORTED SETTING: the CH03 setting is not established by the image; the 20 proposed location entries are not cleared here.
> - ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Grey ash-toned courtyard, coarse mud/thatch house, standing mortar/pestle, two rolled mats, two blue cloths (one striped), bird-shaped small toy on ground. Toy has grain/striated-looking shading and warm brown tone, but rendering does not prove physical wood or clay.

**Independent assessment:** Brief CH03-SUB005 specifically child's CLAY toy. E48 Research calls carved bird/wood-like while prior current RR11 calls clay; material-read disagreement persists, no new CD resolution. Generic bird not automatically sacred or species-authenticated. Grey speckles align with registered ash as readily as snow; do not assert snowfall. Textiles OAD55/56 remain unvalidated.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Toy material-read dispute retained. Current RR11 says clay bird, unlike the earlier account; this is not changed artwork or a CD ruling resolving the disputed read.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Brief CH03-SUB005 specifically child's CLAY toy. E48 Research calls carved bird/wood-like while prior current RR11 calls clay; material-read disagreement persists, no new CD resolution. Generic bird not automatically sacred or species-authenticated. Grey speckles align with registered ash as readily as snow; do not assert snowfall. Textiles OAD55/56 remain unvalidated.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Brief CH03-SUB005 specifically child's CLAY toy. E48 Research calls carved bird/wood-like while prior current RR11 calls clay; material-read disagreement persists, no new CD resolution. Generic bird not automatically sacred or species-authenticated. Grey speckles align with registered ash as readily as snow; do not assert snowfall. Textiles OAD55/56 remain unvalidated.

**Dependencies:** CLAY_TOY_MATERIAL_READ; CH03_PROPOSED_SCOPE; OAD-55/56

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Toy material-read dispute retained. Current RR11 says clay bird, unlike the earlier account; this is not changed artwork or a CD ruling resolving the disputed read.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD release on toy-material read and proposed CH03 scope. CD/Research confirm specified clay-toy appearance via marked crop/reference; only if necessary authorise a tightly bounded material-read correction. Preserve bird shape/mortar/rolled-mats/grey setting and don't add symbolism, child or funerary attribution. Existing NOT APPROVED is not regeneration authority.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B26 source](https://drive.google.com/file/d/10Apn34FkRedH1E5NXGCa9KSZ1Dh42SJK/view) — archive`assessments/B26.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e49"></a>

# E49 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E49` · **Filename:** `ENV_CH03-SUB-006_THE_BACK_PLOTS_V002.jpg`

**Source:** [1bs7I2_iPaWQMANPkCLu8YA3x_24FiS9n](https://drive.google.com/file/d/1bs7I2_iPaWQMANPkCLu8YA3x_24FiS9n/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-SUB-006` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** House gardens gone to grey stalks, a cane fence, a hoe standing in the ground.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Dead garden, fence, hoe.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`391457`bytes; MD5`95d9b92d34b090aa94bc1faaf7bddc63`; SHA256`34ffe5034ecadcb6641efe265f33d3842393d82303dc01bdeba0365c6f0119e4`.
- Research:`2566`bytes; MD5`f61d3439509ae2d73129dbc331401d0d`; SHA256`e021da6a47d253a9694d7c807962bb7d9966f6e87bd4572555c42496be269c2d`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E49_ENV_CH03-SUB-006_THE_BACK_PLOTS_V002.md](https://drive.google.com/file/d/1kIclq7ePR6J4_VONN09U-8Xt-GKwN4A9/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A dusty grey plot with a thatched mud house at the left. A wooden hoe stands upright in the ground in the centre. A broken clay pot lies on its side at the right, against a woven wattle fence. Dry, stalk-like plants stand at the left edge. Two more thatched houses and bare trees stand in the background under an overcast sky. The ground is covered in ash-grey dust. No people are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED: the ash-grey surface is read by the image as dust or ash; no fire or damage event is established.
> - UNIDENTIFIED: the dry stalks are not identified as any crop; 'back plots' is the file's label and is not verified here.
> - UNVERIFIED: the hoe's type and use are not established.
> - UNSUPPORTED SETTING: CH03 setting unresolved; the 20 proposed location entries are not cleared here.
> - No caption band, status text or file-level label is visible on the plate. ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Grey dead garden plots among mud/thatch houses, dry stalks, wattle/cane-like fence, upright hoe with wooden shaft and dark flat head, fallen clay pot. No person visible, no clearly legible scrawl.

**Independent assessment:** Exact95d9b92d34b090aa94bc1faaf7bddc63 equals accepted Back Plots V002; generic required dead-plots/fence/hoe cues present. Does not prove head metal/species/crop or an actual fire event. New Research's uncertainty does not materially reverse existing accepted visual pass; not cultural authentication.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Dead plots/fence/hoe/grey atmosphere retained; alleged scrawl was not reproduced.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Exact95d9b92d34b090aa94bc1faaf7bddc63 equals accepted Back Plots V002; generic required dead-plots/fence/hoe cues present. Does not prove head metal/species/crop or an actual fire event. New Research's uncertainty does not materially reverse existing accepted visual pass; not cultural authentication.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** NO NEW VISUAL DEFECT DECISION.

**Specific issue:** Exact95d9b92d34b090aa94bc1faaf7bddc63 equals accepted Back Plots V002; generic required dead-plots/fence/hoe cues present. Does not prove head metal/species/crop or an actual fire event. New Research's uncertainty does not materially reverse existing accepted visual pass; not cultural authentication.

**Dependencies:** Record-specific source/brief and intended-use limitations stated in components5–7; no separate gate is silently cleared.

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**RETAIN EXISTING ACCEPTED VISUAL PASS ONLY**

**Existing CD record retained:** ACCEPTED VISUAL PASS ONLY — Accepted current-cycle visual pass; not reopened. Dead plots/fence/hoe/grey atmosphere retained; alleged scrawl was not reproduced.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

APPROVAL RECOMMENDED only to retain prior limited visual pass, unchanged. No automatic crop/soil/ash-event claim, production-kit approval or correction request. Parent proposed CH03 scope remains a separate CD decision; no revisiting same pixels without material evidence.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B27 source](https://drive.google.com/file/d/1RcEkIjAlMqO6cvKhwALy9gveVL07gOCK/view) — archive`assessments/B27.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e50"></a>

# E50 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E50` · **Filename:** `ENV_CH03-TRV-003_THE_NARROW_PASSAGES_V002.jpg`

**Source:** [1OmXsyhC7HZJrZuLjFqBKNkpAq4lqUWf2](https://drive.google.com/file/d/1OmXsyhC7HZJrZuLjFqBKNkpAq4lqUWf2/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH03-TRV-003` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** Gaps a shoulder wide between compound walls, drifted knee-deep in ash, with footprints that stop.
> - Architecture: Rectangular mud compounds, steep thatch, carved doors; palace as a larger compound.
> - Materials: Laterite mud, hardwood, palm thatch, fired clay, cotton cloth.
> - Lighting: Shadowless grey daylight.
> **Required assets.** Wall backs, ash drifts.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`361993`bytes; MD5`8b02b0087f181b0aa3f9d8c2fdc525d8`; SHA256`9c5fa0e505b61088a27a5cf1162610209c3bc1d644b1ac4a6b3b0c6f35cc7bd3`.
- Research:`2529`bytes; MD5`721ad92f9cc34e7be9ac8775410ac171`; SHA256`817fca59c6d9a031d11a47af27bf5da76f8ce9d3fefaa61ac61889ada715d388`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E50_ENV_CH03-TRV-003_THE_NARROW_PASSAGES_V002.md](https://drive.google.com/file/d/1Tq2gzBj3yNgQSErR7hwKCO72D6JOdJyL/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A deep, narrow earthen passage between two very tall, ridged mud walls, with dust falling through grey air. A low mound of earth lies along the centre of the floor, with a line of footprints running along the path. Walls break into uneven tops at the far end; the sky is grey. No people are visible; the footprints show that someone walked here.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED SCALE: the wall height and the passage's width are not measurable from the image; the walls may be fictional proposals.
> - UNIDENTIFIED: the mound's origin (spoil, drift or deposit) is not established.
> - UNVERIFIED: the footprints' maker and date are not established.
> - UNSUPPORTED SETTING: the CH03 'travel' setting is not established; the 20 proposed location entries are not cleared here.
> - No caption band, status text or file-level label is visible on the plate. ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Very high nearly continuous grey striated walls on both sides, narrow powdery passage, central ash/dust mound, single line of footprints toward obscured end. No people. Wall surface has uniform vertical texture; not possible to identify real material composition from rendered pixels.

**Independent assessment:** Proposed brief shoulder-wide compound gaps/knee-deep ash/footprints-that-stop only partly represented; footprints fade/occlude behind mound rather than unambiguously ending. Strong concrete-like impression remains a material-appearance concern, not proof of actual concrete. E50 calls mud; that label does not settle closed-cycle blocker or physical wall height.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** BLOCKED / PRESERVE — BLOCKED: wall-material appearance unresolved. Current report calls walls mud; concrete-like appearance is not proof of actual concrete, and the report label does not independently settle that finding.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Proposed brief shoulder-wide compound gaps/knee-deep ash/footprints-that-stop only partly represented; footprints fade/occlude behind mound rather than unambiguously ending. Strong concrete-like impression remains a material-appearance concern, not proof of actual concrete. E50 calls mud; that label does not settle closed-cycle blocker or physical wall height.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Proposed brief shoulder-wide compound gaps/knee-deep ash/footprints-that-stop only partly represented; footprints fade/occlude behind mound rather than unambiguously ending. Strong concrete-like impression remains a material-appearance concern, not proof of actual concrete. E50 calls mud; that label does not settle closed-cycle blocker or physical wall height.

**Dependencies:** CH03_WALL_MATERIAL_READ; CH03_PROPOSED_SCOPE; FOOTPRINT_MICROBEAT

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** BLOCKED / PRESERVE — BLOCKED: wall-material appearance unresolved. Current report calls walls mud; concrete-like appearance is not proof of actual concrete, and the report label does not independently settle that finding.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD on wall-material read/scale and intended microbeat. Obtain accepted earthen-compound crop/reference plus CD-marked material/termination target before any correction; no blanket invented prohibition on tall walls, no claim of actual concrete, no figure addition. Preserve historical blocker and all source evidence.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B28 source](https://drive.google.com/file/d/1DtT7wfMJt63S_oGN-cIKuzR__7oDAqRG/view) — archive`assessments/B28.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e51"></a>

# E51 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E51` · **Filename:** `ENV_CH04-INT-001_A_FISHING_SHELTER_V002.jpg`

**Source:** [13Dc48FnSA9nvCUzL2zBq6zNv6axFLtIG](https://drive.google.com/file/d/13Dc48FnSA9nvCUzL2zBq6zNv6axFLtIG/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-INT-001` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** An open lean-to on the bank with nets hung to dry, floats, a mending needle and a cold fire.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** Lean-to, nets, floats.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1376×768 JPEG; decoded modeRGB. 

- Source:`270003`bytes; MD5`8abc676e02f4b0a068d0810241ca797f`; SHA256`6e71f9fc793dfb4add64af7d862be737ab525b153e87e989252f377486c73761`.
- Research:`2568`bytes; MD5`d44ed6bc8d8c2cbf8c519760c8dfccb0`; SHA256`36487742f04a9b6bfcf1a72e59547401bda42a27079bc1457606e0e68342f127`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E51_ENV_CH04-INT-001_A_FISHING_SHELTER_V002.md](https://drive.google.com/file/d/1QOwDK5f6r1rgGkj5ION8K6-ndxN26CvP/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A thatched open-sided shelter on timber posts, painted in a digital-painting style, facing a broad river. Fishing nets with floats hang from poles at the centre and right. At the left stand tall conical woven traps and a round woven basket. A flat wooden board lies on the muddy floor with a knife on it. A wooden platform with a rack extends over the water at the right. No people are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNIDENTIFIED: the net type, the trap type and the fish species are not identified; no fishing method is claimed.
> - UNIDENTIFIED: the knife's type and use are not established. This report does not relate it to the CQ-9 blade question.
> - UNSUPPORTED SETTING: CH04 setting scope unresolved; the 20 proposed location entries are not cleared here.
> - UNVERIFIED: the platform's use over water is not established.
> - ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Open bank lean-to with round posts/thatch, suspended nets/floats, conical baskets/traps, broad river, over-water timber rack. Rectangular metal knife/cleaver-like tool on board foreground. No definite cold hearth, mending needle or smoke plume visible; river/current surface light neutral-grey.

**Independent assessment:** Nets and bank lean-to fit the proposed subject generally. Actual output is1376×768 versus F68’s stated source1672×941; this is not a native target-size pass and requires asset-specific technical acceptance, not an invented universal1536×1024 rule. Required cold fire and mending needle are not clearly legible. No definite smoke was reproduced and the utility knife is not an Adanna/CQ-9 blade specification.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** BLOCKED / PRESERVE — TECHNICAL / BRIEF HOLD. Verified 1376x768 output acceptance and cold-fire read unresolved. Smoke allegation was not independently confirmed.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Nets and bank lean-to fit the proposed subject generally. Actual output is1376×768 versus F68’s stated source1672×941; this is not a native target-size pass and requires asset-specific technical acceptance, not an invented universal1536×1024 rule. Required cold fire and mending needle are not clearly legible. No definite smoke was reproduced and the utility knife is not an Adanna/CQ-9 blade specification.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Nets and bank lean-to fit the proposed subject generally. Actual output is1376×768 versus F68’s stated source1672×941; this is not a native target-size pass and requires asset-specific technical acceptance, not an invented universal1536×1024 rule. Required cold fire and mending needle are not clearly legible. No definite smoke was reproduced and the utility knife is not an Adanna/CQ-9 blade specification.

**Dependencies:** 1376x768_OUTPUT_ACCEPTANCE; COLD_FIRE_BRIEF; CH04_PROPOSED_SCOPE; FISHING_GEAR_REFERENCE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**HOLD**

**Existing CD record retained:** BLOCKED / PRESERVE — TECHNICAL / BRIEF HOLD. Verified 1376x768 output acceptance and cold-fire read unresolved. Smoke allegation was not independently confirmed.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

HOLD technical acceptance and cold-fire/gear scope. CD specifies accepted dimensions/aspect or real new-render requirement (not relabelled upscale); Research/CD mark required cold fire/mending-tool reference before narrowly scoped correction. No global painterly-only/photoreal ban, no invented boatbuilding culture or knife design, no work executed.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B31 source](https://drive.google.com/file/d/1P-PjtOw4TrIjmN3uZsrFZF0NDjzgfHSv/view) — archive`assessments/B31.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e52"></a>

# E52 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E52` · **Filename:** `ENV_CH04-INT-002_A_RIVERBANK_HOUSE_V002.jpg`

**Source:** [1e98rcp-QG7u5z9ihXmbabgGDXe94XTEa](https://drive.google.com/file/d/1e98rcp-QG7u5z9ihXmbabgGDXe94XTEa/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-INT-002` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A mud house a few steps above the water: paddles by the door, dried fish in the rafters, a sleeping platform.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** House shell, paddles, fish racks.
> **Notes.** On the ground, not stilts.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`399039`bytes; MD5`3261013e9e7b46f61ce4ea7243ea816b`; SHA256`454999c6ae6d521ed9e0f5b1d3a9ab42e234e5b097a08f15c37ef64909bf67b7`.
- Research:`2632`bytes; MD5`75fc1740e13f1591fa517ee2fab6c465`; SHA256`6bbebf1c29036866e30e74c6ca93b32f53e3025a79d34d5913c34e232fb91b37`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E52_ENV_CH04-INT-002_A_RIVERBANK_HOUSE_V002.md](https://drive.google.com/file/d/1dJiMc4sJxjhROWR0pq88QUhiykY19PVk/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A single-room mud house with a steep thatched roof, on a sandy bank beside a broad brown river under a bright sky. Pale patches of plaster or whitewash show on the walls. The open doorway shows a raised platform with a mat inside and dried fish hung on a line at the top of the doorway. A small barred window sits at the left. Outside: a tall grey jar, a brown pot, round woven baskets, a conical trap leaning at the left, and a dugout canoe on the shore at the right. No people are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNIDENTIFIED: the pale wall patches are not identified (plaster, lime or wear); no finish is claimed.
> - UNIDENTIFIED: the fish species and the drying method are not established.
> - UNVERIFIED: the platform's use and the mat's material are not established.
> - UNSUPPORTED SETTING: CH04 setting scope unresolved; the 20 proposed location entries are not cleared here.
> - No caption band, status text or file-level label is visible on the plate. ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Grounded mud/thatch riverbank house with irregular pale wall patches, open doorway shows platform/mat and hanging fish, baskets/jars, canoe at shore. Thin poles/trap handles present but no unmistakable paddle blade by doorway. Bright daylight direction and hard shadowing.

**Independent assessment:** Grounded-house rule improved versus V001 stilt construction; jar/canoe/platform/fish plausible subject evidence. Required paddles still not clearly established; no inference thin stick=paddle. Chapter soft-silver-overcast requirement also not satisfied by obviously warm sunny presentation without approved alternate-state scope; pale patches alone do not prove limewash or banned material.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Required paddles by the door are not legible; grounded-house/dugout/platform improvements acknowledged.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Grounded-house rule improved versus V001 stilt construction; jar/canoe/platform/fish plausible subject evidence. Required paddles still not clearly established; no inference thin stick=paddle. Chapter soft-silver-overcast requirement also not satisfied by obviously warm sunny presentation without approved alternate-state scope; pale patches alone do not prove limewash or banned material.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Grounded-house rule improved versus V001 stilt construction; jar/canoe/platform/fish plausible subject evidence. Required paddles still not clearly established; no inference thin stick=paddle. Chapter soft-silver-overcast requirement also not satisfied by obviously warm sunny presentation without approved alternate-state scope; pale patches alone do not prove limewash or banned material.

**Dependencies:** CH04_PROPOSED_SCOPE; PADDLE_REFERENCE; LIGHTING_STATE_DECISION

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**CORRECTION REQUIRED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Required paddles by the door are not legible; grounded-house/dugout/platform improvements acknowledged.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

CORRECTION REQUIRED as recommendation for owner-authorised future pass: reference-backed paddles legible by door and approved silver-overcast/after-rain state unless CD explicitly chooses alternate state. Preserve grounded shell, dugout/platform/fish placement. Research specifies paddle/fish/finish form if needed; no species, chemistry, new stilts or culture claim invented. Existing NOT APPROVED retained, no regeneration authorised.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B32 source](https://drive.google.com/file/d/1QtJIm1YcL8orW7pNBRZDyLCdPG-RtCGo/view) — archive`assessments/B32.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e53"></a>

# E53 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E53` · **Filename:** `ENV_CH04-INT-003_THE_CANOE_SHED_V002.jpg`

**Source:** [16E4umob2MQdXGMRt1M9upT5yYOJ8-3UV](https://drive.google.com/file/d/16E4umob2MQdXGMRt1M9upT5yYOJ8-3UV/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-INT-003` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A long thatched roof on posts over three dugouts, one half carved, adzes and chips beneath it.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** Shed, dugouts, adzes.
> **Notes.** Open-sided; walk-through.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`393111`bytes; MD5`c0eda25149958ecf6a6eff5764f67ae0`; SHA256`4a065d68ba18ad033ed00337ad4f48723f972278648f5d88ceb6514b0dea01d9`.
- Research:`2466`bytes; MD5`69e0b2c354d1a129f58002bde84c1f89`; SHA256`afca3f9aff290893caec0c901825b1cbeaa5b2bb3c28e3af713e4f33f0eb7cd6`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E53_ENV_CH04-INT-003_THE_CANOE_SHED_V002.md](https://drive.google.com/file/d/1CMICaKVarqR0n3U1H1wcgITGYPMGHwme/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A thatched open-sided shed on timber posts beside a river with light rapids under a clear sky. Three dugout canoes rest on log rollers: two darker and weathered, and one paler and freshly carved, with adze-like marks and wood chips around it. A small wooden-handled tool with a bound head lies across the pale canoe. A long-handled axe leans against a post at the right. No people are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNIDENTIFIED: the tools are read visually as an adze and an axe; the tool types, the carving method and the single-log form are not verified.
> - UNVERIFIED: the freshly carved canoe is shown as in progress; the image does not establish how the hull was made.
> - UNSUPPORTED SETTING: CH04 setting scope unresolved; the 20 proposed location entries are not cleared here.
> - ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Open thatch/pole shed over three dugout-like hulls on logs, front pale unfinished hull with chips/adze-like bound tool, long-handled axe-like object leaning on post. Warm golden sun from side, distinct shadows and bright sky/river, not flat silver overcast.

**Independent assessment:** Three-hull/unfinished-carving staging materially fits proposed CH04-INT003. Chapter light mismatch remains despite craft detail improvement. Image cannot authenticate single-log manufacturing method, adze construction or technique. Style not rejected merely for photoreal versus painting.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Warm directional lighting conflicts with silver-overcast chapter direction; three dugouts/unfinished hull/tools/chips acknowledged.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Three-hull/unfinished-carving staging materially fits proposed CH04-INT003. Chapter light mismatch remains despite craft detail improvement. Image cannot authenticate single-log manufacturing method, adze construction or technique. Style not rejected merely for photoreal versus painting.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Three-hull/unfinished-carving staging materially fits proposed CH04-INT003. Chapter light mismatch remains despite craft detail improvement. Image cannot authenticate single-log manufacturing method, adze construction or technique. Style not rejected merely for photoreal versus painting.

**Dependencies:** CH04_PROPOSED_SCOPE; LIGHTING_STATE_DECISION; BOATBUILDING_REFERENCE

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**CORRECTION REQUIRED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Warm directional lighting conflicts with silver-overcast chapter direction; three dugouts/unfinished hull/tools/chips acknowledged.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

CORRECTION REQUIRED in a separately authorised light-only/state pass: align to accepted soft silver-overcast/after-rain direction or obtain explicit CD alternate-state waiver; preserve three hulls/unfinished chips/tools/shed geometry and no people. Research craft review distinct from visual state acceptance, no tool-tech dimensions invented. NOT APPROVED unchanged until CD decision.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B33 source](https://drive.google.com/file/d/1Wj41WxKZ_kqLWRqJz2PQFr1EYWSqj9vR/view) — archive`assessments/B33.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

<a id="e54"></a>

# E54 — Independent PENDING assessment

`FULL_PENDING_REFRESH_v1` · Assessment/documentation only · Source/report snapshot family labelled2026-11-18. Dates in source records are retained as provenance, not transformed into new authority.

## 01. Identity, exact version and file role

**Scope code:** `E54` · **Filename:** `ENV_CH04-SET-002_THE_TWO_HOUSE_LANDING_V002.jpg`

**Source:** [1Zjbufzzg6J4eL-OEKVZgBgNV8hMw1lig](https://drive.google.com/file/d/1Zjbufzzg6J4eL-OEKVZgBgNV8hMw1lig/view) · Drive versionD2 · parent`16p2TYXn16u9UNdMlJzjTK873YK_Fk7Ab` (ASSISTANT).

**Role:** creative raster. **Currency:** current proposal — no automatic approval. Generation labels, Drive revisions and dependency codes are distinct; classification does not execute any disposition.

## 02. Intended brief and authority

Canonical location entry `CH04-SET-002` ([register](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view)); proposed/design tiers are preserved:

> **Description.** A tiny landing of two houses and a smoke rack on a bend, half a day from the main settlement.
> - Architecture: Riverside mud houses on the ground (never on stilts); open thatched shelters.
> - Materials: Laterite mud, palm thatch, cane, dugout timber, white cotton cloth, chalk, clay.
> - Lighting: Soft silver overcast; reflections off water.
> **Required assets.** 2 houses, rack, canoe.
> **Notes.** None.

A historical cited assignment is not permission for this refresh to perform it.

## 03. Evidence actually inspected and integrity

Exact downloaded image individually displayed, not contact-sheet-only or Research-description-only review; exact published Research fully read. Source MD5/size and Research fresh-metadata MD5/size matched independently; both SHA256s computed; Research body source-ID joined.

1672×941 JPEG; decoded modeRGB. 

- Source:`371136`bytes; MD5`b90eb10a3a9ff284f59702413f6301c4`; SHA256`97bb33f56016a2d75e4eed9719b62a3e42379ee576923acbef0ae145f14e09a6`.
- Research:`2532`bytes; MD5`995eeec20d72c497715a976f38552451`; SHA256`273693c49d68208cd65a394262b68694e4cf866e4ea9c372c045c0a3c6b4f314`.

Both match their selected metadata snapshots. No source or Research payload was overwritten.

## 04. Exact published Research and attributed summary

[E54_ENV_CH04-SET-002_THE_TWO_HOUSE_LANDING_V002.md](https://drive.google.com/file/d/1TGq03nZeuKiUXaCITObbD_CFrpKF7SfN/view) · Drive versionD2 · parent`1qEEDsGMhCy6JBd0hrrMPuZdFBfC8Zll2`. This is the exact193-family published report, not a substitute historical RR/RR11. It has no creative-verdict authority.

**Published summary (attributed, not newly verified merely by quotation):**

> A reddish earth landing between two thatched mud houses on a palm-lined path. The house at the left has a small window and an open doorway; the house at the right has an open doorway and a wooden rack at its side with a row of dried fish. Two dugout canoes float on dark water in front of the red earth bank. A palm grove stands behind. No people are visible.

**Published flags (original wording, including any error reconciled below):**

> - UNSUPPORTED SETTING: the 'two-house landing' is a fictional arrangement; the CH04 setting is not established; the 20 proposed location entries are not cleared here.
> - UNIDENTIFIED: the fish species and the rack's use are not established.
> - UNVERIFIED: the red earth's composition and the palms' species are not identified.
> - No caption band, status text or file-level label is visible on the plate. ASSISTANT environment plate; not approved by this report.

## 05. Independent content findings

**Direct source observation:** Exactly two grounded mud/thatch houses flank red-earth tongue to water; two floating dugout-like canoes front; fish drying on pole rack beside right house; palms and track behind. Bright warm oblique daylight. No clear fire/smoke at rack.

**Independent assessment:** Two grounded houses/canoes/rack are visible; warm directional light conflicts with chapter soft-silver-overcast direction. F68 explicitly says the assigned rack was COLD/UNLIT and side-set. Missing smoke is therefore NOT an automatic defect and adding active smoke would risk violating the stated brief. What remains unresolved is the exact approved side-set cold smoking-rack staging/reference, not proof that the pictured rack cannot have that function.

## 06. Governing-register and standing-control crosschecks

- [OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) — D2; full text.
- [OPEN_ART_DECISIONS.md](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) — D3; full text.
- [VISUAL_STYLE_GUIDE.md](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) — D3; full text.
- [LOCATION_MASTER_REGISTER.md](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) — D3; 23 relevant complete entries fully read, not entire register.
- [ENVIRONMENT_DESIGN_REGISTER.md](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) — D3; full text.

**Exact prior CD outcome, if present:** NOT APPROVED — NOT APPROVED. Warm directional lighting conflict and unresolved smoke-rack staging authority remain.

Style is expressly photoreal grounded dark fantasy in the in-review guide; there is no invented universal painterly-only prohibition. OAD40 figure controls and later specific user controls are not overwritten by older proposed activity/NPC lists.

## 07. Agreement, disagreement and chronology reconciliation

Two grounded houses/canoes/rack are visible; warm directional light conflicts with chapter soft-silver-overcast direction. F68 explicitly says the assigned rack was COLD/UNLIT and side-set. Missing smoke is therefore NOT an automatic defect and adding active smoke would risk violating the stated brief. What remains unresolved is the exact approved side-set cold smoking-rack staging/reference, not proof that the pictured rack cannot have that function.

Agreement with a picture inventory is not approval of cultural/source/brief compliance. Historical READY→REJECTED, absent-old-master→new-output and earlier-missing-report→later-published-report are read in order, not automatically flagged as contemporaneous contradictions. Published Research is preserved unchanged; this assessment records its narrower supported interpretation.

## 08. Issues, dependencies and priority

**Assessment issue class:** BLOCKING FINAL-USE / SCOPE QUALIFICATION.

**Specific issue:** Two grounded houses/canoes/rack are visible; warm directional light conflicts with chapter soft-silver-overcast direction. F68 explicitly says the assigned rack was COLD/UNLIT and side-set. Missing smoke is therefore NOT an automatic defect and adding active smoke would risk violating the stated brief. What remains unresolved is the exact approved side-set cold smoking-rack staging/reference, not proof that the pictured rack cannot have that function.

**Dependencies:** CH04_PROPOSED_SCOPE; SMOKE_RACK_STAGING_AUTHORITY; LIGHTING_STATE_DECISION

The prior closed-cycle6accepted/21notapproved/12blocked denominator is not recomputed from file count. The quarantined EXP text object is outside this193-file inventory and is never substituted for B23.

## 09. Independent recommendation — not an executed verdict

**CORRECTION REQUIRED**

**Existing CD record retained:** NOT APPROVED — NOT APPROVED. Warm directional lighting conflict and unresolved smoke-rack staging authority remain.

No fresh creative approval, cultural authentication, production-canon status, gate release, assignment or filing authority is granted. A not-approved outcome is not an instruction to revise, regenerate, archive, move or delete. An existing accepted visual outcome is retained without sending unchanged bytes through the same decision again.

## 10. Scoped future direction and decision required

CORRECTION REQUIRED as a future owner-authorised lighting-state recommendation only, plus HOLD final staging sign-off pending CD/Research's exact cold/unlit rack reference. Preserve two grounded houses/canoes; do not add fire, smoke, furnace or people to prove smoking. Existing NOT APPROVED unchanged; no work authorised or executed.

This is a recommendation/closure condition for a separately authorised next cycle, not an instruction to an artist to begin work now. Where a source/reference/authority is missing, obtain it before inventing a solution.

## 11. Preservation and non-actions

No new artwork, regeneration, retouch, promotion, disposition execution, gate waiver, source/Research overwrite, move/copy, restore/trash/delete, permission change or direct-agent-notification claim. Existing evidence and tracked review pack are preserved. This assessment is not an action assignment.

Native V002/V003 Adanna geometry, pose, alignment, scale, likeness and drawn baldric are protected. LEFT_SIDE/BACK remainV003; current accepted images are not changed. Historical aid errors/printed metrics remain evidence rather than silently corrected originals.

## 12. Evidence limits, closure owner and cross-links

Hash equality proves staged-byte identity to the selected metadata snapshot, not authenticity, the truth of every author audit, past actor/causal history or future immutability. Rendered appearance does not prove material composition, species, dimensions, ritual identity or cultural authentication. No external primary scholarship or living-custodian clearance was newly obtained. Exact intake listings were manually transcribed; raw API JSON was not archived.

**Closure owner:** CD/TD for intended scope, acceptance, any explicit waiver and future delegation; Research and, where needed, a living custodian/consultant for sourced cultural/material restrictions. Neither the author nor this assessment self-clears those decisions. Raw unavailable historical masters, masks, renders and scripts are not claimed inspected.

**Related scoped records:** [B34 source](https://drive.google.com/file/d/1rYwLsX0S-MlqK-UArMF3MHUu1qc0QhwN/view) — archive`assessments/B34.md`; [F68 source](https://drive.google.com/file/d/1hY4f3JNYFDBvCA7nGoBfCWexJIYUymUR/view) — archive`assessments/F68.md`

**Closure evidence required:** the exact originating instruction/reference or marked native crop/technical acceptance called for in component10; exact final candidate identity plus applicable Research and an explicit owner decision, without overwriting this evidence. For a retained historical/support record, accurate cross-linking and limitations are the result, not a new artwork verdict.


---

