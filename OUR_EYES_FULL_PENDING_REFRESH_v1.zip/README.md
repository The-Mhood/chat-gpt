# Package guide

Start with MASTER.md, then INDEX.md. Read ISSUES.md and EVIDENCE_LIMITS.md before treating any recommendation as a future decision input.

-193 individual reports: assessments/CODE.md, each exactly12 numbered components.
-Six readable annexes: ASSESSMENTS_A.md to ASSESSMENTS_F.md; each mirrors individual report text. Source links work standalone; annex in-document jump support depends on the viewer.
-Each index row links exact Drive source and exact193-family published Research; candidate source generation is not report Drive version.
-CSV/JSON provide exact hashes, roles and independent recommendations. They are not an executed disposition register.
-Evidence contains manually transcribed metadata, provisional notes labelled provisional, final reconciliation/support profiles, relevant register extracts, native inspection crops and exact RGB test. Full source/report/artwork payloads are not duplicated.
-The six retained visual passes are the existing user outcomes only; all21not-approved and12blockers remain. R6closed/R7unexecuted, no new production.
-Canonical ZIP SHA256 and post-download verification are recorded by the separate Drive handoff receipt. The ZIP does not contain itself or that later receipt.
