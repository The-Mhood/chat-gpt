# Evidence coverage, provenance and limits

## Actual coverage

193/193 exact source payloads downloaded and MD5/size matched;193 SHA256s computed.193/193 exact published193-family Research payloads downloaded, fresh-metadata MD5/size matched and body source-ID joined;193 SHA256s computed.193 Research reports and88 source texts fully read.105 images individually displayed.193 complete twelve-component assessments, not just105 provisional notes. No payload mismatch remained.

The source inventory is root1/ORIGINAL62/ASSISTANT130 with no unlisted deeper PENDING scope found in the complete paginated traversal. Both Research195-entry traversals were complete:193 reports plus summary/index. This is a snapshot inventory, not a claim to have inspected every production/rejected/reference object in Drive. Initial/fresh metadata listings were manually transcribed into TSVs, not saved raw API JSON. A01's published index linked the PENDING folder; actual source object was independently resolved and verified.

All relevant23 complete LocationMaster entries and19 complete CH01 scene entries were read, including proposed/design/access/atmosphere/required-image fields. Entire534861-byte LocationMaster and279079-byte SceneMaster were downloaded/hash-verified but not read end-to-end. Environment, style, character, open decisions, moodboard, current CD verdict, cultural desk guide and identified supplementary/rejection/disposition history were fully read. The large v7 art-bible index was read only in identified selected sections/history; no whole-index content audit is claimed.

## What hashes and images establish

- Downloaded payload equals the selected Drive metadata fingerprint/size at that snapshot; independent local SHA256 pins the bytes used.
- Source ID, generation label, Drive version and report version are separate identity dimensions. Older RR11 report DriveD9 is not H3 dependencyD9 and is not the new193-family reportD2.
- Existing six accepted visual source fingerprints match exactly; retained visual outcomes are not a new decision or promotion.
- RGB tests on current Adanna V003→V004 compare the stated art rectangle only. They do not independently prove V002→V003 preservation, alpha masks, orthographic correctness, material braid detail or culture. Different thresholds/baselines explain many different counts.
- D08 foreground crop identifies short cord-linked stakes, but it is not a whole-frame figure census or item5 completion proof.
- E43 printed13618/2222269≈0.6128% is arithmetically consistent. Original raw masks/pair were not rerun; printed audit is not independent measurement merely because arithmetic works.

## What was not established

1. No external primary scholarship was newly retrieved/critically reread. Cultural guide and published Research statements remain attributed; a broad regional label is not a documented exact form. No new living-custodian/cultural-consultant clearance was obtained.
2. No source author’s old operation history, actor attribution, upload-parent bug cause or whole-Drive preservation was retrospectively proved by matching today’s staged bytes. A scoped zero-result query is not global absence or causal proof.
3. No exact physical composition/species/dimensions, body/remains identification, funeral/ritual identity or engineering performance from rendered appearance alone. Concrete-like/wood-like and labels such as mud/clay are material-read evidence, not chemical identification. CH03 white specks may match registered ash, not a proven snowfall/fire history.
4. Originating later owner Cultural-Guidance/override/removal instructions cited in C03-C09 were not independently located by the complete predicates actually searched (name and fullText). This does not prove they never existed, revoke them or authorise a blanket period/style rule. No unrestricted global authority-search claim.
5. Many native external historical candidate masters, working renders/masks/scripts and rejected local attempts were unavailable/not downloaded. Comparison JPEG panels do not prove embedded raw originals’ bytes or all outside-mask equality. Metadata-only Costume/Wall/Washing/VR008/history resolution is not direct native visual review. The primary Adanna master was displayed; its equal-metadata-hash approved duplicate was metadata-only, not a second downloaded-byte comparison.
6. C07 explicitly reports overwritten/unarchived multi-panel attempts; this is retained as author disclosure. Elsewhere discarded means unselected/retained locally where the source says so. No wider deletion event is inferred.
7. The supplementary gate review is trashed=true in retrieved metadata. It is historical evidence only, not current clearance, and it did not inspect H1/H2. Independently read TD reports/current user controls establish visual-only H1/H2 history; no restoration was attempted.
8. B23 validJPEG and the quarantined2537-byte Markdown object are distinct IDs. This refresh neither recovers missing original bytes nor repeats quarantine/restoration. No uploaded image was deemed valid artwork just from its extension.
9. No full technical/production-kit/scene coverage acceptance from a single moodboard frame or previously accepted limited material correction. Proposed location and source-design status remain separate from established story setting.
10. Publication is complete only when newly created canonical documents/ZIP have been read back with exact parents/bytes/hashes and the separate receipt records the result. No permission changes or direct notifications are part of publication.

## Scope of external byte verification

All23 local external payloads below matched the selected exact-ID metadata MD5/size and have independently computed SHA256s in EXTERNAL_EVIDENCE.json. Same-name duplicates found by search were not substituted. This selected ledger was manually transcribed from connector outputs; it is not a raw unfiltered API dump.

| File | Exact source / Drive version | Read/display extent | Trashed? | MD5 | Bytes |
|---|---|---|---|---|---:|
| `00_INDEX_2026-11-18.md` | [1-i7ERQ6MMDu5UD8mSAXaP0Z8jeVIFFap](https://drive.google.com/file/d/1-i7ERQ6MMDu5UD8mSAXaP0Z8jeVIFFap/view) D2 | full text | false | `75c0b1afc53d33d655318f6a44bfd724` | 40555 |
| `ART_BIBLE_MASTER_INDEX_CURRENT_REVIEW_VERDICT_v7.md` | [1rpbhHDyWvlW4iTGeEw4tuThPDIA2YXSU](https://drive.google.com/file/d/1rpbhHDyWvlW4iTGeEw4tuThPDIA2YXSU/view) D8 | selected history sections, not full index | false | `79f87ed2aabbe5c41aa31fb3e584bb79` | 163692 |
| `OUR_EYES_CURRENT_REVIEW_CD_VERDICT.md` | [1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O](https://drive.google.com/file/d/1zMTwzOX8NBxpg-E72hda-ARIzoiXHa0O/view) D2 | full text | false | `91c17dcfca53d5b00b6a2f74b0a3efb6` | 28212 |
| `MOODBOARD_GENERATION_LIST.md` | [13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3](https://drive.google.com/file/d/13_V3eNiQI7Yk5by6dZRzUAKts2Y4nXU3/view) D3 | full text | false | `3375dbbd2da7013f930adc2c2ced195d` | 15899 |
| `LOCATION_MASTER_REGISTER.md` | [1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R](https://drive.google.com/file/d/1IT5RVzd7kBsPeo3hdJpTliqj4h6O6C9R/view) D3 | 23 relevant complete entries fully read, not entire register | false | `7eb30fe48aa8ba7ba091bb069a694e6a` | 534861 |
| `VISUAL_STYLE_GUIDE.md` | [1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1](https://drive.google.com/file/d/1W9T-FqYIeAp41KyuZ4xlb3QlN0SnHMK1/view) D3 | full text | false | `2839a705ec8ce0e6abe4782021a96b0b` | 3463 |
| `OPEN_ART_DECISIONS.md` | [1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN](https://drive.google.com/file/d/1HkaV90iCq3Kmn3M8rgyNPiJ61m7UISPN/view) D3 | full text | false | `03a42dd298f7fc23a2ea384db3975a11` | 19512 |
| `ENVIRONMENT_DESIGN_REGISTER.md` | [14KvEKG534U2-MtJMEO6VUxW59gRHATzE](https://drive.google.com/file/d/14KvEKG534U2-MtJMEO6VUxW59gRHATzE/view) D3 | full text | false | `73429f27113924c9428bcc22033aa4d9` | 10213 |
| `SCENE_AND_MICROLOCATION_MASTER_REGISTER.md` | [1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa](https://drive.google.com/file/d/1UuP2I9szyZvITuyT5Z8q1NilBZBboQZa/view) D3 | 19 relevant CH01 complete entries fully read, not entire register | false | `8860bd464ebace0d0bede03b750b718a` | 279079 |
| `CHAR_ADANNA_MASTER_REFERENCE_V001.jpg` | [1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y](https://drive.google.com/file/d/1k08XH8VjNJAnSoMNU4YvBPtBEUdYD20y/view) D5 | individual full image display | false | `901a5009ab5ff44a81fb3799c7e6de6d` | 585862 |
| `WEAPON_ADANNA_PRIMARY_BLADE_V001.jpg` | [1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac](https://drive.google.com/file/d/1V12Sq2BZdIqjsgkx5GRpzGxc3nS3Gbac/view) D3 | individual full image display | false | `bbeb0788667643d86e9adfde0326399e` | 521776 |
| `CHARACTER_DESIGN_REGISTER.md` | [1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH](https://drive.google.com/file/d/1naNn0D7jAXOVc01Xvnl4YYEvS_zwcTjH/view) D3 | full text | false | `ffb671f2b24a558e5d419a837f7f9ec8` | 12917 |
| `ENV_HOME_SETTLEMENT_ESTABLISHING_V001.jpg` | [1x0VcaAvxbnFIGR8GdvSXWc7cNfzSpIrG](https://drive.google.com/file/d/1x0VcaAvxbnFIGR8GdvSXWc7cNfzSpIrG/view) D4 | individual full image display | false | `d910ed565975530c2b36753fbeba6b96` | 796658 |
| `REF_ADANNA_MASTER_PORTRAIT_APPROVED_V001.jpg` | [1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF](https://drive.google.com/file/d/1CMW978LfSYtR0SRAgnqKZkk0gNY_rpqF/view) D3 | individual full image display | false | `827d464b159059a201def413957d9c4d` | 387742 |
| `ENV_LAST_DAUGHTER_ANCESTRAL_REALM_NNEKAS_HOUSE_V004.jpg` | [1JIoAiQ20goibDA-ujYr95iyihBTLKZWj](https://drive.google.com/file/d/1JIoAiQ20goibDA-ujYr95iyihBTLKZWj/view) D3 | individual full image display | false | `8eec0c112ea14a8aa1d8328ed10004e7` | 580415 |
| `ENV_LAST_DAUGHTER_ANCESTRAL_REALM_ESTABLISHING_V005.jpg` | [1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW](https://drive.google.com/file/d/1qi7TsLi5v8pfM4mHYLWvJEaSdPPyl_qW/view) D3 | individual full image display | false | `6f32d454bb7b6f15ce31e3bffa136385` | 786106 |
| `REJECTION_REPORT_ESTABLISHING_V012.md` | [1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT](https://drive.google.com/file/d/1l4zcjiDg-9M7Mff9BHFDJWfAxz_RG-fT/view) D2 | full text | false | `d8bacfc88e53650e745e3ce810353c89` | 8745 |
| `OUR_EYES_CD_DISPOSITION_REGISTER_2026-11-17_v2.md` | [1UERM2hK_ruXNHzGQAkbXUv9Br277e93g](https://drive.google.com/file/d/1UERM2hK_ruXNHzGQAkbXUv9Br277e93g/view) D2 | full text | false | `3d2050bf7cbdbf1310ab603deb769182` | 18684 |
| `SUPPLEMENTARY_CULTURAL_GATE_REVIEW_HELD_BOARDS_2026-11-17.md` | [1MwntmTwy44imNKFiV7ZGF5yGN5wX8y0r](https://drive.google.com/file/d/1MwntmTwy44imNKFiV7ZGF5yGN5wX8y0r/view) D3 | full text, TRASHED historical evidence only, not live clearance | true | `775c27a1aacb0d8a4bae127722a73d37` | 14548 |
| `REJECTION_REPORT_SCENE_CH01-SCN-015_FISHING_STREAM_V001.md` | [1rxdnvML7xW2eQ4yjj6_xQahCUUEDq2ki](https://drive.google.com/file/d/1rxdnvML7xW2eQ4yjj6_xQahCUUEDq2ki/view) D2 | full text | false | `7ab582a1189dc6050198136cf95e8a28` | 4180 |
| `REJECTION_REPORT_SCENE_CH01-SCN-032_WELLS_V001.md` | [1fRel2FT9hmEJpoETK7ZPHFDElHY-7iRs](https://drive.google.com/file/d/1fRel2FT9hmEJpoETK7ZPHFDElHY-7iRs/view) D2 | full text | false | `b71a1f2cb0293b88f165ec3f7ac81082` | 3624 |
| `CULTURAL_REFERENCE_GUIDE.md` | [1nHRaY0K_nkcPH1wfpL5hHmYHoFOc2do-](https://drive.google.com/file/d/1nHRaY0K_nkcPH1wfpL5hHmYHoFOc2do-/view) D3 | full text, attributed desk-research guide not independent primary verification | false | `c16d402abf86bd4392baa4ff995ef517` | 3177 |
| `REJECTION_REPORT_SCENE_CH01-SCN-034_ROADS_V001.md` | [1bUztQ65iiKN35dPBmPTztZULqPjVRwBM](https://drive.google.com/file/d/1bUztQ65iiKN35dPBmPTztZULqPjVRwBM/view) D2 | full text | false | `726e7102109c057fe761a6320c951eb3` | 4088 |

## Precedence and reproducibility

Final individual assessments/ASSESSMENTS.json supersede provisional visual-note interpretations. Provisional notes are retained for audit, including subsequent corrections; they are not extra approvals or current correction briefs. All report templates carry twelve substantive components; unique per-file observations, source/Research quotes, reconciliation and scope-specific closure are separate from common controls. The supplied build/QA scripts rebuild from the staged exact source payloads and manually authored profiles; source downloads themselves stay at their canonical Drive IDs rather than being duplicated into this documentation archive.
